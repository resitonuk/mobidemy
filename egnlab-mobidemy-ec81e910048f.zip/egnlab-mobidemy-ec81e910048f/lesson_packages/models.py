from django.db import models
from django.utils.translation import ugettext_lazy as _
from lessons.models import *
from quizzes.models import *

# Create your models here.
class LessonPackage(models.Model):

    lesson = models.ManyToManyField(Lesson)
    name = models.CharField(_('lesson_package_name'), max_length=100, unique=True)
    explanation = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = _('Lesson Package')
        verbose_name_plural = _('Lesson Packages')

    def __unicode__(self):
        return self.name
