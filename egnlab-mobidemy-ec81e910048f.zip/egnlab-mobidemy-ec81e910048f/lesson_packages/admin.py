from django.contrib import admin
from lesson_packages.models import LessonPackage

admin.site.register(LessonPackage)
