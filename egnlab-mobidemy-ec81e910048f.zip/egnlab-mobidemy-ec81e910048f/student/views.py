from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.http import Http404
from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.shortcuts import render_to_response
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required, user_passes_test
from settings.views import editor_check
from django.contrib import messages
from settings.views import current_student
from online_exam.models import *
from subscriptions.models import *
from settings.permission_required import student_login_required
import datetime


@student_login_required
def student_root_path(request):
    user = request.user
    student = current_student(request)
    available_subscription_types = SubscriptionType.get_user_available_subscription_types(request.user)
    taken_and_active_subscriptions = Subscription.get_user_taken_and_active_subscriptions(request.user)
    taken_and_deactivated_subscriptions = Subscription.get_user_taken_and_deactivated_subscriptions(request.user)
    #available_exams = OnlineExam.get_student_available_exams_with_subscription(current_student(request))
    #taken_exams = OnlineExam.get_student_taken_exams(current_student(request))
    return render(request, 'student/index.html',locals(), context_instance=RequestContext(request))

@student_login_required
def available_exam_list(request):
    user = request.user
    student = current_student(request)
    available_exams = OnlineExam.get_student_available_exams_with_subscription(current_student(request))
    taken_exams = OnlineExam.get_student_taken_exams(current_student(request))
    return render_to_response('student/student_exam_list.html', locals(), context_instance=RequestContext(request))

@student_login_required
def total_results(request):
    user = request.user
    student = current_student(request)
    return render_to_response('student/total_results.html', locals(), context_instance=RequestContext(request))


@student_login_required
def student_exam_show(request, exam_id):
    exam = get_object_or_404(OnlineExam.get_student_available_exams_with_subscription(current_student(request)), id=exam_id) # TODO: Here is incorrect, temporary
    exam_type_sub_heads = exam.exam_type.examtypesubhead_set.all() # TODO: Here is incorrect, temporary
    return render_to_response('student/student_exam_show.html', locals(), context_instance=RequestContext(request))


@student_login_required
def student_exam_report(request, exam_id):
    exam = get_object_or_404(OnlineExam.get_student_taken_exams(current_student(request)), id=exam_id)
    student = current_student(request)
    exam_type_sub_heads = exam.exam_type.examtypesubhead_set.all()
    exam_questions = exam.examquestion_set.all()
    questions = exam.get_assigned_questions
    choice_list = exam.exam_type.choices_with_list()
    student_exam = StudentExam.get_exam_with_student(student, exam)
    student_exam_answers = student_exam.studentexamanswer_set.all()
    return render_to_response('student/student_exam_report.html', locals(), context_instance=RequestContext(request))
