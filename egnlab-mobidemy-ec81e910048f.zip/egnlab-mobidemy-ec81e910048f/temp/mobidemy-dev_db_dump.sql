--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: exam_packages_exampackage; Type: TABLE; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE TABLE exam_packages_exampackage (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    explanation text
);


ALTER TABLE public.exam_packages_exampackage OWNER TO fordjango;

--
-- Name: exam_packages_exampackage_exam; Type: TABLE; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE TABLE exam_packages_exampackage_exam (
    id integer NOT NULL,
    exampackage_id integer NOT NULL,
    exam_id integer NOT NULL
);


ALTER TABLE public.exam_packages_exampackage_exam OWNER TO fordjango;

--
-- Name: exam_packages_exampackage_exam_id_seq; Type: SEQUENCE; Schema: public; Owner: fordjango
--

CREATE SEQUENCE exam_packages_exampackage_exam_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exam_packages_exampackage_exam_id_seq OWNER TO fordjango;

--
-- Name: exam_packages_exampackage_exam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fordjango
--

ALTER SEQUENCE exam_packages_exampackage_exam_id_seq OWNED BY exam_packages_exampackage_exam.id;


--
-- Name: exam_packages_exampackage_id_seq; Type: SEQUENCE; Schema: public; Owner: fordjango
--

CREATE SEQUENCE exam_packages_exampackage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exam_packages_exampackage_id_seq OWNER TO fordjango;

--
-- Name: exam_packages_exampackage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fordjango
--

ALTER SEQUENCE exam_packages_exampackage_id_seq OWNED BY exam_packages_exampackage.id;


--
-- Name: exams_exam; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exams_exam (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    start_date timestamp with time zone,
    state character varying(50) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_user_id integer,
    exam_type_id integer NOT NULL,
    published_user_id integer,
    total_time integer NOT NULL,
    explanation text
);


ALTER TABLE public.exams_exam OWNER TO postgres;

--
-- Name: exams_exam_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exams_exam_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exams_exam_id_seq OWNER TO postgres;

--
-- Name: exams_exam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE exams_exam_id_seq OWNED BY exams_exam.id;


--
-- Name: exams_examquestion; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exams_examquestion (
    id integer NOT NULL,
    order_number integer NOT NULL,
    assign_user_id integer,
    exam_id integer NOT NULL,
    question_id integer NOT NULL,
    exam_type_sub_head_topic_id integer NOT NULL,
    exam_type_sub_head_id integer NOT NULL
);


ALTER TABLE public.exams_examquestion OWNER TO postgres;

--
-- Name: exams_examquestion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exams_examquestion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exams_examquestion_id_seq OWNER TO postgres;

--
-- Name: exams_examquestion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE exams_examquestion_id_seq OWNED BY exams_examquestion.id;


--
-- Name: exams_examtype; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exams_examtype (
    id integer NOT NULL,
    name character varying(60) NOT NULL,
    choice_count integer NOT NULL
);


ALTER TABLE public.exams_examtype OWNER TO postgres;

--
-- Name: exams_examtype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exams_examtype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exams_examtype_id_seq OWNER TO postgres;

--
-- Name: exams_examtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE exams_examtype_id_seq OWNED BY exams_examtype.id;


--
-- Name: exams_examtypesubhead; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exams_examtypesubhead (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    order_number integer NOT NULL,
    exam_type_id integer NOT NULL,
    question_count integer NOT NULL
);


ALTER TABLE public.exams_examtypesubhead OWNER TO postgres;

--
-- Name: exams_examtypesubhead_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exams_examtypesubhead_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exams_examtypesubhead_id_seq OWNER TO postgres;

--
-- Name: exams_examtypesubhead_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE exams_examtypesubhead_id_seq OWNED BY exams_examtypesubhead.id;


--
-- Name: exams_examtypesubheadtopic; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exams_examtypesubheadtopic (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    order_number integer NOT NULL,
    exam_type_sub_head_id integer NOT NULL,
    lesson_category_unit_topic_id integer NOT NULL
);


ALTER TABLE public.exams_examtypesubheadtopic OWNER TO postgres;

--
-- Name: exams_examtypesubheadtopic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exams_examtypesubheadtopic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exams_examtypesubheadtopic_id_seq OWNER TO postgres;

--
-- Name: exams_examtypesubheadtopic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE exams_examtypesubheadtopic_id_seq OWNED BY exams_examtypesubheadtopic.id;


--
-- Name: exams_studentexam; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exams_studentexam (
    id integer NOT NULL,
    start_date_time timestamp with time zone,
    finish_date_time timestamp with time zone,
    hold_date_time timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    exam_id integer NOT NULL,
    student_id integer NOT NULL,
    is_finish boolean NOT NULL
);


ALTER TABLE public.exams_studentexam OWNER TO postgres;

--
-- Name: exams_studentexam_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exams_studentexam_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exams_studentexam_id_seq OWNER TO postgres;

--
-- Name: exams_studentexam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE exams_studentexam_id_seq OWNED BY exams_studentexam.id;


--
-- Name: exams_studentexamanswer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE exams_studentexamanswer (
    id integer NOT NULL,
    answer_index_number integer,
    total_spent_seconds integer NOT NULL,
    total_viewed_times integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    question_id integer NOT NULL,
    student_exam_id integer NOT NULL
);


ALTER TABLE public.exams_studentexamanswer OWNER TO postgres;

--
-- Name: exams_studentexamanswer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE exams_studentexamanswer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exams_studentexamanswer_id_seq OWNER TO postgres;

--
-- Name: exams_studentexamanswer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE exams_studentexamanswer_id_seq OWNED BY exams_studentexamanswer.id;


--
-- Name: lesson_categories_lessoncategory; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE lesson_categories_lessoncategory (
    id integer NOT NULL,
    name character varying(60) NOT NULL,
    explanation text,
    lesson_level_id integer
);


ALTER TABLE public.lesson_categories_lessoncategory OWNER TO postgres;

--
-- Name: lesson_categories_lessoncategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE lesson_categories_lessoncategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lesson_categories_lessoncategory_id_seq OWNER TO postgres;

--
-- Name: lesson_categories_lessoncategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE lesson_categories_lessoncategory_id_seq OWNED BY lesson_categories_lessoncategory.id;


--
-- Name: lesson_categories_lessoncategoryunit; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE lesson_categories_lessoncategoryunit (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    explanation text,
    lesson_category_id integer NOT NULL
);


ALTER TABLE public.lesson_categories_lessoncategoryunit OWNER TO postgres;

--
-- Name: lesson_categories_lessoncategoryunit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE lesson_categories_lessoncategoryunit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lesson_categories_lessoncategoryunit_id_seq OWNER TO postgres;

--
-- Name: lesson_categories_lessoncategoryunit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE lesson_categories_lessoncategoryunit_id_seq OWNED BY lesson_categories_lessoncategoryunit.id;


--
-- Name: lesson_categories_lessoncategoryunittopic; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE lesson_categories_lessoncategoryunittopic (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    explanation text,
    lesson_category_unit_id integer NOT NULL
);


ALTER TABLE public.lesson_categories_lessoncategoryunittopic OWNER TO postgres;

--
-- Name: lesson_categories_lessoncategoryunittopic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE lesson_categories_lessoncategoryunittopic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lesson_categories_lessoncategoryunittopic_id_seq OWNER TO postgres;

--
-- Name: lesson_categories_lessoncategoryunittopic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE lesson_categories_lessoncategoryunittopic_id_seq OWNED BY lesson_categories_lessoncategoryunittopic.id;


--
-- Name: lesson_categories_lessonlevel; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE lesson_categories_lessonlevel (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    explanation text
);


ALTER TABLE public.lesson_categories_lessonlevel OWNER TO postgres;

--
-- Name: lesson_categories_lessonlevel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE lesson_categories_lessonlevel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lesson_categories_lessonlevel_id_seq OWNER TO postgres;

--
-- Name: lesson_categories_lessonlevel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE lesson_categories_lessonlevel_id_seq OWNED BY lesson_categories_lessonlevel.id;


--
-- Name: places_city; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE places_city (
    id integer NOT NULL,
    "Name" character varying(200),
    "Region_id" integer
);


ALTER TABLE public.places_city OWNER TO postgres;

--
-- Name: places_city_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE places_city_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.places_city_id_seq OWNER TO postgres;

--
-- Name: places_city_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE places_city_id_seq OWNED BY places_city.id;


--
-- Name: places_region; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE places_region (
    id integer NOT NULL,
    "Name" character varying(200)
);


ALTER TABLE public.places_region OWNER TO postgres;

--
-- Name: places_region_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE places_region_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.places_region_id_seq OWNER TO postgres;

--
-- Name: places_region_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE places_region_id_seq OWNED BY places_region.id;


--
-- Name: places_state; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE places_state (
    id integer NOT NULL,
    "Name" character varying(200),
    "City_id" integer
);


ALTER TABLE public.places_state OWNER TO postgres;

--
-- Name: places_state_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE places_state_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.places_state_id_seq OWNER TO postgres;

--
-- Name: places_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE places_state_id_seq OWNED BY places_state.id;


--
-- Name: questions_contentprovider; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE questions_contentprovider (
    id integer NOT NULL,
    name character varying(60) NOT NULL,
    explanation text
);


ALTER TABLE public.questions_contentprovider OWNER TO postgres;

--
-- Name: questions_contentprovider_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE questions_contentprovider_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_contentprovider_id_seq OWNER TO postgres;

--
-- Name: questions_contentprovider_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE questions_contentprovider_id_seq OWNED BY questions_contentprovider.id;


--
-- Name: questions_question; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE questions_question (
    id integer NOT NULL,
    title text,
    correct_choice_index integer NOT NULL,
    state character varying(50) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    content_provider_id integer NOT NULL,
    created_user_id integer,
    last_updated_user_id integer
);


ALTER TABLE public.questions_question OWNER TO postgres;

--
-- Name: questions_question_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE questions_question_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_question_id_seq OWNER TO postgres;

--
-- Name: questions_question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE questions_question_id_seq OWNED BY questions_question.id;


--
-- Name: questions_questionattachment; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE questions_questionattachment (
    id integer NOT NULL,
    label character varying(16) NOT NULL,
    image character varying(100) NOT NULL,
    question_id integer NOT NULL
);


ALTER TABLE public.questions_questionattachment OWNER TO postgres;

--
-- Name: questions_questionattachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE questions_questionattachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_questionattachment_id_seq OWNER TO postgres;

--
-- Name: questions_questionattachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE questions_questionattachment_id_seq OWNED BY questions_questionattachment.id;


--
-- Name: questions_questionlessoncategoryunittopic; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE questions_questionlessoncategoryunittopic (
    id integer NOT NULL,
    lesson_category_unit_topic_id integer NOT NULL,
    question_id integer NOT NULL,
    lesson_category_id integer,
    lesson_category_unit_id integer,
    lesson_level_id integer
);


ALTER TABLE public.questions_questionlessoncategoryunittopic OWNER TO postgres;

--
-- Name: questions_questionlessoncategoryunittopic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE questions_questionlessoncategoryunittopic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.questions_questionlessoncategoryunittopic_id_seq OWNER TO postgres;

--
-- Name: questions_questionlessoncategoryunittopic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE questions_questionlessoncategoryunittopic_id_seq OWNED BY questions_questionlessoncategoryunittopic.id;


--
-- Name: settings_setting; Type: TABLE; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE TABLE settings_setting (
    id integer NOT NULL,
    name character varying(200),
    text text,
    code character varying(200),
    url character varying(200),
    "targetBlank" boolean NOT NULL,
    image character varying(100),
    category character varying(200)
);


ALTER TABLE public.settings_setting OWNER TO fordjango;

--
-- Name: settings_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: fordjango
--

CREATE SEQUENCE settings_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_setting_id_seq OWNER TO fordjango;

--
-- Name: settings_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fordjango
--

ALTER SEQUENCE settings_setting_id_seq OWNED BY settings_setting.id;


--
-- Name: social_auth_association; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE social_auth_association (
    id integer NOT NULL,
    server_url character varying(255) NOT NULL,
    handle character varying(255) NOT NULL,
    secret character varying(255) NOT NULL,
    issued integer NOT NULL,
    lifetime integer NOT NULL,
    assoc_type character varying(64) NOT NULL
);


ALTER TABLE public.social_auth_association OWNER TO postgres;

--
-- Name: social_auth_association_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE social_auth_association_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.social_auth_association_id_seq OWNER TO postgres;

--
-- Name: social_auth_association_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE social_auth_association_id_seq OWNED BY social_auth_association.id;


--
-- Name: social_auth_nonce; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE social_auth_nonce (
    id integer NOT NULL,
    server_url character varying(255) NOT NULL,
    "timestamp" integer NOT NULL,
    salt character varying(40) NOT NULL
);


ALTER TABLE public.social_auth_nonce OWNER TO postgres;

--
-- Name: social_auth_nonce_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE social_auth_nonce_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.social_auth_nonce_id_seq OWNER TO postgres;

--
-- Name: social_auth_nonce_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE social_auth_nonce_id_seq OWNED BY social_auth_nonce.id;


--
-- Name: social_auth_usersocialauth; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE social_auth_usersocialauth (
    id integer NOT NULL,
    user_id integer NOT NULL,
    provider character varying(32) NOT NULL,
    uid character varying(255) NOT NULL,
    extra_data text NOT NULL
);


ALTER TABLE public.social_auth_usersocialauth OWNER TO postgres;

--
-- Name: social_auth_usersocialauth_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE social_auth_usersocialauth_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.social_auth_usersocialauth_id_seq OWNER TO postgres;

--
-- Name: social_auth_usersocialauth_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE social_auth_usersocialauth_id_seq OWNED BY social_auth_usersocialauth.id;


--
-- Name: subscriptions_subscription; Type: TABLE; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE TABLE subscriptions_subscription (
    id integer NOT NULL,
    start_date timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    balance numeric(6,2) NOT NULL,
    subscription_type_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.subscriptions_subscription OWNER TO fordjango;

--
-- Name: subscriptions_subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: fordjango
--

CREATE SEQUENCE subscriptions_subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscriptions_subscription_id_seq OWNER TO fordjango;

--
-- Name: subscriptions_subscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fordjango
--

ALTER SEQUENCE subscriptions_subscription_id_seq OWNED BY subscriptions_subscription.id;


--
-- Name: subscriptions_subscriptiontype; Type: TABLE; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE TABLE subscriptions_subscriptiontype (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    explanation text,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    active boolean NOT NULL,
    price numeric(8,2) NOT NULL
);


ALTER TABLE public.subscriptions_subscriptiontype OWNER TO fordjango;

--
-- Name: subscriptions_subscriptiontype_id_seq; Type: SEQUENCE; Schema: public; Owner: fordjango
--

CREATE SEQUENCE subscriptions_subscriptiontype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscriptions_subscriptiontype_id_seq OWNER TO fordjango;

--
-- Name: subscriptions_subscriptiontype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fordjango
--

ALTER SEQUENCE subscriptions_subscriptiontype_id_seq OWNED BY subscriptions_subscriptiontype.id;


--
-- Name: subscriptions_subscriptiontypepackage; Type: TABLE; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE TABLE subscriptions_subscriptiontypepackage (
    id integer NOT NULL,
    class_name character varying(24) NOT NULL,
    name character varying(100) NOT NULL,
    explanation text,
    class_id integer NOT NULL,
    subscription_type_id integer NOT NULL
);


ALTER TABLE public.subscriptions_subscriptiontypepackage OWNER TO fordjango;

--
-- Name: subscriptions_subscriptiontypepackage_id_seq; Type: SEQUENCE; Schema: public; Owner: fordjango
--

CREATE SEQUENCE subscriptions_subscriptiontypepackage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscriptions_subscriptiontypepackage_id_seq OWNER TO fordjango;

--
-- Name: subscriptions_subscriptiontypepackage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fordjango
--

ALTER SEQUENCE subscriptions_subscriptiontypepackage_id_seq OWNED BY subscriptions_subscriptiontypepackage.id;


--
-- Name: thumbnail_kvstore; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE thumbnail_kvstore (
    key character varying(200) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.thumbnail_kvstore OWNER TO postgres;

--
-- Name: user_conf_student; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_conf_student (
    id integer NOT NULL,
    date_of_birth date,
    gender character varying(40),
    profile_picture character varying(100),
    status boolean NOT NULL,
    activation_code character varying(200),
    password_activation character varying(200),
    made_time timestamp with time zone,
    city_id integer,
    role_id integer NOT NULL,
    state_id integer,
    user_id integer NOT NULL,
    activation_code_date timestamp with time zone,
    password_activation_date timestamp with time zone
);


ALTER TABLE public.user_conf_student OWNER TO postgres;

--
-- Name: user_conf_student_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE user_conf_student_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_conf_student_id_seq OWNER TO postgres;

--
-- Name: user_conf_student_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE user_conf_student_id_seq OWNED BY user_conf_student.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY exam_packages_exampackage ALTER COLUMN id SET DEFAULT nextval('exam_packages_exampackage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY exam_packages_exampackage_exam ALTER COLUMN id SET DEFAULT nextval('exam_packages_exampackage_exam_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_exam ALTER COLUMN id SET DEFAULT nextval('exams_exam_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examquestion ALTER COLUMN id SET DEFAULT nextval('exams_examquestion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examtype ALTER COLUMN id SET DEFAULT nextval('exams_examtype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examtypesubhead ALTER COLUMN id SET DEFAULT nextval('exams_examtypesubhead_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examtypesubheadtopic ALTER COLUMN id SET DEFAULT nextval('exams_examtypesubheadtopic_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_studentexam ALTER COLUMN id SET DEFAULT nextval('exams_studentexam_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_studentexamanswer ALTER COLUMN id SET DEFAULT nextval('exams_studentexamanswer_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lesson_categories_lessoncategory ALTER COLUMN id SET DEFAULT nextval('lesson_categories_lessoncategory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lesson_categories_lessoncategoryunit ALTER COLUMN id SET DEFAULT nextval('lesson_categories_lessoncategoryunit_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lesson_categories_lessoncategoryunittopic ALTER COLUMN id SET DEFAULT nextval('lesson_categories_lessoncategoryunittopic_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lesson_categories_lessonlevel ALTER COLUMN id SET DEFAULT nextval('lesson_categories_lessonlevel_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_city ALTER COLUMN id SET DEFAULT nextval('places_city_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_region ALTER COLUMN id SET DEFAULT nextval('places_region_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_state ALTER COLUMN id SET DEFAULT nextval('places_state_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_contentprovider ALTER COLUMN id SET DEFAULT nextval('questions_contentprovider_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_question ALTER COLUMN id SET DEFAULT nextval('questions_question_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_questionattachment ALTER COLUMN id SET DEFAULT nextval('questions_questionattachment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_questionlessoncategoryunittopic ALTER COLUMN id SET DEFAULT nextval('questions_questionlessoncategoryunittopic_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY settings_setting ALTER COLUMN id SET DEFAULT nextval('settings_setting_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY social_auth_association ALTER COLUMN id SET DEFAULT nextval('social_auth_association_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY social_auth_nonce ALTER COLUMN id SET DEFAULT nextval('social_auth_nonce_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY social_auth_usersocialauth ALTER COLUMN id SET DEFAULT nextval('social_auth_usersocialauth_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY subscriptions_subscription ALTER COLUMN id SET DEFAULT nextval('subscriptions_subscription_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY subscriptions_subscriptiontype ALTER COLUMN id SET DEFAULT nextval('subscriptions_subscriptiontype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY subscriptions_subscriptiontypepackage ALTER COLUMN id SET DEFAULT nextval('subscriptions_subscriptiontypepackage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_conf_student ALTER COLUMN id SET DEFAULT nextval('user_conf_student_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
2	Öğrenci
3	Editör
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 3, true);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 87, true);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add Student Users	7	add_student
20	Can change Student Users	7	change_student
21	Can delete Student Users	7	delete_student
22	Can add user social auth	8	add_usersocialauth
23	Can change user social auth	8	change_usersocialauth
24	Can delete user social auth	8	delete_usersocialauth
25	Can add nonce	9	add_nonce
26	Can change nonce	9	change_nonce
27	Can delete nonce	9	delete_nonce
28	Can add association	10	add_association
29	Can change association	10	change_association
30	Can delete association	10	delete_association
31	Can add kv store	11	add_kvstore
32	Can change kv store	11	change_kvstore
33	Can delete kv store	11	delete_kvstore
34	Can add Coğrafi Bölge	12	add_region
35	Can change Coğrafi Bölge	12	change_region
36	Can delete Coğrafi Bölge	12	delete_region
37	Can add İl	13	add_city
38	Can change İl	13	change_city
39	Can delete İl	13	delete_city
40	Can add İlçe	14	add_state
41	Can change İlçe	14	change_state
42	Can delete İlçe	14	delete_state
43	Can add Exam Type	15	add_examtype
44	Can change Exam Type	15	change_examtype
45	Can delete Exam Type	15	delete_examtype
46	Can add Exam Type Sub Head	16	add_examtypesubhead
47	Can change Exam Type Sub Head	16	change_examtypesubhead
48	Can delete Exam Type Sub Head	16	delete_examtypesubhead
49	Can add Exam Type Sub Head Topic	17	add_examtypesubheadtopic
50	Can change Exam Type Sub Head Topic	17	change_examtypesubheadtopic
51	Can delete Exam Type Sub Head Topic	17	delete_examtypesubheadtopic
52	Can add Exam	18	add_exam
53	Can change Exam	18	change_exam
54	Can delete Exam	18	delete_exam
55	Can add Assigned Question	19	add_examquestion
56	Can change Assigned Question	19	change_examquestion
57	Can delete Assigned Question	19	delete_examquestion
58	Can add Student Exam	20	add_studentexam
59	Can change Student Exam	20	change_studentexam
60	Can delete Student Exam	20	delete_studentexam
61	Can add Student Exam Answer	21	add_studentexamanswer
62	Can change Student Exam Answer	21	change_studentexamanswer
63	Can delete Student Exam Answer	21	delete_studentexamanswer
64	Can add Lesson Category	22	add_lessoncategory
65	Can change Lesson Category	22	change_lessoncategory
66	Can delete Lesson Category	22	delete_lessoncategory
67	Can add Lesson Category Unit	23	add_lessoncategoryunit
68	Can change Lesson Category Unit	23	change_lessoncategoryunit
69	Can delete Lesson Category Unit	23	delete_lessoncategoryunit
70	Can add Lesson Category Unit Topic	24	add_lessoncategoryunittopic
71	Can change Lesson Category Unit Topic	24	change_lessoncategoryunittopic
72	Can delete Lesson Category Unit Topic	24	delete_lessoncategoryunittopic
73	Can add Lesson Level	25	add_lessonlevel
74	Can change Lesson Level	25	change_lessonlevel
75	Can delete Lesson Level	25	delete_lessonlevel
76	Can add Content Provider	26	add_contentprovider
77	Can change Content Provider	26	change_contentprovider
78	Can delete Content Provider	26	delete_contentprovider
79	Can add Question	27	add_question
80	Can change Question	27	change_question
81	Can delete Question	27	delete_question
82	Can add Question Attachment	28	add_questionattachment
83	Can change Question Attachment	28	change_questionattachment
84	Can delete Question Attachment	28	delete_questionattachment
85	Can add question lesson category unit topic	29	add_questionlessoncategoryunittopic
86	Can change question lesson category unit topic	29	change_questionlessoncategoryunittopic
87	Can delete question lesson category unit topic	29	delete_questionlessoncategoryunittopic
91	Can add Setting	31	add_setting
92	Can change Setting	31	change_setting
93	Can delete Setting	31	delete_setting
94	Can add Lesson Category Unit Topic	32	add_exampackage
95	Can change Lesson Category Unit Topic	32	change_exampackage
96	Can delete Lesson Category Unit Topic	32	delete_exampackage
97	Can add Subscription Type	33	add_subscriptiontype
98	Can change Subscription Type	33	change_subscriptiontype
99	Can delete Subscription Type	33	delete_subscriptiontype
100	Can add Subscription Type Package	34	add_subscriptiontypepackage
101	Can change Subscription Type Package	34	change_subscriptiontypepackage
102	Can delete Subscription Type Package	34	delete_subscriptiontypepackage
103	Can add Subscription	35	add_subscription
104	Can change Subscription	35	change_subscription
105	Can delete Subscription	35	delete_subscription
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 105, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
7	pbkdf2_sha256$12000$0euyLrAHFkpE$jm3F9JI6XoO6QQSvgC/gg7OeseYYLic+PThMOJ5eACw=	2015-01-30 16:23:43.525+02	f	lostofis@gmail.com	Yusuf	YILDIRIM	lostofis@gmail.com	f	t	2015-01-30 16:22:38.675+02
4	pbkdf2_sha256$12000$yNxXq1OzlXTu$CWf7/Z6alzCao/6Kz4e+Wf6V/Vl2UGAUdbys93N762w=	2015-02-02 10:41:25.464605+02	f	seymen.sipahi@egnity.com	seymen	sipahi	seymen.sipahi@egnity.com	f	t	2015-01-30 13:31:50.502344+02
9	pbkdf2_sha256$12000$A0yEiZgdxviG$pCd39mSFYCUsQWMZy6kQicsLFiRqOBCNfHDhmSdpN7Y=	2015-07-01 17:10:10.39064+03	f	admin.occ@gmail.com	Fake	Student	admin.occ@gmail.com	f	t	2015-02-10 13:27:51+02
3	pbkdf2_sha256$12000$Z7VoBOTBNLHn$fcCSGJf9o5LOBk9QLYgIlfFbeCM7G4wc5Ejock8KJ8E=	2015-07-02 11:36:58.033261+03	t	egnadmin			info@egnity.com	t	t	2015-01-30 13:16:31.090635+02
5	pbkdf2_sha256$12000$xu1ER3Hv472J$m3EjFHPK/QzUw1S5W1cIBbTiqEQmU0DkILiei9NaIJw=	2015-02-27 20:15:59.320899+02	f	editor@egnity.com	Editor	User	editor@egnity.com	f	t	2015-01-30 13:35:01+02
8	pbkdf2_sha256$12000$xPxIoX0Uq26y$de2uKjXqiQ+Polx/E7zlvrP6W7wz6fUnjXMUCz3/WSE=	2015-06-14 17:07:43.33438+03	f	ilhanoguzhan@gmail.com	Oguzhan	ILHAN	ilhanoguzhan@gmail.com	f	t	2015-02-01 12:18:22+02
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
1	4	2
5	7	2
10	8	2
11	5	3
13	9	2
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 13, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 9, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
9	2015-01-30 13:26:27.662517+02	2	admin.occ@gmail.com	3		4	3
10	2015-01-30 13:26:27.91969+02	1	mobidemy	3		4	3
11	2015-01-30 13:27:33.5417+02	1	Student Role	3		3	3
12	2015-01-30 13:28:25.236349+02	2	Öğrenci	1		3	3
13	2015-01-30 13:28:41.309252+02	3	Editör	1		3	3
14	2015-01-30 13:32:44.867727+02	1	KPSS	1		15	3
15	2015-01-30 13:35:01.496863+02	5	editor_editor	1		4	3
16	2015-01-30 13:35:28.717294+02	5	editor_editor	2	groups değiştirildi.	4	3
17	2015-01-30 13:36:59.485914+02	1	KPSS	3		15	3
18	2015-01-30 13:37:08.495768+02	5	editor_user	2	username değiştirildi.	4	3
19	2015-01-30 13:41:25.385225+02	2	TEOG	1		15	3
20	2015-01-30 13:41:53.053167+02	1	TÜRKÇE	1		16	3
21	2015-01-30 13:42:32.495986+02	2	Sosyal Bilgisi	1		16	3
22	2015-01-30 13:42:39.371865+02	1	Turkce	2	name değiştirildi.	16	3
23	2015-01-30 13:43:11.655564+02	3	Matematik	1		16	3
24	2015-01-30 13:43:21.638315+02	1	Turkce	2	order_number değiştirildi.	16	3
25	2015-01-30 13:43:31.274036+02	2	Sosyal Bilgisi	2	order_number değiştirildi.	16	3
26	2015-01-30 13:43:37.965282+02	3	Matematik	2	Değiştirilen alanlar yok.	16	3
27	2015-01-30 13:44:10.14028+02	4	Fen ve Teknoloji	1		16	3
28	2015-01-30 13:44:31.882463+02	5	Din Kulturu ve Ahlak Bilgisi	1		16	3
29	2015-01-30 13:45:36.771044+02	1	Matematik	1		22	3
30	2015-01-30 13:45:43.78007+02	2	Turkce	1		22	3
31	2015-01-30 13:45:50.891672+02	3	Din Kulturu ve Ahlak Bilgisi	1		22	3
32	2015-01-30 13:45:56.205695+02	4	Fen ve Teknoloji	1		22	3
33	2015-01-30 13:46:22.079261+02	1	Asal Sayilar	1		23	3
34	2015-01-30 13:46:33.931373+02	2	Rasyonel Sayilar	1		23	3
35	2015-01-30 13:46:48.569984+02	3	Anlam BIlgisi	1		23	3
36	2015-01-30 13:47:18.765409+02	4	Dil Bilgisi	1		23	3
37	2015-01-30 13:47:31.195708+02	5	Islamiyet Tarihi	1		23	3
38	2015-01-30 13:47:45.440104+02	6	Peygamberler	1		23	3
39	2015-01-30 13:47:56.652584+02	7	Elementler	1		23	3
40	2015-01-30 13:48:32.935049+02	8	Elektrik	1		23	3
41	2015-01-30 13:50:12.942571+02	1	Negatif Sayilar	1		24	3
42	2015-01-30 13:50:24.479002+02	2	Pozitif Sayilar	1		24	3
43	2015-01-30 13:51:14.970971+02	3	Dogrusal Sayilar	1		24	3
44	2015-01-30 13:51:34.563774+02	4	Limitsiz Rasyonel Sayilar	1		24	3
45	2015-01-30 13:51:45.012498+02	5	Kelime Bilgisi	1		24	3
46	2015-01-30 13:51:55.540792+02	6	Cumle Bilgisi	1		24	3
47	2015-01-30 13:52:18.988918+02	7	Dil Yapisi	1		24	3
48	2015-01-30 13:52:35.693704+02	8	Cumle Bilgisi	1		24	3
49	2015-01-30 13:52:41.885574+02	8	Cumle Bilgisi	3		24	3
50	2015-01-30 13:53:02.28808+02	9	Cumle Yapisi	1		24	3
51	2015-01-30 13:53:20.889847+02	10	Peygamber Zamani	1		24	3
52	2015-01-30 13:53:35.180804+02	11	Peygamberden Sonra	1		24	3
53	2015-01-30 13:53:47.79297+02	12	Inanis	1		24	3
54	2015-01-30 13:54:14.58067+02	13	Tanri Ile Gorusme	1		24	3
55	2015-01-30 13:54:33.27956+02	14	Periyodik Tablo	1		24	3
56	2015-01-30 13:54:45.009282+02	15	Alkali Metaller	1		24	3
57	2015-01-30 13:56:38.940311+02	16	Soy Metaller	1		24	3
58	2015-01-30 13:56:47.576179+02	17	Sert Metaller	1		24	3
59	2015-01-30 13:57:12.808407+02	13	Rehberlik	2	name değiştirildi.	24	3
60	2015-01-30 13:57:23.778973+02	18	Notron	1		24	3
61	2015-01-30 13:57:32.310522+02	19	Proton	1		24	3
62	2015-01-30 13:57:39.352333+02	20	Iletkenlik	1		24	3
63	2015-01-30 13:58:26.87223+02	1	Dil Yapisi	1		17	3
64	2015-01-30 13:58:40.491355+02	2	Cumle Bilgisi	1		17	3
65	2015-01-30 13:58:53.396906+02	3	Kelime Bilgisi	1		17	3
66	2015-01-30 13:59:23.435213+02	4	Peygamber Zamani	1		17	3
67	2015-01-30 13:59:35.549138+02	5	Inanis Bilgisi	1		17	3
68	2015-01-30 13:59:50.402261+02	6	Negatif Sayilar	1		17	3
69	2015-01-30 14:00:01.095278+02	7	Limitsiz Rasyonel Sayilar	1		17	3
70	2015-01-30 14:00:10.27453+02	8	Dogrusal Sayilar	1		17	3
71	2015-01-30 14:00:23.128782+02	9	Alkali Metaller	1		17	3
72	2015-01-30 14:00:30.556324+02	10	Soy Metaller	1		17	3
73	2015-01-30 14:00:39.65704+02	11	Sert Metaller	1		17	3
74	2015-01-30 14:00:51.918399+02	12	Notron	1		17	3
75	2015-01-30 14:01:03.633042+02	13	Proton	1		17	3
76	2015-01-30 14:01:23.514048+02	14	Peygamberden Sonra	1		17	3
77	2015-01-30 14:02:16.801155+02	1	TEOG Deneme Sinavi 1	1		18	3
78	2015-01-30 14:02:44.204962+02	2	TEOG Deneme Sinavi 2	1		18	3
79	2015-01-30 14:03:04.854814+02	2	Final Dersanesi	1		26	3
80	2015-01-30 14:03:11.666071+02	1	Final Dersanesi	3		26	3
81	2015-01-30 14:03:23.934423+02	3	Mobidemy Dershanesi	1		26	3
82	2015-01-30 14:05:07.545656+02	1	1+1 Kactir.	1		27	3
83	2015-01-30 14:06:36.836528+02	2	3/5 kactir?	1		27	3
84	2015-01-30 14:08:48.486674+02	3	NaCl Neyi ifade eder	1		27	3
85	2015-01-30 16:22:17.992+02	6	lostofis@gmail.com	3		4	3
86	2015-01-30 16:23:15.438+02	5	lostofis@gmail.com	2	date_of_birth değiştirildi.	7	3
87	2015-01-30 16:24:47.692+02	5	lostofis@gmail.com	2	date_of_birth değiştirildi.	7	3
88	2015-02-01 02:27:47.636053+02	1	Orta Ogretim 8	1		25	3
89	2015-02-01 02:28:16.772898+02	2	Ilkogretim 7	1		25	3
90	2015-02-01 02:28:25.139275+02	3	NaCl Neyi ifade eder	2	question lesson category unit topic "QuestionLessonCategoryUnitTopic object" eklendi. question lesson category unit topic "QuestionLessonCategoryUnitTopic object" eklendi.	27	3
91	2015-02-01 02:29:19.127598+02	2	3/5 kactir?	2	question lesson category unit topic "QuestionLessonCategoryUnitTopic object" eklendi. question lesson category unit topic "QuestionLessonCategoryUnitTopic object" eklendi. question lesson category unit topic "QuestionLessonCategoryUnitTopic object" eklendi.	27	3
92	2015-02-01 02:29:52.029484+02	1	1+1 Kactir.	2	question lesson category unit topic "QuestionLessonCategoryUnitTopic object" eklendi. question lesson category unit topic "QuestionLessonCategoryUnitTopic object" eklendi.	27	3
93	2015-02-01 03:31:23.831962+02	5	editor_user	2	first_name, last_name ve email değiştirildi.	4	3
94	2015-02-01 03:31:55.680075+02	5	editor_user	2	email değiştirildi.	4	3
95	2015-02-01 03:32:07.034109+02	5	editor@egnity.com	2	username değiştirildi.	4	3
96	2015-02-01 12:18:54.453638+02	8	ilhanoguzhan@gmail.com	2	is_active değiştirildi.	4	3
97	2015-02-02 10:07:14.101512+02	5	editor@egnity.com	2	password değiştirildi.	4	3
98	2015-02-02 10:07:16.629957+02	5	editor@egnity.com	2	Değiştirilen alanlar yok.	4	3
99	2015-02-02 10:18:33.484592+02	5	editor@egnity.com	2	password değiştirildi.	4	3
100	2015-02-03 05:14:37.810681+02	4	Fen ve Teknoloji	2	lesson_level değiştirildi.	22	3
101	2015-02-03 05:14:42.190467+02	3	Din Kulturu ve Ahlak Bilgisi	2	lesson_level değiştirildi.	22	3
102	2015-02-03 05:14:46.732306+02	2	Turkce	2	lesson_level değiştirildi.	22	3
103	2015-02-03 05:14:52.448137+02	1	Matematik	2	lesson_level değiştirildi.	22	3
104	2015-02-03 09:52:10.653241+02	4	Fen ve Teknoloji	2	lesson_level değiştirildi.	22	3
105	2015-02-03 09:52:16.180737+02	4	Fen ve Teknoloji	2	lesson_level değiştirildi.	22	3
106	2015-02-03 09:54:43.161115+02	4	Fen ve Teknoloji	2	lesson_level değiştirildi.	22	3
107	2015-02-06 04:01:35.425386+02	3	hebelek	1		15	3
108	2015-02-06 04:01:37.744904+02	6	Turkce	1		16	3
109	2015-02-06 04:01:47.128962+02	6	Turkce	3		16	3
110	2015-02-07 16:54:45.351887+02	1	TEOG Deneme Sinavi 1	2	total_time değiştirildi.	18	3
111	2015-02-10 13:28:41.629144+02	9	admin.occ@gmail.com	2	is_active değiştirildi.	4	3
112	2015-02-15 07:13:14.203612+02	1	Teog Deneme Paketi	1		32	3
113	2015-02-15 07:44:24.359935+02	1	Aadsasd	1		33	3
114	2015-02-15 08:23:31.762339+02	2	2004 Sinav ve Ders paketi	1		33	3
115	2015-02-15 08:23:34.784511+02	1	Teog deneme paketi Tumu	1		34	3
116	2015-02-15 08:24:49.865395+02	2	Teoh 1	1		32	3
117	2015-02-15 08:24:59.804373+02	2	teoh 1 paketi	1		34	3
118	2015-02-15 08:28:41.674427+02	3	aSDSADASD	1		32	3
119	2015-02-15 08:28:45.164753+02	2	2004 Sinav ve Ders paketi	2	Subscription Type Package "sadsadasdasd" eklendi.	33	3
120	2015-02-15 08:29:09.58514+02	2	2004 Sinav ve Ders paketi	2	Değiştirilen alanlar yok.	33	3
121	2015-02-18 10:10:31.046358+02	2	2004 Sinav ve Ders paketi	2	active değiştirildi.	33	3
122	2015-02-18 10:10:39.534859+02	1	Aadsasd	2	Değiştirilen alanlar yok.	33	3
123	2015-02-18 10:10:54.89521+02	2	2004 Sinav ve Ders paketi	2	end_date değiştirildi.	33	3
124	2015-02-18 10:11:05.127486+02	1	Aadsasd	2	end_date değiştirildi.	33	3
125	2015-06-15 16:35:53.84164+03	2	2004 Sinav ve Ders paketi	2	end_date değiştirildi.	33	3
126	2015-06-15 16:36:03.728085+03	1	Aadsasd	2	end_date değiştirildi.	33	3
127	2015-06-15 17:04:05.298172+03	2	2004 Sinav ve Ders paketi	2	explanation değiştirildi.	33	3
128	2015-06-15 17:04:09.319936+03	1	Aadsasd	2	explanation değiştirildi.	33	3
129	2015-06-15 17:35:53.938967+03	3	2016 Sinav sorulari	1		33	3
130	2015-06-15 17:36:45.293173+03	4	non-characteristic words	1		33	3
131	2015-06-15 17:36:58.011667+03	3	2016 Sinav sorulari	2	Subscription Type Package "Denemeler" eklendi.	33	3
132	2015-06-15 17:37:21.418567+03	1	Aadsasd	2	end_date değiştirildi.	33	3
133	2015-06-15 17:37:30.957286+03	1	Aadsasd	2	active değiştirildi.	33	3
134	2015-06-15 17:45:30.506632+03	4	non-characteristic words	2	start_date, end_date ve active değiştirildi.	33	3
135	2015-06-15 17:45:47.653058+03	3	2016 Sinav sorulari	2	start_date, end_date ve active değiştirildi.	33	3
136	2015-07-02 11:38:02.011345+03	1	from_address	1		31	3
137	2015-07-02 11:38:34.827053+03	2	smtp_password	1		31	3
138	2015-07-02 11:39:10.277774+03	3	smtp_username	1		31	3
139	2015-07-02 11:39:38.815738+03	4	smtp_port	1		31	3
140	2015-07-02 11:40:03.776684+03	5	smtp_address	1		31	3
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 140, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	log entry	admin	logentry
2	permission	auth	permission
3	group	auth	group
4	user	auth	user
5	content type	contenttypes	contenttype
6	session	sessions	session
7	Student Users	user_conf	student
8	user social auth	social_auth	usersocialauth
9	nonce	social_auth	nonce
10	association	social_auth	association
11	kv store	thumbnail	kvstore
12	Coğrafi Bölge	places	region
13	İl	places	city
14	İlçe	places	state
15	Exam Type	exams	examtype
16	Exam Type Sub Head	exams	examtypesubhead
17	Exam Type Sub Head Topic	exams	examtypesubheadtopic
18	Exam	exams	exam
19	Assigned Question	exams	examquestion
20	Student Exam	exams	studentexam
21	Student Exam Answer	exams	studentexamanswer
22	Lesson Category	lesson_categories	lessoncategory
23	Lesson Category Unit	lesson_categories	lessoncategoryunit
24	Lesson Category Unit Topic	lesson_categories	lessoncategoryunittopic
25	Lesson Level	lesson_categories	lessonlevel
26	Content Provider	questions	contentprovider
27	Question	questions	question
28	Question Attachment	questions	questionattachment
29	question lesson category unit topic	questions	questionlessoncategoryunittopic
31	Setting	settings	setting
32	Lesson Category Unit Topic	exam_packages	exampackage
33	Subscription Type	subscriptions	subscriptiontype
34	Subscription Type Package	subscriptions	subscriptiontypepackage
35	Subscription	subscriptions	subscription
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 35, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2015-01-26 07:55:44.666661+02
2	auth	0001_initial	2015-01-26 07:55:44.784835+02
3	admin	0001_initial	2015-01-26 07:55:44.837058+02
4	places	0001_initial	2015-01-26 07:55:44.908867+02
5	user_conf	0001_initial	2015-01-26 07:55:45.011952+02
6	lesson_categories	0001_initial	2015-01-26 07:55:45.086629+02
7	questions	0001_initial	2015-01-26 07:55:45.250817+02
8	exams	0001_initial	2015-01-26 07:55:45.547838+02
9	exams	0002_auto_20150126_0740	2015-01-26 07:55:46.18909+02
10	sessions	0001_initial	2015-01-26 07:55:46.216283+02
11	questions	0002_auto_20150128_1142	2015-01-30 13:12:39.584163+02
12	questions	0003_questionexamtypesubheadtopic	2015-01-30 13:12:40.333026+02
13	user_conf	0002_auto_20150130_1621	2015-01-30 16:21:19.114+02
14	exams	0003_examquestion_exam_type_sub_head_topic	2015-02-01 02:40:16.630816+02
15	questions	0004_auto_20150201_0319	2015-02-01 03:20:14.232964+02
16	exams	0004_examtypesubhead_question_count	2015-02-01 12:15:17.351524+02
17	exams	0005_exam_total_time	2015-02-01 12:15:17.603239+02
18	exams	0006_examquestion_exam_type_sub_head	2015-02-01 12:15:17.887851+02
19	exams	0007_auto_20150203_0417	2015-02-03 04:17:51.353826+02
20	lesson_categories	0002_lessoncategory_lesson_level	2015-02-03 04:17:51.441874+02
21	questions	0005_remove_questionlessoncategoryunittopic_lesson_level	2015-02-03 04:19:37.99707+02
22	questions	0006_auto_20150203_1933	2015-02-03 19:33:49.788523+02
23	exams	0008_auto_20150206_0358	2015-02-06 03:59:18.377491+02
24	settings	0001_initial	2015-02-06 03:59:18.417503+02
25	settings	0002_auto_20150203_1139	2015-02-06 03:59:18.448106+02
26	settings	0003_setting_category	2015-02-06 03:59:18.477273+02
27	settings	0004_auto_20150203_1144	2015-02-06 03:59:18.534566+02
28	exams	0009_auto_20150206_0412	2015-02-06 04:13:50.556155+02
29	lesson_categories	0003_auto_20150206_0412	2015-02-06 04:13:50.644079+02
30	questions	0007_auto_20150206_0412	2015-02-06 04:13:51.070357+02
31	exams	0010_auto_20150206_1519	2015-02-06 15:19:23.475244+02
32	exams	0011_auto_20150206_1712	2015-02-06 17:12:28.660704+02
33	exams	0012_auto_20150206_1713	2015-02-06 17:13:21.043265+02
34	exams	0013_studentexam_is_finish	2015-02-07 17:28:20.033759+02
35	exams	0014_auto_20150215_0339	2015-02-15 03:39:54.152268+02
37	exam_packages	0001_initial	2015-02-15 06:13:05.142392+02
38	subscriptions	0001_initial	2015-02-15 06:36:14.646268+02
39	subscriptions	0002_subscription	2015-02-15 06:48:43.731037+02
40	subscriptions	0003_auto_20150215_0816	2015-02-15 08:16:19.349063+02
41	subscriptions	0004_auto_20150215_1002	2015-02-15 10:02:42.05599+02
42	settings	0005_order	2015-02-20 03:26:55.348948+02
43	settings	0006_delete_order	2015-02-20 03:26:55.412355+02
44	subscriptions	0005_subscriptiontype_price	2015-02-20 03:26:56.399318+02
45	subscriptions	0006_remove_subscription_explanation	2015-02-20 07:44:08.68942+02
46	subscriptions	0007_auto_20150220_1037	2015-02-20 10:37:56.025953+02
47	exams	0015_exam_explanation	2015-06-22 17:48:38.582249+03
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_migrations_id_seq', 47, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
v0ydyee1yq2em842cy2py9lndqmf0uls	YTRhY2Q1ZjE1MTU5Yjg5N2Y5MGI2MDNmNmFmYzg0ZjZiNDRiZjM0OTqAAn1xAShVD19hdXRoX3VzZXJfaGFzaFUoZTZlOWQ2MGU1MjVmYjQ5NWViZWY0NjQ4NjRlYzRiNGI4ZjVjNTc3ZFUSX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHECVQ1fYXV0aF91c2VyX2lkSwR1Lg==	2015-02-13 16:59:34.383638+02
gjnv594f41jk9kf7fhrf7x0rtqlqmuiz	YzljMmNmOTgyZTI4ZDFjZmFjNGM2MGJiODFiM2UzMzEwODNiMDVjYjqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSgzYjJkMTVmMjc3ODk0MjQyMmQ3MDZlODg0NmIzMjU4ZWQ4ZDljNGFkVQ1fYXV0aF91c2VyX2lkcQNLBVUSX2F1dGhfdXNlcl9iYWNrZW5kcQRVKWRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kcQV1Lg==	2015-02-16 10:14:15.652048+02
ufzq8uaoeb1f1f6xrj96smx7gyuglcib	MTdlZjZhOGJjOTlkNjM5ZWQxMjZjNjc3MTYyNWVjOTQxODI0NGZmMDqAAn1xAS4=	2015-02-13 13:24:24.374524+02
o6276899n01lkn9tkpzt5ptmplgch9p9	MTBmYTlmNzU3MjM3NGFkNjA0M2IyYjkwOTg0ZWEwZTYyOWNlZjA5ZDqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSgzMWViZmUzOTI4NDkyYjc0MWFkYTAyNmY5NDcyYjJhZjZjOGYzMjdlVRJfYXV0aF91c2VyX2JhY2tlbmRxA1UpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmRxBFUNX2F1dGhfdXNlcl9pZHEFSwN1Lg==	2015-02-13 13:24:35.034199+02
udplxmtu6a8xwsv0131qxg42qupptxo4	YzdmYzk1YjZmZjYyZWM1MTA0ZjdmZDUxOTk0NjdiNzA5MDdiNTZiZjqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSg3OGI2NDJlN2Q0M2MxMmMwMzE1MDU4ZmZiNTk2OTcxZTMzYTY5NjQyVRJfYXV0aF91c2VyX2JhY2tlbmRxA1UpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmRxBFUNX2F1dGhfdXNlcl9pZHEFSwV1Lg==	2015-02-13 13:37:47.48515+02
4fkzw7nfi7psdu0opltm2q3zlf08tga2	ZWVjNDBiNTgyZmFhOTQ4NDdlOGRjMTIxNWZlMGI4ODc4MjY2NTFlZTqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSgxZmEwNGYxNmQ5YTc3ZDYxYjI4OGI2OWJiNTliY2YwODNlNjM3Yjg5VQ1fYXV0aF91c2VyX2lkcQNLCFUSX2F1dGhfdXNlcl9iYWNrZW5kcQRVKWRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kcQV1Lg==	2015-02-16 10:40:55.141934+02
3hvzjqniep8wksuuob39pwetdawwg1ck	MjBjZjJjM2EzZDA5ZThjZDMwNTNkMTgzODg3NGYzMTM5NGZlZWM4MzqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVShlNmU5ZDYwZTUyNWZiNDk1ZWJlZjQ2NDg2NGVjNGI0YjhmNWM1NzdkVQ1fYXV0aF91c2VyX2lkcQNLBFUSX2F1dGhfdXNlcl9iYWNrZW5kcQRVKWRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kcQV1Lg==	2015-02-16 10:41:25.468044+02
06kegb8uoryp8k17226g62qg6se7hh3k	YzdmYzk1YjZmZjYyZWM1MTA0ZjdmZDUxOTk0NjdiNzA5MDdiNTZiZjqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSg3OGI2NDJlN2Q0M2MxMmMwMzE1MDU4ZmZiNTk2OTcxZTMzYTY5NjQyVRJfYXV0aF91c2VyX2JhY2tlbmRxA1UpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmRxBFUNX2F1dGhfdXNlcl9pZHEFSwV1Lg==	2015-02-15 02:30:29.624497+02
t48wjn0igzrag065xlmj2blwdyc19an4	MTBmYTlmNzU3MjM3NGFkNjA0M2IyYjkwOTg0ZWEwZTYyOWNlZjA5ZDqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSgzMWViZmUzOTI4NDkyYjc0MWFkYTAyNmY5NDcyYjJhZjZjOGYzMjdlVRJfYXV0aF91c2VyX2JhY2tlbmRxA1UpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmRxBFUNX2F1dGhfdXNlcl9pZHEFSwN1Lg==	2015-02-13 16:12:28.147+02
285ute0894g3k1505ctgr9rxsy01mc9r	MTdlZjZhOGJjOTlkNjM5ZWQxMjZjNjc3MTYyNWVjOTQxODI0NGZmMDqAAn1xAS4=	2015-02-13 16:33:42.011+02
2t3kplv2znjz645gyo1vczhfq5c6z05v	MTBmYTlmNzU3MjM3NGFkNjA0M2IyYjkwOTg0ZWEwZTYyOWNlZjA5ZDqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSgzMWViZmUzOTI4NDkyYjc0MWFkYTAyNmY5NDcyYjJhZjZjOGYzMjdlVRJfYXV0aF91c2VyX2JhY2tlbmRxA1UpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmRxBFUNX2F1dGhfdXNlcl9pZHEFSwN1Lg==	2015-07-16 11:36:58.036859+03
sev46p4ezt5o9ufxtgtiasv50mnwsuac	Nzc0ZTBkMmZkMTRiNzk5OWE4YTc5MDUyYzIwZDVhYmQ4NDNjMmUwMjqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSg3ZWQ4YTcxYjE0NTI5ODk4ZDMxYjllMWIwMDk1ZDY0N2FlZWU3ZGNmVRJfYXV0aF91c2VyX2JhY2tlbmRxA1UpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmRxBFUNX2F1dGhfdXNlcl9pZHEFSwl1Lg==	2015-03-13 20:19:15.50874+02
dndk1ub2o0foinv8we8eftss1dknd9iu	MTBmYTlmNzU3MjM3NGFkNjA0M2IyYjkwOTg0ZWEwZTYyOWNlZjA5ZDqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSgzMWViZmUzOTI4NDkyYjc0MWFkYTAyNmY5NDcyYjJhZjZjOGYzMjdlVRJfYXV0aF91c2VyX2JhY2tlbmRxA1UpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmRxBFUNX2F1dGhfdXNlcl9pZHEFSwN1Lg==	2015-06-26 14:02:09.926978+03
uyke414p3fv2dwk3l3jq0p5wdhif6y98	Nzc0ZTBkMmZkMTRiNzk5OWE4YTc5MDUyYzIwZDVhYmQ4NDNjMmUwMjqAAn1xAShVD19hdXRoX3VzZXJfaGFzaHECVSg3ZWQ4YTcxYjE0NTI5ODk4ZDMxYjllMWIwMDk1ZDY0N2FlZWU3ZGNmVRJfYXV0aF91c2VyX2JhY2tlbmRxA1UpZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmRxBFUNX2F1dGhfdXNlcl9pZHEFSwl1Lg==	2015-06-29 17:46:19.289242+03
\.


--
-- Data for Name: exam_packages_exampackage; Type: TABLE DATA; Schema: public; Owner: fordjango
--

COPY exam_packages_exampackage (id, name, explanation) FROM stdin;
1	Teog Deneme Paketi	1. ve 2.
2	Teoh 1	sad
3	aSDSADASD	
\.


--
-- Data for Name: exam_packages_exampackage_exam; Type: TABLE DATA; Schema: public; Owner: fordjango
--

COPY exam_packages_exampackage_exam (id, exampackage_id, exam_id) FROM stdin;
1	1	1
2	1	2
3	2	1
4	3	2
\.


--
-- Name: exam_packages_exampackage_exam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fordjango
--

SELECT pg_catalog.setval('exam_packages_exampackage_exam_id_seq', 4, true);


--
-- Name: exam_packages_exampackage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fordjango
--

SELECT pg_catalog.setval('exam_packages_exampackage_id_seq', 3, true);


--
-- Data for Name: exams_exam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY exams_exam (id, name, start_date, state, created_at, updated_at, created_user_id, exam_type_id, published_user_id, total_time, explanation) FROM stdin;
2	TEOG Deneme Sinavi 2	2015-03-15 12:00:00+02	assigning	2015-01-30 14:02:44.204108+02	2015-02-03 02:32:34.646668+02	3	2	\N	0	\N
1	TEOG Deneme Sinavi 1	2015-02-01 09:00:00+02	published	2015-01-30 14:02:16.800132+02	2015-02-07 16:54:45.349782+02	3	2	\N	120	\N
\.


--
-- Name: exams_exam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exams_exam_id_seq', 2, true);


--
-- Data for Name: exams_examquestion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY exams_examquestion (id, order_number, assign_user_id, exam_id, question_id, exam_type_sub_head_topic_id, exam_type_sub_head_id) FROM stdin;
16	3006002	5	2	2	6	3
17	3008001	5	2	1	8	3
18	3006001	5	1	1	6	3
19	3008002	5	1	2	8	3
20	4009003	5	1	3	9	4
\.


--
-- Name: exams_examquestion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exams_examquestion_id_seq', 20, true);


--
-- Data for Name: exams_examtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY exams_examtype (id, name, choice_count) FROM stdin;
2	TEOG	5
3	hebelek	5
\.


--
-- Name: exams_examtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exams_examtype_id_seq', 3, true);


--
-- Data for Name: exams_examtypesubhead; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY exams_examtypesubhead (id, name, order_number, exam_type_id, question_count) FROM stdin;
1	Turkce	1	2	40
2	Sosyal Bilgisi	2	2	40
4	Fen ve Teknoloji	4	2	40
5	Din Kulturu ve Ahlak Bilgisi	5	2	40
3	Matematik	3	2	40
\.


--
-- Name: exams_examtypesubhead_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exams_examtypesubhead_id_seq', 6, true);


--
-- Data for Name: exams_examtypesubheadtopic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY exams_examtypesubheadtopic (id, name, order_number, exam_type_sub_head_id, lesson_category_unit_topic_id) FROM stdin;
1	Dil Yapisi	1	1	7
2	Cumle Bilgisi	2	1	6
3	Kelime Bilgisi	3	1	5
4	Peygamber Zamani	4	2	10
5	Inanis Bilgisi	5	2	12
6	Negatif Sayilar	6	3	1
7	Limitsiz Rasyonel Sayilar	7	3	4
8	Dogrusal Sayilar	8	3	3
9	Alkali Metaller	9	4	15
10	Soy Metaller	10	4	16
11	Sert Metaller	11	4	17
12	Notron	12	4	18
13	Proton	13	4	19
14	Peygamberden Sonra	14	5	11
\.


--
-- Name: exams_examtypesubheadtopic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exams_examtypesubheadtopic_id_seq', 14, true);


--
-- Data for Name: exams_studentexam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY exams_studentexam (id, start_date_time, finish_date_time, hold_date_time, created_at, updated_at, exam_id, student_id, is_finish) FROM stdin;
18	2015-06-25 14:45:26.374623+03	2015-06-25 14:45:36.186007+03	\N	2015-06-25 14:45:26.374891+03	2015-06-25 14:45:36.186169+03	1	7	t
\.


--
-- Name: exams_studentexam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exams_studentexam_id_seq', 18, true);


--
-- Data for Name: exams_studentexamanswer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY exams_studentexamanswer (id, answer_index_number, total_spent_seconds, total_viewed_times, created_at, updated_at, question_id, student_exam_id) FROM stdin;
61	4	0	2	2015-06-25 14:45:26.380762+03	2015-06-25 14:45:30.182022+03	1	18
62	5	0	1	2015-06-25 14:45:26.383403+03	2015-06-25 14:45:33.413958+03	2	18
63	1	0	1	2015-06-25 14:45:26.386024+03	2015-06-25 14:45:34.780687+03	3	18
\.


--
-- Name: exams_studentexamanswer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('exams_studentexamanswer_id_seq', 63, true);


--
-- Data for Name: lesson_categories_lessoncategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY lesson_categories_lessoncategory (id, name, explanation, lesson_level_id) FROM stdin;
3	Din Kulturu ve Ahlak Bilgisi		1
2	Turkce		1
1	Matematik		1
4	Fen ve Teknoloji		2
\.


--
-- Name: lesson_categories_lessoncategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('lesson_categories_lessoncategory_id_seq', 4, true);


--
-- Data for Name: lesson_categories_lessoncategoryunit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY lesson_categories_lessoncategoryunit (id, name, explanation, lesson_category_id) FROM stdin;
1	Asal Sayilar		1
2	Rasyonel Sayilar		1
3	Anlam BIlgisi		2
4	Dil Bilgisi		2
5	Islamiyet Tarihi		3
6	Peygamberler		3
7	Elementler		4
8	Elektrik		4
\.


--
-- Name: lesson_categories_lessoncategoryunit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('lesson_categories_lessoncategoryunit_id_seq', 8, true);


--
-- Data for Name: lesson_categories_lessoncategoryunittopic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY lesson_categories_lessoncategoryunittopic (id, name, explanation, lesson_category_unit_id) FROM stdin;
1	Negatif Sayilar		1
2	Pozitif Sayilar		1
3	Dogrusal Sayilar		2
4	Limitsiz Rasyonel Sayilar		2
5	Kelime Bilgisi		3
6	Cumle Bilgisi		3
7	Dil Yapisi		4
9	Cumle Yapisi		4
10	Peygamber Zamani		5
11	Peygamberden Sonra		5
12	Inanis		6
14	Periyodik Tablo		7
15	Alkali Metaller		7
16	Soy Metaller		7
17	Sert Metaller		7
13	Rehberlik		6
18	Notron		8
19	Proton		8
20	Iletkenlik		8
\.


--
-- Name: lesson_categories_lessoncategoryunittopic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('lesson_categories_lessoncategoryunittopic_id_seq', 20, true);


--
-- Data for Name: lesson_categories_lessonlevel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY lesson_categories_lessonlevel (id, name, explanation) FROM stdin;
1	Orta Ogretim 8	
2	Ilkogretim 7	
\.


--
-- Name: lesson_categories_lessonlevel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('lesson_categories_lessonlevel_id_seq', 2, true);


--
-- Data for Name: places_city; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY places_city (id, "Name", "Region_id") FROM stdin;
1	Corum	2
\.


--
-- Name: places_city_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('places_city_id_seq', 1, true);


--
-- Data for Name: places_region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY places_region (id, "Name") FROM stdin;
1	Corum
2	Karadeniz
\.


--
-- Name: places_region_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('places_region_id_seq', 2, true);


--
-- Data for Name: places_state; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY places_state (id, "Name", "City_id") FROM stdin;
1	Merkez	1
\.


--
-- Name: places_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('places_state_id_seq', 1, true);


--
-- Data for Name: questions_contentprovider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY questions_contentprovider (id, name, explanation) FROM stdin;
2	Final Dersanesi	
3	Mobidemy Dershanesi	
\.


--
-- Name: questions_contentprovider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('questions_contentprovider_id_seq', 3, true);


--
-- Data for Name: questions_question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY questions_question (id, title, correct_choice_index, state, created_at, updated_at, content_provider_id, created_user_id, last_updated_user_id) FROM stdin;
2	3/5 kactir?	5	published	2015-01-30 14:06:36.739548+02	2015-02-01 02:29:18.555431+02	2	3	\N
1	1+1 Kactir.	4	published	2015-01-30 14:05:07.289789+02	2015-02-01 02:29:51.619073+02	3	3	\N
3	NaCl Neyi ifade eder	1	published	2015-01-30 14:08:48.321595+02	2015-02-03 03:10:44.434834+02	2	3	\N
4	asdasdafasfascsa\r\nfasf	5	initiated	2015-02-03 10:18:11.953475+02	2015-02-03 10:18:11.953517+02	2	\N	\N
5	adssafdasf	3	initiated	2015-02-03 10:30:52.47048+02	2015-02-03 10:30:52.47052+02	2	\N	\N
6	sadasda	1	initiated	2015-02-03 18:13:18.76115+02	2015-02-03 18:13:18.761336+02	3	\N	\N
7	sfdsafsdfwe\r\nfdsfsdfsdf\r\nweghtfdsdfd	1	initiated	2015-02-03 18:42:48.953707+02	2015-02-03 19:23:20.68328+02	3	\N	\N
8	sadasfsafasfa	1	initiated	2015-02-03 21:10:29.932783+02	2015-02-03 21:42:51.303951+02	3	\N	\N
\.


--
-- Name: questions_question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('questions_question_id_seq', 8, true);


--
-- Data for Name: questions_questionattachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY questions_questionattachment (id, label, image, question_id) FROM stdin;
1	question_image	mobidemy-dev-stage/questions/2/images/11.gif	1
2	question_answer	mobidemy-dev-stage/questions/2/images/52.png	1
3	question_image	mobidemy-dev-stage/questions/3/images/114.jpg	2
4	question_answer	mobidemy-dev-stage/questions/3/images/858.jpg	2
5	question_image	mobidemy-dev-stage/questions/4/images/1366.jpg	3
6	question_answer	mobidemy-dev-stage/questions/4/images/2532.jpg	3
7	question_image	mobidemy-dev/questions/5/images/75.jpg	4
8	question_answer	mobidemy-dev/questions/5/images/120.jpg	4
9	question_image	mobidemy-dev/questions/6/images/74.png	5
10	question_answer	mobidemy-dev/questions/6/images/150.jpg	5
11	question_image	mobidemy-dev/questions/8/images/73.png	7
12	question_answer	mobidemy-dev/questions/8/images/16.jpg	7
13	question_image	mobidemy-dev/questions/9/images/126.jpg	8
14	question_answer	mobidemy-dev/questions/9/images/195.jpg	8
\.


--
-- Name: questions_questionattachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('questions_questionattachment_id_seq', 14, true);


--
-- Data for Name: questions_questionlessoncategoryunittopic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY questions_questionlessoncategoryunittopic (id, lesson_category_unit_topic_id, question_id, lesson_category_id, lesson_category_unit_id, lesson_level_id) FROM stdin;
1	14	3	\N	\N	\N
2	15	3	\N	\N	\N
3	2	2	\N	\N	\N
4	1	2	\N	\N	\N
5	3	2	\N	\N	\N
6	1	1	\N	\N	\N
7	3	1	\N	\N	\N
8	15	4	\N	\N	\N
9	16	5	\N	\N	\N
10	6	5	\N	\N	\N
11	15	5	\N	\N	\N
12	10	5	\N	\N	\N
13	5	6	\N	\N	\N
14	18	6	\N	\N	\N
15	5	7	\N	\N	\N
16	15	7	\N	\N	\N
17	16	8	4	7	2
\.


--
-- Name: questions_questionlessoncategoryunittopic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('questions_questionlessoncategoryunittopic_id_seq', 18, true);


--
-- Data for Name: settings_setting; Type: TABLE DATA; Schema: public; Owner: fordjango
--

COPY settings_setting (id, name, text, code, url, "targetBlank", image, category) FROM stdin;
1	from_address	seymen.sipahi@egnity.com	from_address		f		
2	smtp_password	egnity1881*	smtp_password		f		
3	smtp_username	seymen.sipahi@egnity.com	smtp_username		f		
4	smtp_port	587	smtp_port		f		
5	smtp_address	smtp.gmail.com	smtp_address		f		
\.


--
-- Name: settings_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fordjango
--

SELECT pg_catalog.setval('settings_setting_id_seq', 5, true);


--
-- Data for Name: social_auth_association; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY social_auth_association (id, server_url, handle, secret, issued, lifetime, assoc_type) FROM stdin;
\.


--
-- Name: social_auth_association_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('social_auth_association_id_seq', 1, false);


--
-- Data for Name: social_auth_nonce; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY social_auth_nonce (id, server_url, "timestamp", salt) FROM stdin;
\.


--
-- Name: social_auth_nonce_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('social_auth_nonce_id_seq', 1, false);


--
-- Data for Name: social_auth_usersocialauth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY social_auth_usersocialauth (id, user_id, provider, uid, extra_data) FROM stdin;
\.


--
-- Name: social_auth_usersocialauth_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('social_auth_usersocialauth_id_seq', 1, false);


--
-- Data for Name: subscriptions_subscription; Type: TABLE DATA; Schema: public; Owner: fordjango
--

COPY subscriptions_subscription (id, start_date, active, balance, subscription_type_id, user_id) FROM stdin;
4	2015-02-20 10:38:18.132692+02	t	0.00	1	9
5	2015-02-20 10:39:07.013529+02	t	0.00	2	9
7	2015-06-26 23:09:02.805837+03	t	0.00	3	9
\.


--
-- Name: subscriptions_subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fordjango
--

SELECT pg_catalog.setval('subscriptions_subscription_id_seq', 7, true);


--
-- Data for Name: subscriptions_subscriptiontype; Type: TABLE DATA; Schema: public; Owner: fordjango
--

COPY subscriptions_subscriptiontype (id, name, explanation, start_date, end_date, active, price) FROM stdin;
2	2004 Sinav ve Ders paketi	asdasdddfff	2015-02-15 01:23:29+02	2015-10-30 01:23:30+02	t	0.00
1	Aadsasd	asdasfdd	2015-02-15 00:44:22+02	2015-03-19 00:44:23+02	f	0.00
4	non-characteristic words	There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.	2015-06-01 17:45:19+03	2015-06-15 17:45:28+03	t	0.00
3	2016 Sinav sorulari	It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has success.	2015-04-15 17:45:43+03	2015-11-25 17:45:44+02	t	0.00
\.


--
-- Name: subscriptions_subscriptiontype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fordjango
--

SELECT pg_catalog.setval('subscriptions_subscriptiontype_id_seq', 4, true);


--
-- Data for Name: subscriptions_subscriptiontypepackage; Type: TABLE DATA; Schema: public; Owner: fordjango
--

COPY subscriptions_subscriptiontypepackage (id, class_name, name, explanation, class_id, subscription_type_id) FROM stdin;
1	ExamPackage	Teog deneme paketi Tumu	asdasd	1	2
2	ExamPackage	teoh 1 paketi	asdasd	2	2
3	ExamPackage	sadsadasdasd	DASDSA	3	2
4	ExamPackage	Teohh	There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.	2	4
5	ExamPackage	Denemeler	There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.	1	3
\.


--
-- Name: subscriptions_subscriptiontypepackage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fordjango
--

SELECT pg_catalog.setval('subscriptions_subscriptiontypepackage_id_seq', 5, true);


--
-- Data for Name: thumbnail_kvstore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY thumbnail_kvstore (key, value) FROM stdin;
\.


--
-- Data for Name: user_conf_student; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_conf_student (id, date_of_birth, gender, profile_picture, status, activation_code, password_activation, made_time, city_id, role_id, state_id, user_id, activation_code_date, password_activation_date) FROM stdin;
3	\N	\N		t	65e4ee8c5e84c12b1d8458bd3018534957848dfc17e968c7d7f00878e3c0b77bfb34a60a176a061c3	efa7319092bc0908b941d79502a3d6870cf142ec1cb8c6c5b8a38499fb57157fe03acf8af2e9e8f28	2015-01-30 13:31:50.564501+02	\N	2	\N	4	\N	\N
5	2015-01-20	\N		t	4dc97b67c469df7e03e6339348e5d6e993a9a0ca1d3da66000faef507ce5baa3c8b4674913b682d26	4977520ec7c93fc00015701ab4260467d6c376451489f5219c8796604c5c6b5ea36899e7df2bc8d12	2015-01-30 16:22:40.139+02	\N	2	\N	7	\N	2015-01-30 16:42:38.058+02
6	\N	\N		t	cd3494b4f4dd06de995f4994c1ed4dd25245d6ae2d368357c3ad031e6c5e83e93f2526a7bdcfbbb6b	\N	2015-02-01 12:18:22.783113+02	\N	2	\N	8	\N	\N
7	\N	\N		t	62fd480ef6c436a1a024b7ea99b02cdef3b6f1482fb6c33550370f79dadcfa02336b43714733a05fa	\N	2015-02-10 13:27:51.53339+02	\N	2	\N	9	2015-02-10 13:27:51.547108+02	\N
\.


--
-- Name: user_conf_student_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('user_conf_student_id_seq', 7, true);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_18843a82cfcc105c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_18843a82cfcc105c_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: exam_packages_exampackage_exam_exampackage_id_exam_id_key; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY exam_packages_exampackage_exam
    ADD CONSTRAINT exam_packages_exampackage_exam_exampackage_id_exam_id_key UNIQUE (exampackage_id, exam_id);


--
-- Name: exam_packages_exampackage_exam_pkey; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY exam_packages_exampackage_exam
    ADD CONSTRAINT exam_packages_exampackage_exam_pkey PRIMARY KEY (id);


--
-- Name: exam_packages_exampackage_name_key; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY exam_packages_exampackage
    ADD CONSTRAINT exam_packages_exampackage_name_key UNIQUE (name);


--
-- Name: exam_packages_exampackage_pkey; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY exam_packages_exampackage
    ADD CONSTRAINT exam_packages_exampackage_pkey PRIMARY KEY (id);


--
-- Name: exams_exam_name_772638227c719708_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_exam
    ADD CONSTRAINT exams_exam_name_772638227c719708_uniq UNIQUE (name);


--
-- Name: exams_exam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_exam
    ADD CONSTRAINT exams_exam_pkey PRIMARY KEY (id);


--
-- Name: exams_examquestion_order_number_7e1e62f39c6a07a6_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examquestion
    ADD CONSTRAINT exams_examquestion_order_number_7e1e62f39c6a07a6_uniq UNIQUE (order_number, exam_id);


--
-- Name: exams_examquestion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examquestion
    ADD CONSTRAINT exams_examquestion_pkey PRIMARY KEY (id);


--
-- Name: exams_examquestion_question_id_20f8b6f782d349ef_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examquestion
    ADD CONSTRAINT exams_examquestion_question_id_20f8b6f782d349ef_uniq UNIQUE (question_id, exam_id);


--
-- Name: exams_examtype_name_2e47065f07fdf834_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examtype
    ADD CONSTRAINT exams_examtype_name_2e47065f07fdf834_uniq UNIQUE (name);


--
-- Name: exams_examtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examtype
    ADD CONSTRAINT exams_examtype_pkey PRIMARY KEY (id);


--
-- Name: exams_examtypesubhead_name_ed4b8292bbab49e_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examtypesubhead
    ADD CONSTRAINT exams_examtypesubhead_name_ed4b8292bbab49e_uniq UNIQUE (name, exam_type_id);


--
-- Name: exams_examtypesubhead_order_number_550c78a96bc032dd_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examtypesubhead
    ADD CONSTRAINT exams_examtypesubhead_order_number_550c78a96bc032dd_uniq UNIQUE (order_number, exam_type_id);


--
-- Name: exams_examtypesubhead_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examtypesubhead
    ADD CONSTRAINT exams_examtypesubhead_pkey PRIMARY KEY (id);


--
-- Name: exams_examtypesubheadtopic_name_29c0720134f8ae39_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examtypesubheadtopic
    ADD CONSTRAINT exams_examtypesubheadtopic_name_29c0720134f8ae39_uniq UNIQUE (name, exam_type_sub_head_id);


--
-- Name: exams_examtypesubheadtopic_order_number_5d0f5b96ca48359c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examtypesubheadtopic
    ADD CONSTRAINT exams_examtypesubheadtopic_order_number_5d0f5b96ca48359c_uniq UNIQUE (order_number, exam_type_sub_head_id);


--
-- Name: exams_examtypesubheadtopic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_examtypesubheadtopic
    ADD CONSTRAINT exams_examtypesubheadtopic_pkey PRIMARY KEY (id);


--
-- Name: exams_studentexam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_studentexam
    ADD CONSTRAINT exams_studentexam_pkey PRIMARY KEY (id);


--
-- Name: exams_studentexamanswer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_studentexamanswer
    ADD CONSTRAINT exams_studentexamanswer_pkey PRIMARY KEY (id);


--
-- Name: exams_studentexamanswer_question_id_4e0015dfdc9ac9c7_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY exams_studentexamanswer
    ADD CONSTRAINT exams_studentexamanswer_question_id_4e0015dfdc9ac9c7_uniq UNIQUE (question_id, student_exam_id);


--
-- Name: lesson_categories_lessoncategory_name_3fbd9aa97f8217f6_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY lesson_categories_lessoncategory
    ADD CONSTRAINT lesson_categories_lessoncategory_name_3fbd9aa97f8217f6_uniq UNIQUE (name);


--
-- Name: lesson_categories_lessoncategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY lesson_categories_lessoncategory
    ADD CONSTRAINT lesson_categories_lessoncategory_pkey PRIMARY KEY (id);


--
-- Name: lesson_categories_lessoncategoryunit_name_53faa7420e97268c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY lesson_categories_lessoncategoryunit
    ADD CONSTRAINT lesson_categories_lessoncategoryunit_name_53faa7420e97268c_uniq UNIQUE (name, lesson_category_id);


--
-- Name: lesson_categories_lessoncategoryunit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY lesson_categories_lessoncategoryunit
    ADD CONSTRAINT lesson_categories_lessoncategoryunit_pkey PRIMARY KEY (id);


--
-- Name: lesson_categories_lessoncategoryunitt_name_4c3a9cd51a7aad0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY lesson_categories_lessoncategoryunittopic
    ADD CONSTRAINT lesson_categories_lessoncategoryunitt_name_4c3a9cd51a7aad0_uniq UNIQUE (name, lesson_category_unit_id);


--
-- Name: lesson_categories_lessoncategoryunittopic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY lesson_categories_lessoncategoryunittopic
    ADD CONSTRAINT lesson_categories_lessoncategoryunittopic_pkey PRIMARY KEY (id);


--
-- Name: lesson_categories_lessonlevel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY lesson_categories_lessonlevel
    ADD CONSTRAINT lesson_categories_lessonlevel_pkey PRIMARY KEY (id);


--
-- Name: places_city_Name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_city
    ADD CONSTRAINT "places_city_Name_key" UNIQUE ("Name");


--
-- Name: places_city_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_city
    ADD CONSTRAINT places_city_pkey PRIMARY KEY (id);


--
-- Name: places_region_Name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_region
    ADD CONSTRAINT "places_region_Name_key" UNIQUE ("Name");


--
-- Name: places_region_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_region
    ADD CONSTRAINT places_region_pkey PRIMARY KEY (id);


--
-- Name: places_state_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_state
    ADD CONSTRAINT places_state_pkey PRIMARY KEY (id);


--
-- Name: questions_contentprovider_name_1c98216374edd119_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY questions_contentprovider
    ADD CONSTRAINT questions_contentprovider_name_1c98216374edd119_uniq UNIQUE (name);


--
-- Name: questions_contentprovider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY questions_contentprovider
    ADD CONSTRAINT questions_contentprovider_pkey PRIMARY KEY (id);


--
-- Name: questions_question_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY questions_question
    ADD CONSTRAINT questions_question_pkey PRIMARY KEY (id);


--
-- Name: questions_questionattachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY questions_questionattachment
    ADD CONSTRAINT questions_questionattachment_pkey PRIMARY KEY (id);


--
-- Name: questions_questionlessoncategoryunittopic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY questions_questionlessoncategoryunittopic
    ADD CONSTRAINT questions_questionlessoncategoryunittopic_pkey PRIMARY KEY (id);


--
-- Name: settings_setting_code_key; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY settings_setting
    ADD CONSTRAINT settings_setting_code_key UNIQUE (code);


--
-- Name: settings_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY settings_setting
    ADD CONSTRAINT settings_setting_pkey PRIMARY KEY (id);


--
-- Name: social_auth_association_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY social_auth_association
    ADD CONSTRAINT social_auth_association_pkey PRIMARY KEY (id);


--
-- Name: social_auth_association_server_url_handle_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY social_auth_association
    ADD CONSTRAINT social_auth_association_server_url_handle_key UNIQUE (server_url, handle);


--
-- Name: social_auth_nonce_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY social_auth_nonce
    ADD CONSTRAINT social_auth_nonce_pkey PRIMARY KEY (id);


--
-- Name: social_auth_nonce_server_url_timestamp_salt_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY social_auth_nonce
    ADD CONSTRAINT social_auth_nonce_server_url_timestamp_salt_key UNIQUE (server_url, "timestamp", salt);


--
-- Name: social_auth_usersocialauth_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY social_auth_usersocialauth
    ADD CONSTRAINT social_auth_usersocialauth_pkey PRIMARY KEY (id);


--
-- Name: social_auth_usersocialauth_provider_uid_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY social_auth_usersocialauth
    ADD CONSTRAINT social_auth_usersocialauth_provider_uid_key UNIQUE (provider, uid);


--
-- Name: subscriptions_subscr_subscription_type_id_249cf369ed4efe54_uniq; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY subscriptions_subscription
    ADD CONSTRAINT subscriptions_subscr_subscription_type_id_249cf369ed4efe54_uniq UNIQUE (subscription_type_id, user_id);


--
-- Name: subscriptions_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY subscriptions_subscription
    ADD CONSTRAINT subscriptions_subscription_pkey PRIMARY KEY (id);


--
-- Name: subscriptions_subscriptiontype_name_key; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY subscriptions_subscriptiontype
    ADD CONSTRAINT subscriptions_subscriptiontype_name_key UNIQUE (name);


--
-- Name: subscriptions_subscriptiontype_pkey; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY subscriptions_subscriptiontype
    ADD CONSTRAINT subscriptions_subscriptiontype_pkey PRIMARY KEY (id);


--
-- Name: subscriptions_subscriptiontypepackage_name_key; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY subscriptions_subscriptiontypepackage
    ADD CONSTRAINT subscriptions_subscriptiontypepackage_name_key UNIQUE (name);


--
-- Name: subscriptions_subscriptiontypepackage_pkey; Type: CONSTRAINT; Schema: public; Owner: fordjango; Tablespace: 
--

ALTER TABLE ONLY subscriptions_subscriptiontypepackage
    ADD CONSTRAINT subscriptions_subscriptiontypepackage_pkey PRIMARY KEY (id);


--
-- Name: thumbnail_kvstore_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY thumbnail_kvstore
    ADD CONSTRAINT thumbnail_kvstore_pkey PRIMARY KEY (key);


--
-- Name: user_conf_student_activation_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_conf_student
    ADD CONSTRAINT user_conf_student_activation_code_key UNIQUE (activation_code);


--
-- Name: user_conf_student_password_activation_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_conf_student
    ADD CONSTRAINT user_conf_student_password_activation_key UNIQUE (password_activation);


--
-- Name: user_conf_student_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_conf_student
    ADD CONSTRAINT user_conf_student_pkey PRIMARY KEY (id);


--
-- Name: user_conf_student_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_conf_student
    ADD CONSTRAINT user_conf_student_user_id_key UNIQUE (user_id);


--
-- Name: auth_group_name_6d8efc43da7ed9b8_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_name_6d8efc43da7ed9b8_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_3a68ee0bde9a986e_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_username_3a68ee0bde9a986e_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_20d3ae3d3834a58_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_session_key_20d3ae3d3834a58_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: exam_packages_exampackage_exam_09631ec7; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX exam_packages_exampackage_exam_09631ec7 ON exam_packages_exampackage_exam USING btree (exam_id);


--
-- Name: exam_packages_exampackage_exam_43b4d53c; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX exam_packages_exampackage_exam_43b4d53c ON exam_packages_exampackage_exam USING btree (exampackage_id);


--
-- Name: exam_packages_exampackage_name_486d2d1f851cc790_like; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX exam_packages_exampackage_name_486d2d1f851cc790_like ON exam_packages_exampackage USING btree (name varchar_pattern_ops);


--
-- Name: exams_exam_3c30d0a5; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_exam_3c30d0a5 ON exams_exam USING btree (published_user_id);


--
-- Name: exams_exam_7933c674; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_exam_7933c674 ON exams_exam USING btree (exam_type_id);


--
-- Name: exams_exam_8ae5f5c0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_exam_8ae5f5c0 ON exams_exam USING btree (created_user_id);


--
-- Name: exams_examquestion_09631ec7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_examquestion_09631ec7 ON exams_examquestion USING btree (exam_id);


--
-- Name: exams_examquestion_41f92c4c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_examquestion_41f92c4c ON exams_examquestion USING btree (exam_type_sub_head_id);


--
-- Name: exams_examquestion_6c2421bd; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_examquestion_6c2421bd ON exams_examquestion USING btree (exam_type_sub_head_topic_id);


--
-- Name: exams_examquestion_7aa0f6ee; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_examquestion_7aa0f6ee ON exams_examquestion USING btree (question_id);


--
-- Name: exams_examquestion_dbc0f9e4; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_examquestion_dbc0f9e4 ON exams_examquestion USING btree (assign_user_id);


--
-- Name: exams_examtypesubhead_7933c674; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_examtypesubhead_7933c674 ON exams_examtypesubhead USING btree (exam_type_id);


--
-- Name: exams_examtypesubheadtopic_41f92c4c; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_examtypesubheadtopic_41f92c4c ON exams_examtypesubheadtopic USING btree (exam_type_sub_head_id);


--
-- Name: exams_examtypesubheadtopic_80306310; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_examtypesubheadtopic_80306310 ON exams_examtypesubheadtopic USING btree (lesson_category_unit_topic_id);


--
-- Name: exams_studentexam_09631ec7; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_studentexam_09631ec7 ON exams_studentexam USING btree (exam_id);


--
-- Name: exams_studentexam_30a811f6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_studentexam_30a811f6 ON exams_studentexam USING btree (student_id);


--
-- Name: exams_studentexamanswer_7aa0f6ee; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_studentexamanswer_7aa0f6ee ON exams_studentexamanswer USING btree (question_id);


--
-- Name: exams_studentexamanswer_95427a7d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX exams_studentexamanswer_95427a7d ON exams_studentexamanswer USING btree (student_exam_id);


--
-- Name: lesson_categories_lessoncategory_7f25b9e6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX lesson_categories_lessoncategory_7f25b9e6 ON lesson_categories_lessoncategory USING btree (lesson_level_id);


--
-- Name: lesson_categories_lessoncategoryunit_879c716d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX lesson_categories_lessoncategoryunit_879c716d ON lesson_categories_lessoncategoryunit USING btree (lesson_category_id);


--
-- Name: lesson_categories_lessoncategoryunittopic_989582a8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX lesson_categories_lessoncategoryunittopic_989582a8 ON lesson_categories_lessoncategoryunittopic USING btree (lesson_category_unit_id);


--
-- Name: places_city_Name_6f8d41d258d4976b_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "places_city_Name_6f8d41d258d4976b_like" ON places_city USING btree ("Name" varchar_pattern_ops);


--
-- Name: places_city_ed3f663b; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX places_city_ed3f663b ON places_city USING btree ("Region_id");


--
-- Name: places_region_Name_371ef3b2dcd90dee_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "places_region_Name_371ef3b2dcd90dee_like" ON places_region USING btree ("Name" varchar_pattern_ops);


--
-- Name: places_state_2848fb6d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX places_state_2848fb6d ON places_state USING btree ("City_id");


--
-- Name: questions_question_0c54e209; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX questions_question_0c54e209 ON questions_question USING btree (last_updated_user_id);


--
-- Name: questions_question_8ae5f5c0; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX questions_question_8ae5f5c0 ON questions_question USING btree (created_user_id);


--
-- Name: questions_question_f377ae07; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX questions_question_f377ae07 ON questions_question USING btree (content_provider_id);


--
-- Name: questions_questionattachment_7aa0f6ee; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX questions_questionattachment_7aa0f6ee ON questions_questionattachment USING btree (question_id);


--
-- Name: questions_questionlessoncategoryunittopic_7aa0f6ee; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX questions_questionlessoncategoryunittopic_7aa0f6ee ON questions_questionlessoncategoryunittopic USING btree (question_id);


--
-- Name: questions_questionlessoncategoryunittopic_7f25b9e6; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX questions_questionlessoncategoryunittopic_7f25b9e6 ON questions_questionlessoncategoryunittopic USING btree (lesson_level_id);


--
-- Name: questions_questionlessoncategoryunittopic_80306310; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX questions_questionlessoncategoryunittopic_80306310 ON questions_questionlessoncategoryunittopic USING btree (lesson_category_unit_topic_id);


--
-- Name: questions_questionlessoncategoryunittopic_879c716d; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX questions_questionlessoncategoryunittopic_879c716d ON questions_questionlessoncategoryunittopic USING btree (lesson_category_id);


--
-- Name: questions_questionlessoncategoryunittopic_989582a8; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX questions_questionlessoncategoryunittopic_989582a8 ON questions_questionlessoncategoryunittopic USING btree (lesson_category_unit_id);


--
-- Name: settings_setting_code_37516ccf71c0a060_like; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX settings_setting_code_37516ccf71c0a060_like ON settings_setting USING btree (code varchar_pattern_ops);


--
-- Name: social_auth_association_issued; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX social_auth_association_issued ON social_auth_association USING btree (issued);


--
-- Name: social_auth_nonce_timestamp; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX social_auth_nonce_timestamp ON social_auth_nonce USING btree ("timestamp");


--
-- Name: social_auth_usersocialauth_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX social_auth_usersocialauth_user_id ON social_auth_usersocialauth USING btree (user_id);


--
-- Name: subscriptions_subscription_e8701ad4; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX subscriptions_subscription_e8701ad4 ON subscriptions_subscription USING btree (user_id);


--
-- Name: subscriptions_subscription_e9b67ea9; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX subscriptions_subscription_e9b67ea9 ON subscriptions_subscription USING btree (subscription_type_id);


--
-- Name: subscriptions_subscriptiontype_name_1f557dc4de3e1420_like; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX subscriptions_subscriptiontype_name_1f557dc4de3e1420_like ON subscriptions_subscriptiontype USING btree (name varchar_pattern_ops);


--
-- Name: subscriptions_subscriptiontypepackag_name_12c4febffe65ff7d_like; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX subscriptions_subscriptiontypepackag_name_12c4febffe65ff7d_like ON subscriptions_subscriptiontypepackage USING btree (name varchar_pattern_ops);


--
-- Name: subscriptions_subscriptiontypepackage_301e3c17; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX subscriptions_subscriptiontypepackage_301e3c17 ON subscriptions_subscriptiontypepackage USING btree (class_id);


--
-- Name: subscriptions_subscriptiontypepackage_e9b67ea9; Type: INDEX; Schema: public; Owner: fordjango; Tablespace: 
--

CREATE INDEX subscriptions_subscriptiontypepackage_e9b67ea9 ON subscriptions_subscriptiontypepackage USING btree (subscription_type_id);


--
-- Name: thumbnail_kvstore_key_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX thumbnail_kvstore_key_like ON thumbnail_kvstore USING btree (key varchar_pattern_ops);


--
-- Name: user_conf_student_84566833; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX user_conf_student_84566833 ON user_conf_student USING btree (role_id);


--
-- Name: user_conf_student_activation_code_45bb96fd2f8133b_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX user_conf_student_activation_code_45bb96fd2f8133b_like ON user_conf_student USING btree (activation_code varchar_pattern_ops);


--
-- Name: user_conf_student_c7141997; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX user_conf_student_c7141997 ON user_conf_student USING btree (city_id);


--
-- Name: user_conf_student_d5582625; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX user_conf_student_d5582625 ON user_conf_student USING btree (state_id);


--
-- Name: user_conf_student_password_activation_7e3f94d2c5d44697_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX user_conf_student_password_activation_7e3f94d2c5d44697_like ON user_conf_student USING btree (password_activation varchar_pattern_ops);


--
-- Name: D160d7ba745cc8772fae6f405972d5d6; Type: FK CONSTRAINT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY subscriptions_subscription
    ADD CONSTRAINT "D160d7ba745cc8772fae6f405972d5d6" FOREIGN KEY (subscription_type_id) REFERENCES subscriptions_subscriptiontype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D18ac66dbb0ebedbcb909ef54ecbe47b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examtypesubheadtopic
    ADD CONSTRAINT "D18ac66dbb0ebedbcb909ef54ecbe47b" FOREIGN KEY (exam_type_sub_head_id) REFERENCES exams_examtypesubhead(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D31d39c716463919090f639f10a6873c; Type: FK CONSTRAINT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY exam_packages_exampackage_exam
    ADD CONSTRAINT "D31d39c716463919090f639f10a6873c" FOREIGN KEY (exampackage_id) REFERENCES exam_packages_exampackage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D3ec9a9d660317f09f856e4fc67a020a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examquestion
    ADD CONSTRAINT "D3ec9a9d660317f09f856e4fc67a020a" FOREIGN KEY (exam_type_sub_head_topic_id) REFERENCES exams_examtypesubheadtopic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D6414ff434a7c087937c716705d0d64e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examquestion
    ADD CONSTRAINT "D6414ff434a7c087937c716705d0d64e" FOREIGN KEY (exam_type_sub_head_id) REFERENCES exams_examtypesubhead(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D68cd6c88af90217c719f8c6abb4bf52; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_questionlessoncategoryunittopic
    ADD CONSTRAINT "D68cd6c88af90217c719f8c6abb4bf52" FOREIGN KEY (lesson_level_id) REFERENCES lesson_categories_lessonlevel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D6c15c93aaeadbd5c09cd84c067103b8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_questionlessoncategoryunittopic
    ADD CONSTRAINT "D6c15c93aaeadbd5c09cd84c067103b8" FOREIGN KEY (lesson_category_id) REFERENCES lesson_categories_lessoncategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D6f884fda40eff54c5bc3410ef045a2b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_questionlessoncategoryunittopic
    ADD CONSTRAINT "D6f884fda40eff54c5bc3410ef045a2b" FOREIGN KEY (lesson_category_unit_topic_id) REFERENCES lesson_categories_lessoncategoryunittopic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D9b496c0c7c939e1435d22bd352e260f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lesson_categories_lessoncategoryunit
    ADD CONSTRAINT "D9b496c0c7c939e1435d22bd352e260f" FOREIGN KEY (lesson_category_id) REFERENCES lesson_categories_lessoncategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: a3a6b481bbf625cdb15abc6d121f2314; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examtypesubheadtopic
    ADD CONSTRAINT a3a6b481bbf625cdb15abc6d121f2314 FOREIGN KEY (lesson_category_unit_topic_id) REFERENCES lesson_categories_lessoncategoryunittopic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: a6136ef4bbe78cd16a1a6dbced787228; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lesson_categories_lessoncategoryunittopic
    ADD CONSTRAINT a6136ef4bbe78cd16a1a6dbced787228 FOREIGN KEY (lesson_category_unit_id) REFERENCES lesson_categories_lessoncategoryunit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth__content_type_id_380bc89e8bc7621_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth__content_type_id_380bc89e8bc7621_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_group_id_781159fd002ae6c9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_781159fd002ae6c9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_2c402f4b5b0acc7c_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_2c402f4b5b0acc7c_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user__permission_id_16815eb5434ecab0_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user__permission_id_16815eb5434ecab0_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_c19f4fdca7cd9f7_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_c19f4fdca7cd9f7_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_54cf9f8eecb77b50_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_54cf9f8eecb77b50_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permiss_user_id_3d17f0d392de7556_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permiss_user_id_3d17f0d392de7556_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: b30295e201e5ba95d2085ad1056b801d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY lesson_categories_lessoncategory
    ADD CONSTRAINT b30295e201e5ba95d2085ad1056b801d FOREIGN KEY (lesson_level_id) REFERENCES lesson_categories_lessonlevel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: b7ddb3904777348b05f4479305d846d8; Type: FK CONSTRAINT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY subscriptions_subscriptiontypepackage
    ADD CONSTRAINT b7ddb3904777348b05f4479305d846d8 FOREIGN KEY (subscription_type_id) REFERENCES subscriptions_subscriptiontype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cc185c311a799022a5c2f4ff5e9f53ae; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_question
    ADD CONSTRAINT cc185c311a799022a5c2f4ff5e9f53ae FOREIGN KEY (content_provider_id) REFERENCES questions_contentprovider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_551faaa19dd7a8a3_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_551faaa19dd7a8a3_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_content_type_id_fab6cb37ad9a1a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_content_type_id_fab6cb37ad9a1a_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: e5cfb57e06699ecbf252639ad487c106; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_questionlessoncategoryunittopic
    ADD CONSTRAINT e5cfb57e06699ecbf252639ad487c106 FOREIGN KEY (lesson_category_unit_id) REFERENCES lesson_categories_lessoncategoryunit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exam_packages_exampac_exam_id_1957a56341262fb8_fk_exams_exam_id; Type: FK CONSTRAINT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY exam_packages_exampackage_exam
    ADD CONSTRAINT exam_packages_exampac_exam_id_1957a56341262fb8_fk_exams_exam_id FOREIGN KEY (exam_id) REFERENCES exams_exam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams__student_exam_id_667169f08bf8d653_fk_exams_studentexam_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_studentexamanswer
    ADD CONSTRAINT exams__student_exam_id_667169f08bf8d653_fk_exams_studentexam_id FOREIGN KEY (student_exam_id) REFERENCES exams_studentexam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_exam_created_user_id_6757a195073aba34_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_exam
    ADD CONSTRAINT exams_exam_created_user_id_6757a195073aba34_fk_auth_user_id FOREIGN KEY (created_user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_exam_exam_type_id_2407ab179ed4aaa7_fk_exams_examtype_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_exam
    ADD CONSTRAINT exams_exam_exam_type_id_2407ab179ed4aaa7_fk_exams_examtype_id FOREIGN KEY (exam_type_id) REFERENCES exams_examtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_exam_published_user_id_6b9746971c59de38_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_exam
    ADD CONSTRAINT exams_exam_published_user_id_6b9746971c59de38_fk_auth_user_id FOREIGN KEY (published_user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_exam_question_id_9ed5641940c231a_fk_questions_question_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examquestion
    ADD CONSTRAINT exams_exam_question_id_9ed5641940c231a_fk_questions_question_id FOREIGN KEY (question_id) REFERENCES questions_question(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_examquest_assign_user_id_20b64842322a8d82_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examquestion
    ADD CONSTRAINT exams_examquest_assign_user_id_20b64842322a8d82_fk_auth_user_id FOREIGN KEY (assign_user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_examquestion_exam_id_2d18c8bd098259b_fk_exams_exam_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examquestion
    ADD CONSTRAINT exams_examquestion_exam_id_2d18c8bd098259b_fk_exams_exam_id FOREIGN KEY (exam_id) REFERENCES exams_exam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_examty_exam_type_id_1748cc42d0e598e8_fk_exams_examtype_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_examtypesubhead
    ADD CONSTRAINT exams_examty_exam_type_id_1748cc42d0e598e8_fk_exams_examtype_id FOREIGN KEY (exam_type_id) REFERENCES exams_examtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_stu_question_id_33b30f9860f57c82_fk_questions_question_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_studentexamanswer
    ADD CONSTRAINT exams_stu_question_id_33b30f9860f57c82_fk_questions_question_id FOREIGN KEY (question_id) REFERENCES questions_question(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_stude_student_id_516f3b661a4f5e50_fk_user_conf_student_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_studentexam
    ADD CONSTRAINT exams_stude_student_id_516f3b661a4f5e50_fk_user_conf_student_id FOREIGN KEY (student_id) REFERENCES user_conf_student(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exams_studentexam_exam_id_199edcd4ebdf86f_fk_exams_exam_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY exams_studentexam
    ADD CONSTRAINT exams_studentexam_exam_id_199edcd4ebdf86f_fk_exams_exam_id FOREIGN KEY (exam_id) REFERENCES exams_exam(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: places_city_Region_id_3136b02105940d95_fk_places_region_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_city
    ADD CONSTRAINT "places_city_Region_id_3136b02105940d95_fk_places_region_id" FOREIGN KEY ("Region_id") REFERENCES places_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: places_state_City_id_6221430add5fe445_fk_places_city_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_state
    ADD CONSTRAINT "places_state_City_id_6221430add5fe445_fk_places_city_id" FOREIGN KEY ("City_id") REFERENCES places_city(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_last_updated_user_id_2aab28b8e77fcc2b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_question
    ADD CONSTRAINT questions_last_updated_user_id_2aab28b8e77fcc2b_fk_auth_user_id FOREIGN KEY (last_updated_user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_ques_created_user_id_7dbdef252befbb68_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_question
    ADD CONSTRAINT questions_ques_created_user_id_7dbdef252befbb68_fk_auth_user_id FOREIGN KEY (created_user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_question_id_67bdbc0dcac6365a_fk_questions_question_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_questionlessoncategoryunittopic
    ADD CONSTRAINT questions_question_id_67bdbc0dcac6365a_fk_questions_question_id FOREIGN KEY (question_id) REFERENCES questions_question(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: questions_question_id_790d4221155cf40b_fk_questions_question_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions_questionattachment
    ADD CONSTRAINT questions_question_id_790d4221155cf40b_fk_questions_question_id FOREIGN KEY (question_id) REFERENCES questions_question(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subsc_class_id_62973cf56425452c_fk_exam_packages_exampackage_id; Type: FK CONSTRAINT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY subscriptions_subscriptiontypepackage
    ADD CONSTRAINT subsc_class_id_62973cf56425452c_fk_exam_packages_exampackage_id FOREIGN KEY (class_id) REFERENCES exam_packages_exampackage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subscriptions_subscrip_user_id_57ac47f8d149cac1_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: fordjango
--

ALTER TABLE ONLY subscriptions_subscription
    ADD CONSTRAINT subscriptions_subscrip_user_id_57ac47f8d149cac1_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_conf_student_city_id_1b223ab3895cf038_fk_places_city_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_conf_student
    ADD CONSTRAINT user_conf_student_city_id_1b223ab3895cf038_fk_places_city_id FOREIGN KEY (city_id) REFERENCES places_city(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_conf_student_role_id_27d0cb9212942237_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_conf_student
    ADD CONSTRAINT user_conf_student_role_id_27d0cb9212942237_fk_auth_group_id FOREIGN KEY (role_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_conf_student_state_id_2f6caabca4c3336b_fk_places_state_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_conf_student
    ADD CONSTRAINT user_conf_student_state_id_2f6caabca4c3336b_fk_places_state_id FOREIGN KEY (state_id) REFERENCES places_state(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_conf_student_user_id_2a7edd6f196e11ac_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_conf_student
    ADD CONSTRAINT user_conf_student_user_id_2a7edd6f196e11ac_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

