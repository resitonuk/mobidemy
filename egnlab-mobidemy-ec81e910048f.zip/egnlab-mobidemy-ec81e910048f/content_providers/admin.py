from django.contrib import admin
from content_providers.models import ContentProvider

admin.site.register(ContentProvider)
