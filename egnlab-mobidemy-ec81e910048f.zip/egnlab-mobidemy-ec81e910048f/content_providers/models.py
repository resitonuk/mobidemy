from django.db import models
from django.utils.translation import ugettext_lazy as _
from lesson_categories.models import *


class ContentProvider(models.Model):

    name = models.CharField(_('content_provider_name'), max_length=60, unique=True)
    explanation = models.TextField(blank=True, null=True)

    class Meta:
        app_label = 'content_providers'
        verbose_name = _('Content Provider')
        verbose_name_plural = _('Content Providers')

    def __unicode__(self):
        return self.name
