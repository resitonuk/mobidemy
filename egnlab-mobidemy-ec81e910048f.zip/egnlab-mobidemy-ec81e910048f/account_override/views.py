import account.views
from django.core.urlresolvers import reverse
from django.http.response import HttpResponseRedirect
from django.views.generic.base import TemplateResponseMixin, View
from settings.views import current_institution
from django.contrib.auth.models import User, Group
import account_override.forms
from user_conf.models import UserExtent, Student


class SignupView(account.views.SignupView):
    form_class = account_override.forms.SignupForm

    def after_signup(self, form):
        self.create_profile(form)
        super(SignupView, self).after_signup(form)

    def create_profile(self, form):
        user_extent = UserExtent()
        user_extent.user = self.created_user
        user_extent.institution = self.request.tenant
        user_extent.save()
        group = Group.objects.get(id=2)
        self.created_user.groups.add(group)
        self.created_user.first_name = form.cleaned_data["first_name"]
        self.created_user.last_name = form.cleaned_data["last_name"]
        self.created_user.save()
        student = Student(user_id=self.created_user.id, date_of_birth = form.cleaned_data["birth_date"])
        student.save()


    def generate_username(self, form):
        # do something to generate a unique username (required by the
        # Django User model, unfortunately)
        username = form.cleaned_data["email"]
        return username
