from django.shortcuts import render
from django.template import RequestContext
from django.core.urlresolvers import reverse
from questions.views import *
from django.contrib.auth.decorators import login_required, user_passes_test
from settings.views import editor_check
from django.contrib import messages
from settings.views import current_student

# Create your views here.
def root_path(request):
    user = request.user

    if user.id:
        student = current_student(request)
    return render(request, 'institution_public_pages/index.html',locals(), context_instance=RequestContext(request))

def permission_denied(request):
    return render_to_response('institution_public_pages/permission-denied.html',locals(), context_instance=RequestContext(request))
