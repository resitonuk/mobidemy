# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('exam_packages', '0001_initial'),
        ('lesson_packages', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Subscription',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('start_date', models.DateTimeField()),
                ('active', models.BooleanField(default=False)),
                ('balance', models.DecimalField(max_digits=6, decimal_places=2)),
            ],
            options={
                'verbose_name': 'Subscription',
                'verbose_name_plural': 'Subscription',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='SubscriptionType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=100, verbose_name='subscription_type_name')),
                ('explanation', models.TextField(null=True, blank=True)),
                ('start_date', models.DateTimeField(null=True, blank=True)),
                ('end_date', models.DateTimeField(null=True, blank=True)),
                ('active', models.BooleanField(default=False)),
                ('price', models.DecimalField(default=0.0, max_digits=8, decimal_places=2)),
            ],
            options={
                'verbose_name': 'Subscription Type',
                'verbose_name_plural': 'Subscription Type',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='SubscriptionTypePackage',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('class_name', models.CharField(max_length=24, editable=False)),
                ('name', models.CharField(unique=True, max_length=100, verbose_name='subscription_type_package_name')),
                ('explanation', models.TextField(null=True, blank=True)),
                ('exam_package', models.ForeignKey(blank=True, to='exam_packages.ExamPackage', null=True)),
                ('lesson_package', models.ForeignKey(blank=True, to='lesson_packages.LessonPackage', null=True)),
                ('subscription_type', models.ForeignKey(to='subscriptions.SubscriptionType')),
            ],
            options={
                'verbose_name': 'Subscription Type Package',
                'verbose_name_plural': 'Subscription Type Package',
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='subscription',
            name='subscription_type',
            field=models.ForeignKey(to='subscriptions.SubscriptionType'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='subscription',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
            preserve_default=True,
        ),
        migrations.AlterUniqueTogether(
            name='subscription',
            unique_together=set([('subscription_type', 'user')]),
        ),
    ]
