from django.db import models
from django.utils.translation import ugettext_lazy as _
from django.db.models import Q
from exam_packages.models import *
from lesson_packages.models import LessonPackage
from user_conf.models import *


class SubscriptionType(models.Model):

    name = models.CharField(_('subscription_type_name'), max_length=100, unique=True)
    explanation = models.TextField(blank=True, null=True)
    start_date = models.DateTimeField(blank=True, null=True)
    end_date = models.DateTimeField(blank=True, null=True)
    active = models.BooleanField(default=False)
    price = models.DecimalField(default=0.00, max_digits=8, decimal_places=2)

    class Meta:
        verbose_name = _('Subscription Type')
        verbose_name_plural = _('Subscription Type')

    def __unicode__(self):
        return self.name

    @staticmethod
    def get_user_available_subscription_types(user):
        return SubscriptionType.objects.select_related('Subscription').\
            filter(active=True,
                   start_date__lte=datetime.datetime.now(),
                   end_date__gte=datetime.datetime.now(),
                   ).\
            exclude(subscription__user_id=user.id)

    @staticmethod
    def get_user_taken_subscription_types(user):
        return SubscriptionType.objects.select_related('Subscription').\
            filter(active=True,
                   subscription__user_id=user.id,
                   )


class SubscriptionTypePackage(models.Model):

    exam_package = models.ForeignKey(ExamPackage, blank=True, null=True)
    lesson_package = models.ForeignKey(LessonPackage, blank=True, null=True)
    subscription_type = models.ForeignKey(SubscriptionType)
    class_name = models.CharField(max_length=24, editable=False)
    name = models.CharField(_('subscription_type_package_name'), max_length=100, unique=True)
    explanation = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = _('Subscription Type Package')
        verbose_name_plural = _('Subscription Type Package')
        # unique_together = (("class_name", "class_id"), )

    def __unicode__(self):
        return self.name

    def save(self):
        if self.exam_package:
            self.class_name = 'ExamPackage'
        if self.lesson_package:
            self.class_name = 'LessonPackage'
        # TODO: if you have another relation, put here. Example (Another Package)
        super(SubscriptionTypePackage, self).save()


class Subscription(models.Model):

    subscription_type = models.ForeignKey(SubscriptionType)
    user = models.ForeignKey(User)
    start_date = models.DateTimeField()
    active = models.BooleanField(default=False)
    balance = models.DecimalField(max_digits=6, decimal_places=2)

    class Meta:
        verbose_name = _('Subscription')
        verbose_name_plural = _('Subscription')
        unique_together = (("subscription_type", "user"), )

    def __unicode__(self):
        return self.subscription_type.name + " - " + self.user.email

    @staticmethod
    def get_user_taken_and_active_subscriptions(user):
        return Subscription.objects.filter(active=True,
                   user_id=user.id,
                   )


    @staticmethod
    def get_user_taken_and_deactivated_subscriptions(user):
        return Subscription.objects.select_related('SubscriptionType').filter((Q(subscription_type__active=False) | Q(subscription_type__active=None)) & Q(user_id=user.id))