from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.core.urlresolvers import reverse
from django.template import RequestContext
from django.contrib import messages
from django.utils.translation import ugettext_lazy as _
from subscriptions.models import SubscriptionType
from subscriptions.models import Subscription
from settings.permission_required import student_login_required
from settings.views import current_student
import datetime


@student_login_required
def available_and_taken_subscription_list(request):
    available_subscription_types = SubscriptionType.get_user_available_subscription_types(request.user)
    taken_and_active_subscriptions = Subscription.get_user_taken_and_active_subscriptions(request.user)
    taken_and_deactivated_subscriptions = Subscription.get_user_taken_and_deactivated_subscriptions(request.user)
    return render_to_response('subscriptions/available_and_taken_subscriptions.html', locals(), context_instance=RequestContext(request))


@student_login_required
def available_subscription_show(request, subscription_type_id):
    user = request.user
    student = current_student(request)
    subscription_type = get_object_or_404(SubscriptionType.get_user_available_subscription_types(request.user), id=subscription_type_id)
    return render_to_response('subscriptions/available_subscription.html', locals(), context_instance=RequestContext(request))


@student_login_required
def taken_subscription_show(request, subscription_id):
    user = request.user
    student = current_student(request)
    subscription = get_object_or_404(Subscription.get_user_taken_and_active_subscriptions(request.user), id=subscription_id)
    subscription_type = subscription.subscription_type
    return render_to_response('subscriptions/taken_subscription.html', locals(), context_instance=RequestContext(request))


@student_login_required
def subscribe_now(request, subscription_type_id):
    user = request.user
    student = current_student(request)
    subscription_type = get_object_or_404(SubscriptionType.get_user_available_subscription_types(request.user), id=subscription_type_id)
    if request.POST:
        if True: # TODO: Payment method put to here
            subscription = Subscription()
            subscription.subscription_type_id = subscription_type.id
            subscription.user_id = request.user.id
            subscription.start_date = datetime.datetime.now()
            subscription.active = True
            subscription.balance = 0.00
            subscription.save()
            return HttpResponseRedirect(reverse('taken_subscription_show_path', kwargs={'subscription_id': subscription.id}))
        else:
            return render_to_response('subscriptions/available_subscription.html', locals(), context_instance=RequestContext(request))
    else:
        # TODO: Credit card form and page requirements should be here.
        return render_to_response('subscriptions/subscribe_now.html', locals(), context_instance=RequestContext(request))

