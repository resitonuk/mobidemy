from django.contrib import admin
from subscriptions.models import *

class SubscriptionTypePackageInline(admin.TabularInline):
    model = SubscriptionTypePackage
    extra = 1

class SubscriptionTypeAdmin(admin.ModelAdmin):
    inlines = [
        SubscriptionTypePackageInline,
    ]


admin.site.register(SubscriptionType, SubscriptionTypeAdmin)
admin.site.register(SubscriptionTypePackage)
admin.site.register(Subscription)
