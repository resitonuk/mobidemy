from django.db import models
from django.utils.translation import ugettext_lazy as _
from tenant_schemas.models import TenantMixin


class Institution(TenantMixin):
    code_name = models.CharField(max_length=60, verbose_name=_('Code name'))
    name = models.CharField(max_length=100, verbose_name=_('Name'))
    admin_email = models.CharField(max_length=60, blank=True, null=True, verbose_name=_('Admin email'))
    domain = models.CharField(max_length=60, blank=True, null=True, verbose_name=_('Domain'))
    sub_domain = models.CharField(max_length=60, blank=True, null=True, verbose_name=_('Sub domain'))
    paid_until =  models.DateField(blank=True, null=True, verbose_name=_('Paid until'))
    on_trial = models.BooleanField(default=True, verbose_name=_('On trial'))
    created_on = models.DateField(auto_now_add=True, verbose_name=_('Created on'))

    # default true, schema will be automatically created and synced when it is saved
    auto_create_schema = True


