from django import template
from django.core.cache import cache
from exam_reports.models import *

register = template.Library()

def find_answer_in_student_exam_answers(student_exam_answers, question):
    student_exam_answer_list = list(student_exam_answers)
    answer = None
    for student_exam_answer in student_exam_answer_list:
        if student_exam_answer.question_id == question.id:
            answer = student_exam_answer
            break
    return answer


@register.filter
def exam_assigned_questions_with_exam_sub_head_filter(exam_type_sub_head, exam):
    return exam_type_sub_head.assigned_questions_with_exam(exam)


@register.filter
def student_exam_answer_choice_index_with_question_filter(student_exam_answers, question):
    try:
        return find_answer_in_student_exam_answers(student_exam_answers, question).answer_index_number
    except:
        return None


@register.filter
def correct_question_count_with_exam_sub_head_filter(exam_type_sub_head, student_exam):
    return StudentReport.get_correct_answers_with_student_exam(exam_type_sub_head, student_exam).count()


@register.filter
def incorrect_question_count_with_exam_sub_head_filter(exam_type_sub_head, student_exam):
    return StudentReport.get_incorrect_answers_with_student_exam(exam_type_sub_head, student_exam).count()



@register.filter
def blank_question_count_with_exam_sub_head_filter(exam_type_sub_head, student_exam):
    return StudentReport.get_blank_answers_with_student_exam(exam_type_sub_head, student_exam).count()


@register.simple_tag
def student_exam_answer_total_spent_minutes_with_question(student_exam_answers, question):
    try:
        return find_answer_in_student_exam_answers(student_exam_answers, question).total_spent_seconds / 60
    except:
        return None


@register.simple_tag
def student_exam_answer_view_count_with_question(student_exam_answers, question):
    try:
        return find_answer_in_student_exam_answers(student_exam_answers, question).total_viewed_times
    except:
        return None


@register.simple_tag
def set_counter(value, id):
    value = cache.set('num' + str(id), value)
    return ''

@register.simple_tag
def delete_counter(id):
    cache.delete('num' + str(id))
    return ''


@register.simple_tag
def increment_counter(id):
    cache.incr('num' + str(id))
    value = cache.get('num' + str(id))
    return value