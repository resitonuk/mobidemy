from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.core.urlresolvers import reverse
from django.template import RequestContext
from django.contrib import messages
from django.utils.translation import ugettext_lazy as _
from exams.models import Exam
from exams.models import StudentExam
from online_exam.models import OnlineExam
from settings.views import current_student
from settings.permission_required import student_login_required

