from django.db import models
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from django.db.models import Q
from user_conf.models import *
from lesson_categories.models import *
from questions.models import *
from exams.models import *


class StudentReport:

    @staticmethod
    def get_correct_answers_with_student_exam(exam_type_sub_head, student_exam):
        list =  StudentExamAnswer.objects.extra(
            tables=['questions_question', 'exams_examquestion'],
            where=[
                '"exams_studentexamanswer"."question_id"="questions_question"."id"',
                '"exams_studentexamanswer"."question_id"="exams_examquestion"."question_id"',
                '"exams_studentexamanswer"."answer_index_number"="questions_question"."correct_choice_index"',
                '"exams_examquestion"."exam_id"=' + str(student_exam.exam_id),
                '"exams_examquestion"."exam_type_sub_head_id"=' + str(exam_type_sub_head.id)
            ]
        ).filter(student_exam_id=student_exam.id)
        return list

    @staticmethod
    def get_incorrect_answers_with_student_exam(exam_type_sub_head, student_exam):
        list =  StudentExamAnswer.objects.extra(
            tables=['questions_question', 'exams_examquestion'],
            where=[
                '"exams_studentexamanswer"."question_id"="questions_question"."id"',
                '"exams_studentexamanswer"."question_id"="exams_examquestion"."question_id"',
                '"exams_studentexamanswer"."answer_index_number"!="questions_question"."correct_choice_index"',
                '"exams_studentexamanswer"."answer_index_number" IS NOT NULL',
                '"exams_examquestion"."exam_id"=' + str(student_exam.exam_id),
                '"exams_examquestion"."exam_type_sub_head_id"=' + str(exam_type_sub_head.id)
            ]
        ).filter(student_exam_id=student_exam.id)
        return list


    @staticmethod
    def get_blank_answers_with_student_exam(exam_type_sub_head, student_exam):
        list =  StudentExamAnswer.objects.extra(
            tables=['questions_question', 'exams_examquestion'],
            where=[
                '"exams_studentexamanswer"."question_id"="questions_question"."id"',
                '"exams_studentexamanswer"."question_id"="exams_examquestion"."question_id"',
                '"exams_studentexamanswer"."answer_index_number" IS NULL',
                '"exams_examquestion"."exam_id"=' + str(student_exam.exam_id),
                '"exams_examquestion"."exam_type_sub_head_id"=' + str(exam_type_sub_head.id)
            ]
        ).filter(student_exam_id=student_exam.id)
        return list
