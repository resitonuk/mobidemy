# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext as _ 
from django.template.defaultfilters import slugify 
from django.conf import settings
import datetime , os
from django.contrib.auth.models import User, Group
from django.conf import settings
from django.contrib.auth.backends import ModelBackend
from django.core.exceptions import ImproperlyConfigured
from django.db.models import get_model
from django import forms

class string_with_title(str):
    def __new__(cls, value, title):
        instance = str.__new__(cls, value)
        instance._title = title
        return instance

    def title(self):
        return self._title

    __copy__ = lambda self: self
    __deepcopy__ = lambda self, memodict: self


class Region(models.Model):
    
    Name = models.CharField(blank=True,null=True,max_length=200, verbose_name="Coğrafi Bölge",unique=True)
    
    class Meta:
        verbose_name_plural = 'Coğrafi Bölgeler'
        verbose_name = 'Coğrafi Bölge'
        app_label = string_with_title("places", u"Yerleşim Alanları")
        ordering = ['Name']
        
    def __unicode__(self):
        return self.Name

    
class City(models.Model):
    
    Region = models.ForeignKey('Region', verbose_name="Coğrafi Bölge",blank=True,null=True)
    Name = models.CharField(blank=True,null=True,max_length=200,unique=True, verbose_name="Adı")
    
    class Meta:
        verbose_name_plural = 'İller'
        verbose_name = 'İl'
        app_label = string_with_title("places", u"Yerleşim Alanları")
        ordering = ['Name']
        
    def __unicode__(self):
        return self.Name


class State(models.Model):
    
    City = models.ForeignKey('City', verbose_name="İl",blank=True,null=True,)
    Name = models.CharField(blank=True,null=True,max_length=200, verbose_name="İlçe")
    
    class Meta:
        verbose_name_plural = 'İlçeler'
        verbose_name = 'İlçe'
        app_label = string_with_title("places", u"Yerleşim Alanları")
        ordering = ['Name']
        
    def __unicode__(self):
        return self.Name

