# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='City',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('Name', models.CharField(max_length=200, unique=True, null=True, verbose_name=b'Ad\xc4\xb1', blank=True)),
            ],
            options={
                'ordering': ['Name'],
                'verbose_name': '\u0130l',
                'verbose_name_plural': '\u0130ller',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Region',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('Name', models.CharField(max_length=200, unique=True, null=True, verbose_name=b'Co\xc4\x9frafi B\xc3\xb6lge', blank=True)),
            ],
            options={
                'ordering': ['Name'],
                'verbose_name': 'Co\u011frafi B\xf6lge',
                'verbose_name_plural': 'Co\u011frafi B\xf6lgeler',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='State',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('Name', models.CharField(max_length=200, null=True, verbose_name=b'\xc4\xb0l\xc3\xa7e', blank=True)),
                ('City', models.ForeignKey(verbose_name=b'\xc4\xb0l', blank=True, to='places.City', null=True)),
            ],
            options={
                'ordering': ['Name'],
                'verbose_name': '\u0130l\xe7e',
                'verbose_name_plural': '\u0130l\xe7eler',
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='city',
            name='Region',
            field=models.ForeignKey(verbose_name=b'Co\xc4\x9frafi B\xc3\xb6lge', blank=True, to='places.Region', null=True),
            preserve_default=True,
        ),
    ]
