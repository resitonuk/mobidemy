# -*- coding: utf-8 -*-

from places.models import *
from django.contrib import admin
from django.forms import TextInput, Textarea,ModelForm
from django.forms import ModelForm


class AdminRegion(admin.ModelAdmin):
    
    list_display = ('Name',)
    list_display_links = ('Name',)
    list_filter = ('Name',)
    search_fields = ['Name',]

class AdminCity(admin.ModelAdmin):
    
    list_display = ('Name','Region',)
    list_display_links = ('Name','Region',)
    list_filter = ('Region',)
    search_fields = ['Name','Region',]
    
    
class AdminState(admin.ModelAdmin):
    
    list_display = ('Name','City',)
    list_display_links = ('Name','City',)
    list_filter = ('City',)
    search_fields = ['Name','City',]


admin.site.register(Region,AdminRegion)
admin.site.register(City,AdminCity)
admin.site.register(State,AdminState)
 