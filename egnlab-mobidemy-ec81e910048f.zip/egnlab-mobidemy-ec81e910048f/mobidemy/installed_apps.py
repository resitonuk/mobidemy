SHARED_APPS = (
    'tenant_schemas',  # mandatory
    'institutions', # you must list the app where your tenant model resides in

    'suit',
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django_tables2',
    'storages',
    'djrill',
    'bootstrap3',
    'user_conf',
    'social_auth',
    'admin_reorder',
    'sorl.thumbnail',
    "account",
    "account_override",
    'places',
    'public_site',
    'management',
)

TENANT_APPS = (
    # The following Django contrib apps must be in TENANT_APPS
    'django.contrib.contenttypes',

    # your tenant-specific apps
    'content_providers',
    'questions',
    'exams',
    'lesson_categories',
    'online_exam',
    'settings',
    'exam_reports',
    'exam_packages',
    'subscriptions',
    'lessons',
    'videos',
    'quizzes',
    'online_quiz',
    'lesson_packages',
    'institution_public_pages',
    'student',
)

INSTALLED_APPS = list(set(SHARED_APPS + TENANT_APPS))

TENANT_MODEL = "institutions.Institution"
