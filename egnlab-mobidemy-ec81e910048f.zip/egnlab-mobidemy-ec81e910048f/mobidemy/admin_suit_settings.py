# -*- coding: utf-8 -*-
ugettext = lambda s: s

ADMIN_REORDER = (

    {'app': 'auth', 'label': u'Kullanıcı Hesapları'},
    {'app': 'user_conf', 'label': u'Kullanıcı Profilleri'},
    {'app': 'places', 'label': u'Yerleşim Alanları'},
    {'app': 'exams', 'label': ugettext('Exams'), 'models': (
        'exams.ExamType',
        'exams.ExamTypeSubHead',
        'exams.ExamTypeSubHeadTopic',
        'exams.Exam',
    )},
    {'app': 'lesson_categories', 'label': ugettext('Lesson Categories'), 'models': (
        'lesson_categories.LessonCategory',
        'lesson_categories.LessonCategoryUnit',
        'lesson_categories.LessonCategoryUnitTopic',
        'lesson_categories.LessonLevel',
    )},
    {'app': 'content_providers', 'label': ugettext('Content Providers')},
    {'app': 'questions', 'label': ugettext('Questions'), 'models': (
            'questions.Question',
    )},
    {'app': 'settings', 'label': ugettext('settings')},
    {'app': 'exam_packages', 'label': ugettext('Exam Packages')},
    {'app': 'subscriptions', 'label': ugettext('Subscriptions')},
    {'app': 'lessons', 'label': ugettext('Lessons')},
    {'app': 'videos', 'label': ugettext('Videos')},
    {'app': 'quizzes', 'label': ugettext('Quizzes')},
    {'app': 'lesson_packages', 'label': ugettext('Lesson Package')},
)

SUIT_CONFIG = {
    'ADMIN_NAME': 'Mobidemy Yönetim Paneli',
    'LIST_PER_PAGE': 20,
    'SHOW_REQUIRED_ASTERISK': True,
    'MENU': (
        {'app': 'auth', 'label': u'Kullanıcı Hesapları'},
        #{'app': 'social_auth', 'label': u'Facebook Kullanıcıları', 'icon':'icon-user'},
        {'app': 'user_conf', 'label': u'Kullanıcı Profilleri', 'icon':'icon-user'},

        {'app': 'places', 'label': u'Yerleşim Alanları', 'icon':'icon-globe'},
        '-',
        {'app': 'exams', 'label': ugettext('Exams'), 'models': (
            'exams.ExamType',
            'exams.ExamTypeSubHead',
            'exams.ExamTypeSubHeadTopic',
            'exams.Exam',
        )},
        {'app': 'lesson_categories', 'label': ugettext('Lesson Categories'), 'models': (
            'lesson_categories.LessonCategory',
            'lesson_categories.LessonCategoryUnit',
            'lesson_categories.LessonCategoryUnitTopic',
            'lesson_categories.LessonLevel',
        )},
        {'app': 'content_providers', 'label': ugettext('Content Providers')},
        {'app': 'questions', 'label': ugettext('Questions'), 'models': (
            'questions.Question',
        )},
        {'app': 'settings', 'label': ugettext('settings')},
        {'app': 'exam_packages', 'label': ugettext('Exam Packages')},
        {'app': 'subscriptions', 'label': ugettext('Subscriptions')},
        {'app': 'lessons', 'label': ugettext('Lessons')},
        {'app': 'videos', 'label': ugettext('Videos')},
        {'app': 'quizzes', 'label': ugettext('Quizzes')},
        {'app': 'lesson_packages', 'label': ugettext('Lesson Package')},
    )
}
