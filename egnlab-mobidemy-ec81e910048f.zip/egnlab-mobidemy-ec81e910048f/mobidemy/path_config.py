import os

### Paths ###

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
BASE_PATH = os.path.join(BASE_DIR, os.path.dirname(__file__))

MEDIA_ROOT = os.path.join(BASE_PATH, 'media')

MEDIA_URL = '/media/'

STATIC_ROOT = os.path.join(BASE_PATH, 'assets')

STATIC_URL = '/assets/'

STATICFILES_DIRS = (
    os.path.join(BASE_PATH, 'static'),
)

#STATICFILES_STORAGE = 'whitenoise.django.GzipManifestStaticFilesStorage'

TEMPLATE_DIRS = (
    os.path.join(os.path.dirname(__file__), 'templates'),
)

LOCALE_PATHS = (
    os.path.join(os.path.dirname(__file__), 'locales'),
)

STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
    # other finders..
)

### Paths end ###
