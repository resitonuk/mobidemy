#DEFAULT_FILE_STORAGE = 'storages.backends.s3boto.S3BotoStorage'
AWS_APPLICATION_PATH = 'mobidemy-dev/'
AWS_S3_CUSTOM_DOMAIN = 's3-eu-west-1.amazonaws.com/egnity'
AWS_ACCESS_KEY_ID = 'AKIAJXGW4S3EO54SDNHA'
AWS_SECRET_ACCESS_KEY = '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'
AWS_STORAGE_BUCKET_NAME = 'egnity'

# TODO: Aws images and file should have size limitation.