# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from account.context_processors import account
from django.conf.urls import patterns, include, url
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.views.generic import TemplateView
from management.views import new_institution, institution_list, institution_show, management_index
from user_conf.views import *
from social_auth.views import auth, complete, disconnect
from questions.views import *
from public_site.views import *
from exams.views import *
from online_exam.views import *
from exam_reports.views import *
from subscriptions.views import *
from account_override.views import *
from student.views import student_root_path, available_exam_list, total_results, student_exam_report, student_exam_show


urlpatterns = patterns('',

    url(r'^login_redirect_router/$', login_redirect_router, name='login_redirect_router_path'),
    url(r'^admin/', include(admin.site.urls)), #admin sayfası template url'leri.
    url(r'^$', root_path, name='root_path'),
    url(r'^editor/$', editor_root_path, name='editor_root_path'),
    (r'^secret-answer/$', secret_answer),
    url(r'^permission-denied/$', permission_denied, name='permission_denied'),
    url(r'^profile/$', profile, name='profile_path'),
    url(r'', include('social_auth.urls')),#facebook login url
    url(r'^complete/(?P<backend>[^/]+)/$', complete,name='socialauth_complete'),
    url(r'^profile-facebook/$', new_facebook_user),

    url(r"^account/signup/$", SignupView.as_view(), name="account_signup"),
    url(r"^account/", include("account.urls")),

    ### Management url ###

    url(r'^management/$', management_index, name='management_root_path'),
    url(r'^management/new/$', new_institution, name='new_institution_path'),
    url(r'^management/list/$', institution_list, name='institutions_path'),
    url(r'^management/(?P<object_id>[0-9\-]+)/$', institution_show, name='institution_path'),
    url(r'^management/(?P<object_id>[0-9\-]+)/update/$', institution_show, name='update_institution_path'),

)+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

