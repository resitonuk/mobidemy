# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.conf.urls import patterns, include, url
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.views.generic import TemplateView
from public_site.views import editor_root_path, login_redirect_router
from user_conf.views import *
from social_auth.views import auth, complete, disconnect
from questions.views import *
from exams.views import *
from online_exam.views import *
from exam_reports.views import *
from subscriptions.views import *
from institution_public_pages.views import *
from student.views import student_root_path, available_exam_list, total_results, student_exam_report, student_exam_show
from account_override.views import *


urlpatterns = patterns('',

    ### Institution Public Pages Paths ###
    url(r'^login_redirect_router/$', login_redirect_router, name='login_redirect_router_path'),
    url(r'^admin/', include(admin.site.urls)), #admin sayfası template url'leri.
    url(r'^$', root_path, name='root_path'),
    url(r'^editor/$', editor_root_path, name='editor_root_path'),

    url(r'^permission-denied/$', permission_denied, name='permission_denied'),
    url(r'^profile/$', profile, name='profile_path'),
    url(r'', include('social_auth.urls')),#facebook login url
    url(r'^complete/(?P<backend>[^/]+)/$', complete,name='socialauth_complete'),
    url(r'^profile-facebook/$', new_facebook_user),

    url(r"^account/signup/$", SignupView.as_view(), name="account_signup"),
    url(r"^account/", include("account.urls")),


    ### Question Paths ###
    url(r'^questions/$', question_list, name='questions_path'),
    url(r'^questions/new/$', question_create, name='new_question_path'),
    url(r'^questions/(?P<object_id>[0-9\-]+)/show/$', question_show, name='question_path'),
    url(r'^questions/(?P<object_id>[0-9\-]+)/show_popup/$', question_show_popup, name='popup_question_path'),
    url(r'^questions/(?P<object_id>[0-9\-]+)/edit/$', question_update, name='edit_question_path'),
    url(r'^questions/(?P<object_id>[0-9\-]+)/delete/$', question_delete, name='delete_question_path'),
    url(r'^questions/(?P<object_id>[0-9\-]+)/publish/$', question_publish, name='publish_question_path'),
    url(r'^questions/(?P<object_id>[0-9\-]+)/close/$', question_close, name='close_question_path'),

    ### Exam Paths ###
    url(r'^exams/$', exam_list, name='exams_path'),
    url(r'^exams/(?P<object_id>[0-9\-]+)/show/$', exam_show, name='exam_path'),
    url(r'^exams/(?P<exam_id>[0-9\-]+)/exam_type_sub_head/(?P<exam_type_sub_head_id>[0-9\-]+)/$', exam_question_assign_show, name='exam_question_assign_show_path'),
    url(r'^exams/(?P<exam_id>[0-9\-]+)/exam_type_sub_head/(?P<exam_type_sub_head_id>[0-9\-]+)/exam_type_sub_head_topic/(?P<exam_type_sub_head_topic_id>[0-9\-]+)/assign/(?P<question_id>[0-9\-]+)$', exam_question_assign, name='exam_question_assign_path'),
    url(r'^exams/(?P<exam_id>[0-9\-]+)/exam_type_sub_head/(?P<exam_type_sub_head_id>[0-9\-]+)/exam_type_sub_head_topic/(?P<exam_type_sub_head_topic_id>[0-9\-]+)/remove/(?P<question_id>[0-9\-]+)$', exam_question_remove, name='exam_question_remove_path'),
    url(r'^exams/(?P<object_id>[0-9\-]+)/complete/$', exam_complete, name='complete_exam_path'),
    url(r'^exams/(?P<object_id>[0-9\-]+)/publish/$', exam_publish, name='publish_exam_path'),
    url(r'^exams/(?P<object_id>[0-9\-]+)/unpublish/$', exam_unpublish, name='unpublish_exam_path'),
    url(r'^exams/(?P<object_id>[0-9\-]+)/republish/$', exam_republish, name='republish_exam_path'),

    ### Online Exam Paths ###

    url(r'^online_exams/(?P<exam_id>[0-9\-]+)/start/$', student_exam_start, name='student_exam_start_path'),
    url(r'^online_exams/(?P<exam_id>[0-9\-]+)/question/(?P<question_id>[0-9\-]+)/$', student_exam_question_show, name='student_exam_question_show_path'),
    url(r'^online_exams/(?P<exam_id>[0-9\-]+)/question/(?P<question_id>[0-9\-]+)/next/$', student_exam_question_show_next, name='student_exam_question_show_next_path'),
    url(r'^online_exams/(?P<exam_id>[0-9\-]+)/question/(?P<question_id>[0-9\-]+)/previous/$', student_exam_question_show_previous, name='student_exam_question_show_previous_path'),
    url(r'^online_exams/(?P<exam_id>[0-9\-]+)/question/(?P<question_id>[0-9\-]+)/target/(?P<target_question_id>[0-9\-]+)/$', student_exam_question_show_target, name='student_exam_question_show_target_path'),
    url(r'^online_exams/(?P<exam_id>[0-9\-]+)/question/(?P<question_id>[0-9\-]+)/answer/(?P<answer_id>[0-9\-]+)/$', student_exam_answer, name='student_exam_answer_path'),
    url(r'^online_exams/(?P<exam_id>[0-9\-]+)/finish/$', student_exam_finish, name='student_exam_finish_path'),

    ### Lesson Categories ajax paths ###
    url(r'^questions/ajax_lesson_category_request/(?P<lesson_level_id>[0-9\-]+)/$', lesson_category_request),
    url(r'^questions/ajax_lesson_category_unit_request/(?P<lesson_category_id>[0-9\-]+)/$', lesson_category_unit_request),
    url(r'^questions/ajax_lesson_category_unit_topic_request/(?P<lesson_category_unit_id>[0-9\-]+)/$', lesson_category_unit_topic_request),

    ### Exam Reports Paths ###


    ### Subscriptions Path ###
    url(r'^subscriptions/$', available_and_taken_subscription_list, name='available_and_taken_subscriptions_path'),
    url(r'^subscriptions/(?P<subscription_id>[0-9\-]+)/taken_show/$', taken_subscription_show, name='taken_subscription_show_path'),
    url(r'^subscriptions/(?P<subscription_type_id>[0-9\-]+)/available_show/$', available_subscription_show, name='available_subscription_show_path'),
    url(r'^subscriptions/(?P<subscription_type_id>[0-9\-]+)/subscribe_now/$', subscribe_now, name='subscribe_now_path'),

    ### Student Side Path ###
    url(r'^student_my_page/$', student_root_path, name='student_root_path'),
    url(r'^online_exams/$', available_exam_list, name='student_available_exams_path'),
    url(r'^online_exams/(?P<exam_id>[0-9\-]+)/show/$', student_exam_show, name='student_exam_path'),
    url(r'^total_results/$', total_results, name='student_total_results_path'),
    url(r'^student_exam_reports/(?P<exam_id>[0-9\-]+)/report/$', student_exam_report, name='student_exam_report_path'),


)+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

