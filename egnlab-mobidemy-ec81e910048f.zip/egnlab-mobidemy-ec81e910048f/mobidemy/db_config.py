
# -*- coding: utf-8 -*-
#import dj_database_url
### Db Config ###

# DATABASES = {'default': dj_database_url.config()}

#local bağlantı

DATABASES = {
    'default': {
        'ENGINE': 'tenant_schemas.postgresql_backend',
        'NAME': 'mobidemy_development',
        'USER': 'fordjango',
        'PASSWORD': '123456',
        'HOST': 'localhost',
        'PORT': '',
    }
}

DATABASE_ROUTERS = (
    'tenant_schemas.routers.TenantSyncRouter',
)

### Db Config end ###