# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import ugettext as _ 
from django.template.defaultfilters import slugify 
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django import forms
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from django.contrib.auth.models import User, UserManager, Group
from django.contrib.auth.backends import ModelBackend
from institutions.models import Institution
from places.models import *
from django.utils.translation import ugettext_lazy as _
from django.core.files.storage import default_storage


GENDER_TYPES = (
    ('male', _('male')),
    ('female', _('female')),
    ('gay', _('gay')),
    ('lesbian', _('lesbian')),
)

def get_student_upload_path(instance, filename):
    id = instance.id
    if id == None:
        try:
            id = Student.objects.latest('id').id + 1
        except:
            id = 1
    return settings.AWS_APPLICATION_PATH + "students/%s/profile_pictures/%s" % (id, filename)

class Student(models.Model):

    user = models.ForeignKey(User, unique=True, verbose_name=_('user'))
    date_of_birth = models.DateField(blank=True, null=True, verbose_name=_('date_of_birth'))
    gender = models.CharField(blank=True, null=True, max_length=40, verbose_name=_('gender'), choices=GENDER_TYPES)
    profile_picture = models.ImageField(
        upload_to=get_student_upload_path,
        blank=True,
        null=True,
    )
    city = models.ForeignKey(City, blank=True, null=True)
    state = models.ForeignKey(State, blank=True, null=True)
    status = models.BooleanField(default=True, verbose_name=_('active?'))

    class Meta:
        verbose_name_plural = _('Student User')
        verbose_name = _('Student Users')
   
    def __unicode__(self):
        return self.user.username


class UserExtent(models.Model):
    user = models.OneToOneField(User, primary_key=True)
    institution = models.ForeignKey(Institution)
