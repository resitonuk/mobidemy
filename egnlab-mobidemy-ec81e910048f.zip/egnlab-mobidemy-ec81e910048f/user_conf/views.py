# -*- coding: utf-8 -*-
from django.shortcuts import *
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import RequestContext, Context
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from django.core.mail import EmailMessage
from smtplib import SMTP
from django.contrib import messages
from django.utils.translation import get_language_info
from django.contrib.auth import authenticate, login, logout
from django.contrib import *
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.contrib.auth.models import User,Group
import datetime, random, sha, hashlib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from django.core.mail import EmailMessage
from smtplib import SMTP
from user_conf.models import Student
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _
from settings.models import *
from django.core.urlresolvers import reverse


def membership(request):
    return render_to_response('user_conf/membership.html', context_instance=RequestContext(request))

def registration(request):
    return render_to_response('user_conf/registration.html', context_instance=RequestContext(request))

def reset_password(request):
    return render_to_response('user_conf/reset_password.html', context_instance=RequestContext(request))


def login_view(request):
    username = request.POST.get('username', '')
    password = request.POST.get('password', '')
    user = auth.authenticate(username=username, password=password)

    if user is not None and user.is_active and user.username != "super_user" :

        auth.login(request, user)

        if request.user.groups.filter(name='Öğrenci'):

             return HttpResponseRedirect(reverse('student_root_path'))

        if request.user.groups.filter(name='Editör'):

             return HttpResponseRedirect('/editor/')


    elif user is not None and user.is_active and user.is_superuser :

        auth.login(request, user),

        return HttpResponseRedirect('/egnity_egnity/')

    else:
        messages.error(request, 'Kullanıcı Adı veya Şifreniz Hatalı')
        return HttpResponseRedirect('/?next=%s' % request.path)


def forget_password(request):
    username = ""
    student = ""
    question = ""

    if request.POST:

        username = request.POST['username']

        try:
            validate_email(username)
            username = request.POST['username']

        except:
            messages.error(request, _('user_login_email_error'))
            return HttpResponseRedirect('?next=%s' % request.path)

        try:
            student_exist = Student.objects.get(user__email__exact=username)

            key1 = hashlib.sha1(str(random.random())).hexdigest()[:40]
            key2 = hashlib.sha1(str(random.random())).hexdigest()[:40]
            now = datetime.datetime.now()

            student_exist.password_activation_date = now

            student_exist.password_activation = key1 + str(now.month) + key2
            student_exist.save()

            # TODO: Here has hard code strings and html. this needs moving to template file
            # üye mailına activasyon linki yolluyoruz...

            activation_link = u"http://localhost:8000/renew-password/" + str(
                student_exist.id) + "/" + student_exist.password_activation + "/"
            mail_adress = student_exist.user.email

            htmly = get_template('template_renew_password.html')
            d = Context({ 'activation_link': activation_link, 'mail_adress': mail_adress })
            html_content = htmly.render(d)


            from_addr = u"noreply@mobidemy.com"
            to_addr = student_exist.user.username
            subj = u"Mobidemy Şifre Sıfırlama"

            message_text = html_content
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subj
            msg['From'] = from_addr
            msg['To'] = to_addr

            html = message_text.encode('utf-8')

            htmlBody = MIMEText(html, 'html', _charset="UTF-8")
            msg.attach(htmlBody)

            #smtp bilgileri veritabanından geliyor (ayarlar modülünden bakabilirsiniz)
            smtp_address = Setting.objects.get(code="smtp_address")
            smtp_port = Setting.objects.get(code="smtp_port")
            smtp_username = Setting.objects.get(code="smtp_username")
            smtp_password = Setting.objects.get(code="smtp_password")

            smtp = SMTP()
            smtp.set_debuglevel(0)
            smtp.connect(str(smtp_address.text), int(smtp_port.text))
            smtp.starttls()
            smtp.login(str(smtp_username.text), str(smtp_password.text))
            smtp.sendmail(from_addr, to_addr, msg.as_string())
            smtp.quit()

            messages.error(request, 'Şifre sıfırlama linki başarıyla e-posta adresinize gönderildi')
            return HttpResponseRedirect('/?next=%s' % request.path)
        except:

            messages.error(request, 'Bu email sistemde kayıtlı değil')
            return HttpResponseRedirect('?next=%s' % request.path)

    else:
        return HttpResponseRedirect('/')



def secret_answer(request):
    if request.POST:

        answer = request.POST['answer']
        email = request.POST['email_hidden']

        student_exist = Student.objects.get(user__email__exact=email)

        if student_exist.secret_answer == answer:

            key1 = hashlib.sha1(str(random.random())).hexdigest()[:40]
            key2 = hashlib.sha1(str(random.random())).hexdigest()[:40]
            now = datetime.datetime.now()

            student_exist.password_activation = key1 + str(now.month) + key2
            student_exist.save()

            # TODO: Here has hard code strings and html. this needs moving to template file
            # üye mailına activasyon linki yolluyoruz...
            activation_link = u"http://localhost:8000/activation/" + str(
                student_exist.id) + "/" + student_exist.activation_code + "/"
            mail_adress = student_exist.user.email

            htmly = get_template('template_activation.html')
            d = Context({ 'activation_link': activation_link, 'mail_adress': mail_adress })
            html_content = htmly.render(d)

            from_addr = u"seymen.sipahi@egnity.com"
            to_addr = student_exist.user.username
            subj = u"Mobidemy Şifre Sıfırlama"

            message_text = html_content
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subj
            msg['From'] = from_addr
            msg['To'] = to_addr

            html = "<html><head></head><body>" + message_text.encode('utf-8') + "</body></html>"

            htmlBody = MIMEText(html, 'html', _charset="UTF-8")
            msg.attach(htmlBody)

            #smtp bilgileri veritabanından geliyor (ayarlar modülünden bakabilirsiniz)
            smtp_address = Setting.objects.get(code="smtp_address")
            smtp_port = Setting.objects.get(code="smtp_port")
            smtp_username = Setting.objects.get(code="smtp_username")
            smtp_password = Setting.objects.get(code="smtp_password")

            smtp = SMTP()
            smtp.set_debuglevel(0)
            smtp.connect(str(smtp_address.text), int(smtp_port.text))
            smtp.starttls()
            smtp.login(str(smtp_username.text), str(smtp_password.text))
            smtp.sendmail(from_addr, to_addr, msg.as_string())
            smtp.quit()

            messages.error(request, 'Şifre sıfırlama linki başarıyla e-posta adresinize gönderildi')
            return HttpResponseRedirect('/?next=%s' % request.path)

        else:

            messages.error(request, 'Yanlış cevap verdiniz')
            return HttpResponseRedirect('/?next=%s' % request.path)


def renew_password(request, id, key):
    current_student = Student.objects.get(id=id, status=True)
    message = ""

    now = datetime.datetime.now()
    after = current_student.password_activation_date + datetime.timedelta(hours=24)

    if(current_student.password_activation == key):
        return render_to_response('user_conf/password_change.html', locals(), context_instance=RequestContext(request))
    else:
        messages.error(request, 'Aktivasyon kodunuz geçersiz, tekrar göndermeyi deneyiniz')
        return HttpResponseRedirect('/?next=%s' % request.path)

    if now > after:

        now = datetime.datetime.now()
        key1 = hashlib.sha1(str(random.random())).hexdigest()[:40]
        key2 = hashlib.sha1(str(random.random())).hexdigest()[:40]

        current_student.password_activation = key1 + str(now.month) + key2
        current_student.password_activation_date = now
        current_student.save()

        # TODO: Here has hard code strings and html. this needs moving to template file
        # üye mailına activasyon linki yolluyoruz...
        activation_link = u"http://localhost:8000/activation/" + str(
        current_student.id) + "/" + current_student.activation_code + "/"
        mail_adress = current_student.user.email

        htmly = get_template('template_activation.html')
        d = Context({ 'activation_link': activation_link, 'mail_adress': mail_adress })
        html_content = htmly.render(d)

        from_addr = u"seymen.sipahi@egnity.com"
        to_addr = current_student.user.username
        subj = u"Mobidemy Üyelik Aktivasyon Mailı"

        message_text = html_content
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subj
        msg['From'] = from_addr
        msg['To'] = to_addr

        html = "<html><head></head><body>" + message_text.encode('utf-8') + "</body></html>"

        htmlBody = MIMEText(html, 'html', _charset="UTF-8")
        msg.attach(htmlBody)

        #smtp bilgileri veritabanından geliyor (ayarlar modülünden bakabilirsiniz)
        smtp_address = Setting.objects.get(code="smtp_address")
        smtp_port = Setting.objects.get(code="smtp_port")
        smtp_username = Setting.objects.get(code="smtp_username")
        smtp_password = Setting.objects.get(code="smtp_password")

        smtp = SMTP()
        smtp.set_debuglevel(0)
        smtp.connect(str(smtp_address.text), int(smtp_port.text))
        smtp.starttls()
        smtp.login(str(smtp_username.text), str(smtp_password.text))
        smtp.sendmail(from_addr, to_addr, msg.as_string())
        smtp.quit()

        messages.error(request, 'Aktivasyon kodunuzun süresi dolmuştur. Yeni aktivasyon kodunuz email adresinize gönderildi')

        return HttpResponseRedirect('/?next=%s' % request.path)


def change_password(request):
    if request.method == 'POST':
        password = request.POST['password']
        password2 = request.POST['password2']

        id = request.POST['id']
        pass_activation_key = request.POST['pass_activation_key']

        try:
            current_student = Student.objects.get(id=id, password_activation = pass_activation_key, status=True)

            if(password == password2):

                current_student.user.set_password(password)
                current_student.password_activation = ""

                current_student.user.save()
                current_student.save()

                messages.error(request, 'Şifreniz başarıyla değiştirildi!')
            else:
                messages.error(request, 'Girdiğiniz şifreler uyuşmuyor, tekrar deneyiniz')

        except:

            messages.error(request, 'Aktivasyon kodunuz geçersiz, lütfen tekrar deneyiniz')


        return HttpResponseRedirect('/?next=%s' % request.path)

def logout_view(request):
    auth.logout(request)
    # Redirect to a success page.
    return HttpResponseRedirect('/?next=%s' % request.path)


def new_facebook_user(request):
    # kayıtlı olarak geldi facebook kullanıcısı
    #bu kullanıcının mail adresiyle aynı olan kullanıcılar var mı ona bakıcaz

    facebook_mail = request.user.email
    same_mail_users_count = User.objects.filter(email=facebook_mail).count()

    if same_mail_users_count > 1:

        same_user = User.objects.filter(email=request.user.email)
        same_user.latest('id').delete()  #en son yaratılanı siliyoruz

        messages.error(request, 'Bu mail adresiyle zaten kayıt yapılmış')
        return HttpResponseRedirect('/?next=%s' % request.path)

    else:

        """current_user = User.objects.get(email=request.user.email)  #oluşturduğumuz userı çekiyoruz
        now = datetime.datetime.now()"""

        try:

            user = User.objects.get(email=facebook_mail)
            group = Group.objects.get(id=2)
            user.groups.add(group)

            current_user = User.objects.get(email=facebook_mail)  #oluşturduğumuz userı çekiyoruz

            # oluşturulan user a basic bir profil oluşturuyoruz bu profilde sadece
            create_student_profile = Student.objects.get_or_create(user_id=current_user.id, role_id=2)
            create_student_profile.save()

        except:

            pass

        return HttpResponseRedirect('/profile/')


def new_user(request):
    if request.POST:

        # formdan gelen verileri alıyoruz
        username = request.POST['username']
        first_name = request.POST['firstname']
        last_name = request.POST['lastname']
        password1 = request.POST['password']
        password2 = request.POST['verify']

        # boş alanları kontrol ediyoruz
        if username == "" or first_name == "" or last_name == "" or password1 == "" or password2 == "":
            messages.error(request, 'Lütfen boş alan bırakmayın')
            return HttpResponseRedirect('/sign_in/#register')

        if password1 != password2:
            messages.error(request, 'Girdiğiniz şifreler eşleşmiyor')
            return HttpResponseRedirect('/sign_in/#register')

        try:
            validate_email(username)
            username = request.POST['username']
        except:
            messages.error(request, 'Lütfen geçerli e-posta adresi girin')
            return HttpResponseRedirect('/sign_in/#register')

        exsisting_user = User.objects.filter(username__exact=username)
        exsisting_mail = User.objects.filter(email__exact=username)

        if exsisting_user or exsisting_mail:

            messages.error(request, 'Bu mail adresiyle zaten kayıt yapılmış')
            return HttpResponseRedirect('/?next=%s' % request.path)

        else:

            #formdan gelen verileri kullanarak djangonun user modeline kayıt ediyoruz böylece yeni bir user oluşturabiliriz
            user = User.objects.create_user(username, username,
                                            password2)  #sadece 3 alan koyabiliyoruz fonksiyon buna izin veriyor

            # ad soyad ve login olabilme özelliğini ayarlıyoruz.
            user.first_name = first_name
            user.last_name = last_name
            user.is_active = False  #false yapma nedenimiz activation kodunu maila gönderip aktive edebilmemiz için
            user.save()

            user = User.objects.get(id=user.id)
            group = Group.objects.get(id=2)
            user.groups.add(group)

            current_user = User.objects.get(username=username)  #oluşturduğumuz userı çekiyoruz

            # oluşturulan user a basic bir profil oluşturuyoruz bu profilde sadece 
            create_student_profile = Student(user_id=current_user.id, role_id=2)
            create_student_profile.save()

            current_student = Student.objects.get(user__username=username)

            key1 = hashlib.sha1(str(random.random())).hexdigest()[:40]
            key2 = hashlib.sha1(str(random.random())).hexdigest()[:40]
            now = datetime.datetime.now()
            current_student.activation_code_date = now
            current_student.activation_code = key1 + str(now.month) + key2
            current_student.save()

            # TODO: Here has hard code strings and html. this needs moving to template file
            #üye mailına activasyon linki yolluyoruz...
            activation_link = u"http://localhost:8000/activation/" + str(
                current_student.id) + "/" + current_student.activation_code + "/"
            mail_adress = current_student.user.email

            htmly = get_template('template_activation.html')
            d = Context({ 'activation_link': activation_link, 'mail_adress': mail_adress })
            html_content = htmly.render(d)

            from_addr = u"seymen.sipahi@egnity.com"
            to_addr = username
            subj = u"Mobidemy Üyelik Aktivasyon Mailı"

            message_text = html_content
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subj
            msg['From'] = from_addr
            msg['To'] = to_addr

            html = "<html><head></head><body>" + message_text.encode('utf-8') + "</body></html>"

            htmlBody = MIMEText(html, 'html', _charset="UTF-8")
            msg.attach(htmlBody)

            #smtp bilgileri veritabanından geliyor (ayarlar modülünden bakabilirsiniz)
            smtp_address = Setting.objects.get(code="smtp_address")
            smtp_port = Setting.objects.get(code="smtp_port")
            smtp_username = Setting.objects.get(code="smtp_username")
            smtp_password = Setting.objects.get(code="smtp_password")

            smtp = SMTP()
            smtp.set_debuglevel(0)
            smtp.connect(str(smtp_address.text), int(smtp_port.text))
            smtp.starttls()
            smtp.login(str(smtp_username.text), str(smtp_password.text))
            smtp.sendmail(from_addr, to_addr, msg.as_string())
            smtp.quit()

            messages.success(request, 'Aktivaston mailı yollandı')
    return HttpResponseRedirect('/?next=%s' % request.path)


def activation(request, id, key):
    current_student = Student.objects.get(id=id, status=True)
    message = ""

    if current_student.user.is_active == False:

        now = datetime.datetime.now()
        after = current_student.activation_code_date + datetime.timedelta(hours=2)

        if now > after:

            message = "Aktivasyon kodunuzun zamanı doldu. Lütfen aktivasyon işleminizi yineliyiniz."

            now = datetime.datetime.now()
            key1 = hashlib.sha1(str(random.random())).hexdigest()[:40]
            key2 = hashlib.sha1(str(random.random())).hexdigest()[:40]
            current_student.activation_code = key1 + str(now.month) + key2

            current_student.save(update_fields=["activation_code"])

            # TODO: Here has hard code strings and html. this needs moving to template file
            # üye mailına activasyon linki yolluyoruz...

            activation_link = u"http://localhost:8000/activation/" + str(
                current_student.id) + "/" + current_student.activation_code + "/"
            mail_adress = current_student.user.email

            htmly = get_template('template_activation.html')
            d = Context({ 'activation_link': activation_link, 'mail_adress': mail_adress })
            html_content = htmly.render(d)

            from_addr = u"seymen.sipahi@egnity.com"
            to_addr = current_student.user.username
            subj = u"Mobidemy Üyelik Aktivasyon Mailı"

            message_text = html_content
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subj
            msg['From'] = from_addr
            msg['To'] = to_addr

            html = "<html><head></head><body>" + message_text.encode('utf-8') + "</body></html>"

            htmlBody = MIMEText(html, 'html', _charset="UTF-8")
            msg.attach(htmlBody)

            #smtp bilgileri veritabanından geliyor (ayarlar modülünden bakabilirsiniz)
            smtp_address = Setting.objects.get(code="smtp_address")
            smtp_port = Setting.objects.get(code="smtp_port")
            smtp_username = Setting.objects.get(code="smtp_username")
            smtp_password = Setting.objects.get(code="smtp_password")

            smtp = SMTP()
            smtp.set_debuglevel(0)
            smtp.connect(str(smtp_address.text), int(smtp_port.text))
            smtp.starttls()
            smtp.login(str(smtp_username.text), str(smtp_password.text))
            smtp.sendmail(from_addr, to_addr, msg.as_string())
            smtp.quit()

        else:

            if current_student.activation_code == key:
                current_student = Student.objects.get(activation_code=key, status=True)
                current_user = User.objects.get(id=current_student.user_id)

                if current_user.is_active == False:

                    current_user.is_active = True
                    current_user.save()
                    message = "Üyeliğiniz başarıyla aktifleştirilmiştir."

                else:

                    message = "Üyeliğiniz zaten aktifleştirilmiş. Sisteme giriş yapmanız için login olmanız yeterli."
            else:

                message = "Aktivasyon kodunuz eşleşmiyor"
    else:

        message = "Üyeliğiniz zaten aktifleştirilmiş. Sisteme giriş yapmanız için login olmanız yeterli."

    return render_to_response('user_conf/activation.html', {'current_student': current_student,
                                                  'message': message}, context_instance=RequestContext(request))


@login_required(login_url='/?next=%s')
def profile(request):
    student = Student.objects.get(user_id=request.user.id)

    if request.POST:
        question = request.POST['question']
        answer = request.POST['answer']

        student.secret_question = question
        student.secret_answer = answer
        student.save(update_fields=['secret_question', 'secret_answer'])

    return render_to_response('user_conf/profil.html',locals(), context_instance=RequestContext(request))
