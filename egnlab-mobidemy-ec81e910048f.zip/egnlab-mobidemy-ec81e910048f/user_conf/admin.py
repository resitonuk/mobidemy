from user_conf.models import *
from django.contrib import admin
from django.forms import TextInput, Textarea,ModelForm
#from suit.admin import SortableTabularInline


class AdminStudent(admin.ModelAdmin):
    
    list_display = ('user', 'name', 'surname', 'status')
    list_display_links = ('user', 'name', 'surname', 'status')
    list_filter = ('gender', 'status')
    search_fields = ['user', 'name', 'surname']
    
    def name(self, instance):
        return instance.user.first_name
    
    def surname(self, instance):
        return instance.user.last_name
    
    
admin.site.register(Student, AdminStudent)

