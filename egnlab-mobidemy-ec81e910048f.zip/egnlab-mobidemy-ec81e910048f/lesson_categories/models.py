from django.db import models
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from user_conf.models import *
from lesson_categories import *

# Create your models here.

class LessonLevel(models.Model):

    name = models.CharField(_('lesson_level_name'), max_length=100)
    explanation = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = _('Lesson Level')
        verbose_name_plural = _('Lesson Levels')

    def __unicode__(self):
        return self.name


class LessonCategory(models.Model):

    name = models.CharField(_('lesson_category_name'), max_length=60, unique=True)
    lesson_level = models.ForeignKey('lesson_categories.LessonLevel', blank=True, null=True)
    explanation = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = _('Lesson Category')
        verbose_name_plural = _('Lesson Categories')

    def __unicode__(self):
        return self.name


class LessonCategoryUnit(models.Model):

    lesson_category = models.ForeignKey(LessonCategory)
    name = models.CharField(_('lesson_category_unit_name'), max_length=100)
    explanation = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = _('Lesson Category Unit')
        verbose_name_plural = _('Lesson Category Units')
        unique_together = (("name", "lesson_category"), )

    def __unicode__(self):
        return self.name


class LessonCategoryUnitTopic(models.Model):

    lesson_category_unit = models.ForeignKey(LessonCategoryUnit)
    name = models.CharField(_('lesson_category_unit_topic_name'), max_length=100)
    explanation = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = _('Lesson Category Unit Topic')
        verbose_name_plural = _('Lesson Category Unit Topics')
        unique_together = (("name", "lesson_category_unit"), )

    def __unicode__(self):
        return self.name
