# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='LessonCategory',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=60, verbose_name='lesson_category_name')),
                ('explanation', models.TextField(null=True, blank=True)),
            ],
            options={
                'verbose_name': 'Lesson Category',
                'verbose_name_plural': 'Lesson Categories',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='LessonCategoryUnit',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100, verbose_name='lesson_category_unit_name')),
                ('explanation', models.TextField(null=True, blank=True)),
                ('lesson_category', models.ForeignKey(to='lesson_categories.LessonCategory')),
            ],
            options={
                'verbose_name': 'Lesson Category Unit',
                'verbose_name_plural': 'Lesson Category Units',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='LessonCategoryUnitTopic',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100, verbose_name='lesson_category_unit_topic_name')),
                ('explanation', models.TextField(null=True, blank=True)),
                ('lesson_category_unit', models.ForeignKey(to='lesson_categories.LessonCategoryUnit')),
            ],
            options={
                'verbose_name': 'Lesson Category Unit Topic',
                'verbose_name_plural': 'Lesson Category Unit Topics',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='LessonLevel',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100, verbose_name='lesson_level_name')),
                ('explanation', models.TextField(null=True, blank=True)),
            ],
            options={
                'verbose_name': 'Lesson Level',
                'verbose_name_plural': 'Lesson Levels',
            },
            bases=(models.Model,),
        ),
        migrations.AlterUniqueTogether(
            name='lessoncategoryunittopic',
            unique_together=set([('name', 'lesson_category_unit')]),
        ),
        migrations.AlterUniqueTogether(
            name='lessoncategoryunit',
            unique_together=set([('name', 'lesson_category')]),
        ),
        migrations.AddField(
            model_name='lessoncategory',
            name='lesson_level',
            field=models.ForeignKey(blank=True, to='lesson_categories.LessonLevel', null=True),
            preserve_default=True,
        ),
    ]
