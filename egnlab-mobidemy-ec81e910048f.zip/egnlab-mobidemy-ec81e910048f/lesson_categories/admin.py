from django.contrib import admin
from lesson_categories.models import *

#####
class CustomModelChoiceFieldLessonCategoryUnitTopic(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return "%s - %s - %s" % (obj.lesson_category.lesson_level.name,
                                      obj.lesson_category.name,
                                      obj.name)


class MyLessonCategoryUnitTopicAdminForm(forms.ModelForm):
    lesson_category_unit = CustomModelChoiceFieldLessonCategoryUnitTopic(
        queryset=LessonCategoryUnit.objects.order_by('lesson_category_id').all())

    class Meta:
        model = LessonCategoryUnitTopic
        fields = '__all__'


class ExamTypeSubHeadTopicAdmin(admin.ModelAdmin):
    form = MyLessonCategoryUnitTopicAdminForm

#####

class CustomModelChoiceFieldLessonCategoryUnit(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return "%s - %s" % (obj.lesson_level.name,
                                      obj.name)


class MyLessonCategoryUnitAdminForm(forms.ModelForm):
    lesson_category = CustomModelChoiceFieldLessonCategoryUnit(
        queryset=LessonCategory.objects.order_by('lesson_level_id').all())

    class Meta:
        model = LessonCategoryUnit
        fields = '__all__'


class ExamTypeSubHeadAdmin(admin.ModelAdmin):
    form = MyLessonCategoryUnitAdminForm


# Register your models here.
admin.site.register(LessonCategory)
admin.site.register(LessonCategoryUnit, ExamTypeSubHeadAdmin)
admin.site.register(LessonCategoryUnitTopic, ExamTypeSubHeadTopicAdmin)
admin.site.register(LessonLevel)