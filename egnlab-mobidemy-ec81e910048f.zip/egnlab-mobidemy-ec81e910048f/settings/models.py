from django.db import models
from django.utils.translation import ugettext_lazy as _
from mobidemy import settings
from questions.models import Question

### Images Upload Path Define start ###
def get_question_attachment_image_upload_path(instance, filename):
    id = instance.id
    if id == None:
        try:
            id = Question.objects.latest('id').id + 1
        except:
            id = 1
    return settings.AWS_APPLICATION_PATH + "questions/%s/images/%s" % (id, filename)


class Setting(models.Model):

    name = models.CharField(blank=True,null=True,max_length=200,verbose_name=_('Title'))
    text = models.TextField(blank=True,null=True,verbose_name=_('Content'))
    code = models.CharField(unique=True,blank=True,null=True,max_length=200,verbose_name=_('Code'))
    url = models.CharField(blank=True,null=True,max_length=200,verbose_name=_('Url'))
    targetBlank = models.BooleanField(default=False,verbose_name=_('Open in new page'))
    category = models.CharField(blank=True,null=True,max_length=200,verbose_name=_('Category'))

    image = models.FileField(
        upload_to=get_question_attachment_image_upload_path,
        blank=True,
        null=True,
    )

    class Meta:
        verbose_name_plural = _('Settings')
        verbose_name = _('Setting')

    def __unicode__(self):
        return self.name
