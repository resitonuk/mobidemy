# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import settings.models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Setting',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=200, null=True, verbose_name='Title', blank=True)),
                ('text', models.TextField(null=True, verbose_name='Content', blank=True)),
                ('code', models.CharField(max_length=200, unique=True, null=True, verbose_name='Code', blank=True)),
                ('url', models.CharField(max_length=200, null=True, verbose_name='Url', blank=True)),
                ('targetBlank', models.BooleanField(default=False, verbose_name='Open in new page')),
                ('category', models.CharField(max_length=200, null=True, verbose_name='Category', blank=True)),
                ('image', models.FileField(null=True, upload_to=settings.models.get_question_attachment_image_upload_path, blank=True)),
            ],
            options={
                'verbose_name': 'Setting',
                'verbose_name_plural': 'Settings',
            },
            bases=(models.Model,),
        ),
    ]
