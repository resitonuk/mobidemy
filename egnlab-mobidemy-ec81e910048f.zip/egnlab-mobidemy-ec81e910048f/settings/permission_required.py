# -*- coding: utf-8 -*-
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from user_conf.models import Student


def student_login_required(f):
        def wrap(request, *args, **kwargs):
                if request.user.id:
                    student = Student.objects.get(user_id=request.user.id)
                    if not student:
                        return HttpResponseRedirect(reverse('permission_denied'))
                else:
                    return HttpResponseRedirect(reverse('permission_denied'))
                return f(request, *args, **kwargs)
        wrap.__doc__=f.__doc__
        wrap.__name__=f.__name__
        return wrap

def editor_login_required(f):
        def wrap(request, *args, **kwargs):
                if request.user.id:
                    if not request.user.groups.filter(name=u'editor'):
                        return HttpResponseRedirect(reverse('permission_denied'))
                else:
                    return HttpResponseRedirect(reverse('permission_denied'))
                return f(request, *args, **kwargs)
        wrap.__doc__=f.__doc__
        wrap.__name__=f.__name__
        return wrap