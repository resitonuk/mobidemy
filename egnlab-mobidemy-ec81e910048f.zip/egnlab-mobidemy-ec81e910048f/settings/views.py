# -*- coding: utf-8 -*-
from django.contrib.auth.models import User,Group
from user_conf.models import *
from django.shortcuts import *


def editor_check(user):
    if user:
        return user.groups.filter(name=u'editor')
    return True

def current_student(request):
    val = None
    try:
        val = Student.objects.get(user_id=request.user.id)
    except:
        val = False
    return val

def current_institution(request):
    val = None
    try:
        val = request.tenant
    except:
        val = False
    return val

def current_institution_with_user(request):
    val = None
    try:
        val = UserExtent.objects.get(user_id=request.user.id).institution
    except:
        val = False
    return val
