from django.contrib import admin
from settings.models import *

class AdminSetting(admin.ModelAdmin):

    list_display = ('name','code','category')
    search_fields = ['name','code','category']

admin.site.register(Setting,AdminSetting)

