from django.db import models
from django_tables2 import tables
from django_tables2.utils import Accessor
from django_tables2.utils import A
from institutions.models import Institution
import django_tables2 as tables


class InstitutionTable(tables.Table):
    id = tables.LinkColumn('institution_path', args=[A('pk')])
    code_name = tables.LinkColumn('institution_path', args=[A('pk')])
    name = tables.LinkColumn('institution_path', args=[A('pk')])
    #actions = tables.TemplateColumn(template_name='questions/inline/general_table_link.html', orderable=False)

    class Meta:
        model = Institution
