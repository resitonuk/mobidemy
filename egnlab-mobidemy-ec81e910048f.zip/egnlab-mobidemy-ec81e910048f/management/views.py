from django.core.urlresolvers import reverse
from django.forms.models import model_to_dict
from django.shortcuts import render, render_to_response, get_object_or_404, redirect
from django.http import HttpResponseRedirect
from django.template.context import RequestContext
from django_tables2.config import RequestConfig
from institutions.models import Institution
from management.forms import InstitutionForm
from management.models import InstitutionTable
from settings.permission_required import editor_login_required
from django.contrib.auth.models import User, Group
from tenant_schemas.utils import tenant_context
from user_conf.models import UserExtent


def management_index(request):
    return render_to_response('management/index.html', locals(), context_instance=RequestContext(request))

def new_institution(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = InstitutionForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # create your first real tenant
            super_user = None
            try:
                super_user = User.objects.create_superuser(username=(form.cleaned_data["code_name"] + "_admin"), password='superuser', email=form.cleaned_data["admin_email"])
                institution = form.save()
                user_extent = UserExtent()
                user_extent.user = super_user
                user_extent.institution = institution
                user_extent.save()
                group = Group.objects.get(id=1)
                super_user.groups.add(group)

                return HttpResponseRedirect(reverse('institution_path', args=[institution.id]))
            except:
                pass

    # if a GET (or any other method) we'll create a blank form
    else:
        form = InstitutionForm()

    return render_to_response('management/new.html', locals(), context_instance=RequestContext(request))

def update_institution(request, pk=None):
    obj = get_object_or_404(Institution, pk=pk)
    form = InstitutionForm(request.POST or None,
                        request.FILES or None, instance=obj)
    if request.method == 'POST':
        if form.is_valid():
           institution = form.save()
           return redirect(reverse('institution_path', args=[institution.id]))
    return render(request, 'management/new.html', {'form': form})


def institution_list(request):
    table = InstitutionTable(Institution.objects.all())
    RequestConfig(request, paginate={"per_page": 16}).configure(table)
    return render(request, 'management/list.html', {'institutions': table})\


def institution_show(request, object_id):
    institution = get_object_or_404(Institution, id=object_id)
    institution_table = InstitutionForm(data=model_to_dict(institution))

    return render_to_response('management/show.html', locals(), context_instance=RequestContext(request))
