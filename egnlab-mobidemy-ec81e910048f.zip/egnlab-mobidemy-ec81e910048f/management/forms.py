from django import forms
from django.forms.models import ModelForm
from django.utils.translation import ugettext_lazy as _
from institutions.models import Institution
from questions.models import Question


class InstitutionForm(ModelForm):
    class Meta:
        model = Institution
        exclude = ['created_on']


