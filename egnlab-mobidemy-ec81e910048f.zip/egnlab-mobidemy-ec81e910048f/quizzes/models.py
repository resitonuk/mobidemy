from django.db import models
from django.utils.translation import ugettext_lazy as _
from user_conf.models import *
from questions.models import *
from lesson_categories.models import *
from lessons.models import *
from videos.models import *

class Quiz(models.Model):

    name = models.CharField(_('quiz name'), max_length=100)
    title = models.CharField(_('quiz title'), max_length=100)
    description = models.TextField(blank=True, null=True)
    lesson_video = models.ForeignKey('videos.LessonVideo', blank=True, null=True)

    class Meta:
        verbose_name = _('Quiz')
        verbose_name_plural = _('Quizzes')

    def __unicode__(self):
        return self.name


class QuizQuestion(models.Model):

    quiz = models.ForeignKey('quizzes.Quiz', blank=True, null=True)
    question = models.ForeignKey('questions.Question', blank=True, null=True)
    order_number = models.IntegerField(default=0)

    class Meta:
        verbose_name = _('Quiz Question')
        verbose_name_plural = _('Quiz Question')

