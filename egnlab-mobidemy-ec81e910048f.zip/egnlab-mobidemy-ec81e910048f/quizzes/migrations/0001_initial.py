# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('questions', '0001_initial'),
        ('videos', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Quiz',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100, verbose_name='quiz name')),
                ('title', models.CharField(max_length=100, verbose_name='quiz title')),
                ('description', models.TextField(null=True, blank=True)),
                ('lesson_video', models.ForeignKey(blank=True, to='videos.LessonVideo', null=True)),
            ],
            options={
                'verbose_name': 'Quiz',
                'verbose_name_plural': 'Quizzes',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='QuizQuestion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('order_number', models.IntegerField(default=0)),
                ('question', models.ForeignKey(blank=True, to='questions.Question', null=True)),
                ('quiz', models.ForeignKey(blank=True, to='quizzes.Quiz', null=True)),
            ],
            options={
                'verbose_name': 'Quiz Question',
                'verbose_name_plural': 'Quiz Question',
            },
            bases=(models.Model,),
        ),
    ]
