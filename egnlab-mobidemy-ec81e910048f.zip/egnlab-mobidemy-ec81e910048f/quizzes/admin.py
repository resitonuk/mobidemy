from django.contrib import admin
from quizzes.models import Quiz

admin.site.register(Quiz)
