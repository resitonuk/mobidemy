# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings
import django_fsm
import questions.models


class Migration(migrations.Migration):

    dependencies = [
        ('lesson_categories', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('content_providers', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Question',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.TextField(null=True, verbose_name='Title', blank=True)),
                ('correct_choice_index', models.IntegerField(default=1)),
                ('state', django_fsm.FSMField(default=b'initiated', max_length=50)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('content_provider', models.ForeignKey(to='content_providers.ContentProvider')),
                ('created_user', models.ForeignKey(related_name='question_created', db_column=b'created_user_id', blank=True, to=settings.AUTH_USER_MODEL, null=True)),
                ('last_updated_user', models.ForeignKey(related_name='question_last_updated', db_column=b'last_updated_user_id', blank=True, to=settings.AUTH_USER_MODEL, null=True)),
            ],
            options={
                'verbose_name': 'Question',
                'verbose_name_plural': 'Questions',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='QuestionAttachment',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('label', models.CharField(max_length=16, choices=[(b'question_image', 'Question Image'), (b'question_answer', 'Question Answer'), (b'another_image', 'Another Image')])),
                ('image', models.FileField(upload_to=questions.models.get_question_attachment_image_upload_path)),
                ('question', models.ForeignKey(to='questions.Question')),
            ],
            options={
                'verbose_name': 'Question Attachment',
                'verbose_name_plural': 'Question Attachments',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='QuestionLessonCategoryUnitTopic',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('lesson_category', models.ForeignKey(blank=True, to='lesson_categories.LessonCategory', null=True)),
                ('lesson_category_unit', models.ForeignKey(blank=True, to='lesson_categories.LessonCategoryUnit', null=True)),
                ('lesson_category_unit_topic', models.ForeignKey(to='lesson_categories.LessonCategoryUnitTopic')),
                ('lesson_level', models.ForeignKey(blank=True, to='lesson_categories.LessonLevel', null=True)),
                ('question', models.ForeignKey(to='questions.Question')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
    ]
