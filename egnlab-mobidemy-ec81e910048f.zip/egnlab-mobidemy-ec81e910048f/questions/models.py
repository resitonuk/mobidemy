from django.db import models
from django.conf import settings
from django.core.files.storage import default_storage
from django.utils.translation import ugettext_lazy as _
from django.forms import *
from django.shortcuts import render
from django.utils.translation import ugettext_lazy as _
from django.core.exceptions import NON_FIELD_ERRORS
from user_conf.models import *
from django.utils import timezone
from lesson_categories.models import *
from django_fsm import FSMField, transition
from django.db.models import Q
import django_tables2 as tables
from django_tables2.utils import Accessor
from django_tables2.utils import A
from django.utils.safestring import mark_safe
from django.utils.html import escape
from content_providers.models import *


class Question(models.Model):

    title = models.TextField(blank=True, null=True, verbose_name=_('Title'))
    content_provider = models.ForeignKey(ContentProvider)
    created_user = models.ForeignKey(User, db_column='created_user_id', related_name='%(class)s_created', blank=True, null=True)
    last_updated_user = models.ForeignKey(User, db_column='last_updated_user_id', related_name='%(class)s_last_updated', blank=True, null=True)
    correct_choice_index = models.IntegerField(default=1)
    state = FSMField(default='initiated')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


    class Meta:
        app_label = 'questions'
        verbose_name = _('Question')
        verbose_name_plural = _('Questions')

    def __unicode__(self):
        return self.title


    ### State Machine Start ###
    @transition(field=state, source='*', target='published')
    def publish(self):
        ''

    @transition(field=state, source='*', target='closed')
    def close(self):
        ''

    ### State Machine End ###


    @staticmethod
    def get_assignable_questions():
        return Question.objects.filter(Q(state='published'))


    def get_question_image(self):
        return self.questionattachment_set.get(label='question_image')



class QuestionTable(tables.Table):
    title = tables.LinkColumn('question_path', args=[A('pk')])
    id = tables.LinkColumn('question_path', args=[A('pk')])
    actions = tables.TemplateColumn(template_name='questions/inline/general_table_link.html', orderable=False)

    class Meta:
        model = Question


class QuestionAssignTable(tables.Table):
    title = tables.LinkColumn('question_path', args=[A('pk')])
    id = tables.LinkColumn('question_path', args=[A('pk')])
    actions = tables.TemplateColumn(template_name='questions/inline/assign_table_link.html', orderable=False)

    class Meta:
        model = Question
        fields = ('id', 'title', 'content_provider', 'updated_at')



#### End Question Model



LABEL_CHOICES = (
        ('question_image', _('Question Image')),
        ('question_answer', _('Question Answer')),
        ('another_image', _('Another Image')),
)

### Images Upload Path Define start ###

def get_question_attachment_image_upload_path(instance, filename):
    id = instance.id
    if id == None:
        try:
            id = Question.objects.latest('id').id + 1
        except:
            id = 1
    return settings.AWS_APPLICATION_PATH + "questions/%s/images/%s" % (id, filename)

### Images Upload Path Define end ###

class QuestionAttachment(models.Model):

    question = models.ForeignKey(Question)
    label = models.CharField(max_length=16, choices=LABEL_CHOICES) # TODO: This field assign to automatic and we define about array items (question, answer, etc).

    image = models.FileField(
        upload_to=get_question_attachment_image_upload_path,
    )

    def label_human_name(self):
        return dict(LABEL_CHOICES)[self.label]

    class Meta:
        app_label = 'questions'
        verbose_name = _('Question Attachment')
        verbose_name_plural = _('Question Attachments')



class QuestionLessonCategoryUnitTopic(models.Model):

    question = models.ForeignKey(Question)
    lesson_category_unit_topic = models.ForeignKey(LessonCategoryUnitTopic)
    lesson_category_unit = models.ForeignKey(LessonCategoryUnit, blank=True, null=True)
    lesson_category = models.ForeignKey(LessonCategory, blank=True, null=True)
    lesson_level = models.ForeignKey(LessonLevel, blank=True, null=True)



    class Meta:
        app_label = 'questions'



class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['title', 'content_provider', 'correct_choice_index']

        error_messages = {
            NON_FIELD_ERRORS: {
                'unique_together': "%(model_name)s's %(field_labels)s are not unique.",
            }
        }

class QuestionLessonCategoryForm(forms.ModelForm):

    lesson_category_unit = forms.ModelChoiceField(queryset=LessonCategoryUnit.objects.all(), widget=forms.Select(attrs={'onchange':'get_lesson_sub_head_topic(this);'}), required=False)
    lesson_category = forms.ModelChoiceField(queryset=LessonCategory.objects.all(), widget=forms.Select(attrs={'onchange':'get_lesson_sub_head(this);'}), required=False)
    lesson_level = forms.ModelChoiceField(queryset=LessonLevel.objects.all(), widget=forms.Select(attrs={'onchange':'get_lesson(this);'}), required=False)

    class Meta:
        model = QuestionLessonCategoryUnitTopic
        fields = '__all__'



class QuestionAttachmentForm(forms.ModelForm):
    class Meta:
        model = QuestionAttachment
        fields = '__all__'


QuestionAttachmentFormSet = inlineformset_factory(Question,
                                                  QuestionAttachment,
                                                  form=QuestionAttachmentForm,
                                                  can_delete=True,
                                                  extra=2,
                                                  max_num=3
)

QuestionLessonCategoryFormSet = inlineformset_factory(Question,
                                                  QuestionLessonCategoryUnitTopic,
                                                  form=QuestionLessonCategoryForm,
                                                  can_delete=True,
                                                  extra=1,
)

