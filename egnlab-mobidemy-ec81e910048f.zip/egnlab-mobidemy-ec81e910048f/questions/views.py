from django.shortcuts import render
from django.forms.models import inlineformset_factory
from django.template import RequestContext
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.core.urlresolvers import reverse
from django.db.models import Q
from django_tables2 import RequestConfig
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from questions.models import *
from exams.models import *
from  settings.permission_required import editor_login_required


@editor_login_required
def question_list(request):
    table = QuestionTable(Question.objects.all())
    RequestConfig(request, paginate={"per_page": 16}).configure(table)
    return render(request, 'questions/list.html', {'questions': table})


@editor_login_required
def question_show(request, object_id):
    question = get_object_or_404(Question, id=object_id)
    question_table = QuestionForm(data=model_to_dict(question))
    question_attachments = question.questionattachment_set.all()

    return render_to_response('questions/show.html', locals(), context_instance=RequestContext(request))


@editor_login_required
def question_show_popup(request, object_id):
    question = get_object_or_404(Question, id=object_id)
    question_table = QuestionForm(data=model_to_dict(question))
    question_attachments = question.questionattachment_set.all()

    return render_to_response('questions/show_popup.html', locals(), context_instance=RequestContext(request))


@editor_login_required
def question_create(request):
    if request.POST:

        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question_attachment_formset = QuestionAttachmentFormSet(request.POST, request.FILES, instance=question, prefix='question_attachment')
            question_lesson_category_formset = QuestionLessonCategoryFormSet(request.POST, instance=question, prefix='lesson_category')
            if question_attachment_formset.is_valid() & question_lesson_category_formset.is_valid():
                question.save()
                question_attachment_formset.save()
                question_lesson_category_formset.save()
                return HttpResponseRedirect(reverse(question_show, kwargs={'object_id':question.id}))
    else:
        form = QuestionForm()
        question_attachment_formset = QuestionAttachmentFormSet(instance=Question(), prefix='question_attachment')
        question_lesson_category_formset = QuestionLessonCategoryFormSet(instance=Question(), prefix='lesson_category')

    return render_to_response("questions/question_form.html", {
        "form": form,
        "question_attachment_formset": question_attachment_formset,
        "question_lesson_category_formset": question_lesson_category_formset,
    }, context_instance=RequestContext(request))



@editor_login_required
def question_update(request, object_id):
    question = get_object_or_404(Question, id=object_id)

    if request.POST:

        form = QuestionForm(request.POST, instance=question)
        if form.is_valid():
            question_attachment_formset = QuestionAttachmentFormSet(request.POST, request.FILES, instance=question, prefix='question_attachment')
            question_lesson_category_formset = QuestionLessonCategoryFormSet(request.POST, instance=question, prefix='lesson_category')
            if question_attachment_formset.is_valid() & question_lesson_category_formset.is_valid():
                form.save()
                question_attachment_formset.save()
                question_lesson_category_formset.save()
                return HttpResponseRedirect(reverse(question_show, kwargs={'object_id':question.id}))
    else:
        form = QuestionForm(instance=question)
        question_attachment_formset = QuestionAttachmentFormSet(instance=question, prefix='question_attachment')
        question_lesson_category_formset = QuestionLessonCategoryFormSet(instance=question, prefix='lesson_category')
    return render_to_response("questions/question_form.html", {
        "form": form,
        "question_attachment_formset": question_attachment_formset,
        "question_lesson_category_formset": question_lesson_category_formset,
}, context_instance=RequestContext(request))



@editor_login_required
def question_delete(request, object_id):
    question = get_object_or_404(Question, id=object_id)
    question.delete()


    return HttpResponseRedirect(reverse(question_list))



@editor_login_required
def question_publish(request, object_id):
    question = get_object_or_404(Question.objects.filter(Q(state='initiated') | Q(state='closed')).all(), id=object_id)
    question.publish()
    question.save()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))



@editor_login_required
def question_close(request, object_id):
    question = get_object_or_404(Question.objects.filter(state='published').all(), id=object_id)
    question.close()
    question.save()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


@editor_login_required
@csrf_exempt
def lesson_category_request(request, lesson_level_id):
    objects = LessonCategory.objects.filter(lesson_level_id=lesson_level_id)
    return render_to_response('questions/inline/select_box.html', locals())


@editor_login_required
@csrf_exempt
def lesson_category_unit_request(request, lesson_category_id):
    objects = LessonCategoryUnit.objects.filter(lesson_category_id=lesson_category_id)
    return render_to_response('questions/inline/select_box.html', locals())


@editor_login_required
@csrf_exempt
def lesson_category_unit_topic_request(request, lesson_category_unit_id):
    objects = LessonCategoryUnitTopic.objects.filter(lesson_category_unit_id=lesson_category_unit_id)
    return render_to_response('questions/inline/select_box.html', locals())

