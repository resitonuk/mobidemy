from django.contrib import admin
from questions.models import *

class QuestionAttachmentInline(admin.TabularInline):
    model = QuestionAttachment
    extra = 2

class QuestionLessonCategoryUnitTopicInline(admin.TabularInline):
    model = QuestionLessonCategoryUnitTopic
    extra = 1

class QuestionAdmin(admin.ModelAdmin):
    inlines = [
        QuestionAttachmentInline,
        QuestionLessonCategoryUnitTopicInline,
    ]

# Register your models here.
admin.site.register(Question, QuestionAdmin)
