from django.db import models
from django.utils.translation import ugettext_lazy as _
from user_conf.models import *
from lesson_categories.models import *
from lessons.models import *


class Video(models.Model):

    name = models.CharField(_('video name'), max_length=100)
    title = models.CharField(_('video title'), max_length=100)
    description = models.TextField(blank=True, null=True)
    url = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = _('Video')
        verbose_name_plural = _('Videos')

    def __unicode__(self):
        return self.name


class LessonVideo(models.Model):

    lesson = models.ForeignKey('lessons.Lesson', blank=True, null=True)
    video = models.ForeignKey('videos.Video', blank=True, null=True)

    class Meta:
        verbose_name = _('Lesson Video')
        verbose_name_plural = _('Lesson Videos')
