# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('exam_packages', '0001_initial'),
        ('exams', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='exampackage',
            name='exam',
            field=models.ManyToManyField(to='exams.Exam'),
            preserve_default=True,
        ),
    ]
