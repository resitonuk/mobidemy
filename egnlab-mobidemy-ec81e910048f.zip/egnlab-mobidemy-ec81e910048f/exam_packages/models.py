from django.db import models
from django.utils.translation import ugettext_lazy as _
from exams.models import *

# Create your models here.
class ExamPackage(models.Model):

    exam = models.ManyToManyField(Exam)
    name = models.CharField(_('exam_package_name'), max_length=100, unique=True)
    explanation = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = _('Exam Package')
        verbose_name_plural = _('Exam Packages')

    def __unicode__(self):
        return self.name
