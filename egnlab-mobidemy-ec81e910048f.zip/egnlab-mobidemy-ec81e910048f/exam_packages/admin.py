from django.contrib import admin
from exam_packages.models import *

admin.site.register(ExamPackage)
