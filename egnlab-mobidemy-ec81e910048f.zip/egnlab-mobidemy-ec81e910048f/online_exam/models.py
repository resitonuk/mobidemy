from django.db import models
from exam_packages.models import ExamPackage
from subscriptions.models import *
import datetime


class OnlineExam:
    @staticmethod
    def initialize_student_exam_and_answers(exam, student):
        questions = exam.get_assigned_questions()
        student_exam = StudentExam.get_exam_with_student(student, exam)
        if not student_exam:
            student_exam = StudentExam()
            student_exam.student_id = student.id
            student_exam.exam_id = exam.id
            student_exam.start_date_time = datetime.datetime.now()
            student_exam.is_finish = False
            student_exam.save()
            for question in questions:
                student_exam_answer = StudentExamAnswer()
                student_exam_answer.student_exam_id = student_exam.id
                student_exam_answer.question_id = question.id
                student_exam_answer.total_spent_seconds = 0
                student_exam_answer.total_viewed_times = 0
                student_exam_answer.save()
        else:
            student_exam.save()

        return student_exam


    @staticmethod
    def write_spend_time_and_view_times_and_get_answer(exam, student_exam, active_question, request):
        try:
            last_question_id = request.session['last_question_id']
            if last_question_id:
                last_question = exam.get_assigned_question(question_id=last_question_id)
                student_exam_answer_last = student_exam.get_answer_with_question(last_question)
                around = datetime.datetime.now() - student_exam_answer_last.updated_at
                around_sec = around.seconds
                student_exam_answer_last.total_spent_seconds = student_exam_answer_last.total_spent_seconds + around_sec
                student_exam_answer_last.total_viewed_times = student_exam_answer_last.total_viewed_times + 1
                student_exam_answer_last.save()
                student_exam_answer_active = student_exam.get_answer_with_question(active_question)
                student_exam_answer_active.save()
                return student_exam_answer_active
            else:
                return False
        except:
            return False


    @staticmethod
    def user_subscribed_exam_ids(user):
        # subscriptions = Subscription.get_user_taken_and_active_subscriptions(user)
        exam_packages = ExamPackage.objects. \
            extra(
            where=[
                "subscriptions_subscriptiontypepackage.class_name = 'ExamPackage'",
                "subscriptions_subscriptiontypepackage.exam_package_id = exam_packages_exampackage.id",
                "subscriptions_subscriptiontypepackage.subscription_type_id = subscriptions_subscription.subscription_type_id",
                "subscriptions_subscription.active IS TRUE",
                "subscriptions_subscription.user_id =" + str(user.id)
            ],
            tables=["subscriptions_subscription", "subscriptions_subscriptiontypepackage"])

        ids = list()
        for exam_package in exam_packages:
            for exam in exam_package.exam.all():
                ids.append(exam.id)
        return list(set(ids))


    @staticmethod
    def get_student_available_exams_with_subscription(student):
        return Exam.objects.select_related('StudentExam'). \
            filter(state='published',
                   id__in=OnlineExam.user_subscribed_exam_ids(student.user),
                   start_date__lte=datetime.datetime.now(),
        ). \
            exclude(studentexam__is_finish=True,
                    studentexam__student_id=student.id)


    @staticmethod
    def get_student_available_exams(student):
        return Exam.objects.select_related('StudentExam'). \
            filter(state='published',
                   start_date__lte=datetime.datetime.now(),
        ). \
            exclude(studentexam__is_finish=True,
                    studentexam__student_id=student.id)




    @staticmethod
    def get_student_taken_exams(student):
        return Exam.objects.select_related('StudentExam'). \
            filter(start_date__lte=datetime.datetime.now(),
                   studentexam__is_finish=True,
                   studentexam__student_id=student.id)

