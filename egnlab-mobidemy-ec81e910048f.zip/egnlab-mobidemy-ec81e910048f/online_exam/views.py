from django.shortcuts import render
from django.shortcuts import get_object_or_404
from django.http import Http404
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.core.urlresolvers import reverse
from django.template import RequestContext
from django.contrib import messages
from django.utils.translation import ugettext_lazy as _
from exams.models import *
from questions.models import *
from settings.views import current_student
from online_exam.models import *
from settings.permission_required import student_login_required
import datetime


### Exam taking times methods start ###
@student_login_required
def student_exam_start(request, exam_id):
    student = current_student(request)
    exam = get_object_or_404(OnlineExam.get_student_available_exams_with_subscription(current_student(request)), id=exam_id)
    OnlineExam.initialize_student_exam_and_answers(exam, student)
    active_question = exam.get_assigned_questions()[:1].get()
    request.session['last_question_id'] = active_question.id
    return HttpResponseRedirect(reverse('student_exam_question_show_path', kwargs={'exam_id': exam.id, 'question_id': active_question.id}))


@student_login_required
def student_exam_question_show(request, exam_id, question_id):
    student = current_student(request)
    exam = get_object_or_404(OnlineExam.get_student_available_exams(current_student(request)), id=exam_id)
    student_exam = StudentExam.get_exam_with_student(student, exam)

    if not student_exam:
       raise Http404

    if not student_exam.check_student_exam_time():
        return HttpResponseRedirect(reverse('student_exam_finish_path', kwargs={'exam_id': exam.id}))

    active_question = exam.get_assigned_question(question_id=question_id)
    active_question_image = active_question.get_question_image()
    exam_type_sub_heads = exam.exam_type.examtypesubhead_set.all()
    choice_list = exam.exam_type.choices_with_list()

    student_exam_answer = OnlineExam.write_spend_time_and_view_times_and_get_answer(exam, student_exam, active_question, request)
    if not student_exam_answer:
        return HttpResponseRedirect(reverse('student_exam_start_path', kwargs={'exam_id': exam.id}))
    request.session['last_question_id'] = active_question.id

    return render_to_response('online_exam/student_exam_question_show.html', locals(), context_instance=RequestContext(request))


@student_login_required
def student_exam_question_show_next(request, exam_id, question_id):
    exam = get_object_or_404(OnlineExam.get_student_available_exams(current_student(request)), id=exam_id)
    active_exam_question = exam.examquestion_set.get(question_id=question_id)
    next_exam_question = active_exam_question.get_next_exam_question()
    if not next_exam_question:
        next_exam_question = active_exam_question
    return HttpResponseRedirect(reverse('student_exam_question_show_path', kwargs={'exam_id': exam.id, 'question_id': next_exam_question.question_id}))


@student_login_required
def student_exam_question_show_previous(request, exam_id, question_id):
    exam = get_object_or_404(OnlineExam.get_student_available_exams(current_student(request)), id=exam_id)
    active_exam_question = exam.examquestion_set.get(question_id=question_id)
    previous_exam_question = active_exam_question.get_previous_exam_question()
    if not previous_exam_question:
        previous_exam_question = active_exam_question
    return HttpResponseRedirect(reverse('student_exam_question_show_path', kwargs={'exam_id': exam.id, 'question_id': previous_exam_question.question_id}))



@student_login_required
def student_exam_question_show_target(request, exam_id, question_id, target_question_id):
    exam = get_object_or_404(OnlineExam.get_student_available_exams(current_student(request)), id=exam_id)
    return HttpResponseRedirect(reverse('student_exam_question_show_path', kwargs={'exam_id': exam.id, 'question_id': target_question_id}))



@student_login_required
def student_exam_answer(request, exam_id, question_id, answer_id):
    student = current_student(request)
    exam = get_object_or_404(OnlineExam.get_student_available_exams(current_student(request)), id=exam_id)
    active_question = exam.get_assigned_question(question_id=question_id)
    student_exam = StudentExam.get_exam_with_student(student, exam)

    if not student_exam.check_student_exam_time():
        return HttpResponseRedirect(reverse('student_exam_finish_path', kwargs={'exam_id': exam.id}))

    student_exam_answer = student_exam.get_answer_with_question(active_question)

    student_exam_answer.answer_index_number = answer_id
    student_exam_answer.save()

    return HttpResponseRedirect(reverse('student_exam_question_show_next_path', kwargs={'exam_id': exam.id, 'question_id': active_question.id}))



@student_login_required
def student_exam_finish(request, exam_id):
    exam = get_object_or_404(OnlineExam.get_student_available_exams(current_student(request)), id=exam_id)
    student = current_student(request)
    student_exam = StudentExam.get_exam_with_student(student, exam)
    student_exam.finish_date_time = datetime.datetime.now()
    student_exam.is_finish = True
    student_exam.save()
    return HttpResponseRedirect(reverse('student_exam_report_path', kwargs={'exam_id': exam.id}))


### Exam taking times methods end ###
