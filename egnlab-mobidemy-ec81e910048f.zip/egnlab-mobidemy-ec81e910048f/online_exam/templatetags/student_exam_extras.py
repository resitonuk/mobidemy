from django import template

register = template.Library()

@register.filter
def exam_assigned_questions_with_exam_topic_filter(value, topic_id):
    return value.get_assigned_questions_by_exam_type_topic(topic_id)

@register.filter
def exam_assigned_questions_with_exam_sub_head_filter(value, exam):
    return value.assigned_questions_with_exam(exam)

@register.filter
def student_exam_answer_choice_index_with_question_filter(value, question):
    student_exam_answer = value.get_answer_with_question(question)
    return student_exam_answer.answer_index_number


