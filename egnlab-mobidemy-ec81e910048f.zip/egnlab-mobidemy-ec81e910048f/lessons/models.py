from django.db import models
from django.utils.translation import ugettext_lazy as _
from user_conf.models import *
from lesson_categories.models import *


class Lesson(models.Model):
    name = models.CharField(_('lesson'), max_length=100)
    description = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = _('Lesson')
        verbose_name_plural = _('Lessons')

    def __unicode__(self):
        return self.name


class LessonLessonCategoryUnitTopic(models.Model):
    lesson = models.ForeignKey('lessons.Lesson', blank=True, null=True)
    lesson_category_unit_topic = models.ForeignKey('lesson_categories.LessonCategoryUnitTopic', blank=True, null=True)

    class Meta:
        verbose_name = _('Lesson Lesson Category')
        verbose_name_plural = _('Lesson Lesson Categories')


class LessonLessonLevel(models.Model):
    lesson = models.ForeignKey('lessons.Lesson', blank=True, null=True)
    lesson_level = models.ForeignKey('lesson_categories.LessonLevel', blank=True, null=True)

    class Meta:
        verbose_name = _('Lesson Lesson Level')
        verbose_name_plural = _('Lesson Lesson Levels')

