# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('lesson_categories', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Lesson',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100, verbose_name='lesson')),
                ('description', models.TextField(null=True, blank=True)),
            ],
            options={
                'verbose_name': 'Lesson',
                'verbose_name_plural': 'Lessons',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='LessonLessonCategoryUnitTopic',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('lesson', models.ForeignKey(blank=True, to='lessons.Lesson', null=True)),
                ('lesson_category_unit_topic', models.ForeignKey(blank=True, to='lesson_categories.LessonCategoryUnitTopic', null=True)),
            ],
            options={
                'verbose_name': 'Lesson Lesson Category',
                'verbose_name_plural': 'Lesson Lesson Categories',
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='LessonLessonLevel',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('lesson', models.ForeignKey(blank=True, to='lessons.Lesson', null=True)),
                ('lesson_level', models.ForeignKey(blank=True, to='lesson_categories.LessonLevel', null=True)),
            ],
            options={
                'verbose_name': 'Lesson Lesson Level',
                'verbose_name_plural': 'Lesson Lesson Levels',
            },
            bases=(models.Model,),
        ),
    ]
