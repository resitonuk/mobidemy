from django.contrib import admin
from lessons.models import Lesson
from videos.models import LessonVideo


class LessonVideoInline(admin.TabularInline):
    model = LessonVideo
    extra = 2

class LessonAdmin(admin.ModelAdmin):
    inlines = [
        LessonVideoInline,
    ]



admin.site.register(Lesson, LessonAdmin)