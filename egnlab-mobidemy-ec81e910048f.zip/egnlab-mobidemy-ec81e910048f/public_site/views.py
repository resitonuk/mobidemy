from django.shortcuts import render, redirect
from django.template import RequestContext
from django.core.urlresolvers import reverse
from questions.views import *
from django.contrib.auth.decorators import login_required, user_passes_test
from settings.views import editor_check
from django.contrib import messages
from settings.views import current_student
# Create your views here.

from institutions.models import Institution
from django.core.mail import EmailMultiAlternatives
from django.core.mail import send_mail

def root_path(request):
    user = request.user

    if user.id:
        student = current_student(request)
    return render(request, 'public_site/index.html',locals(), context_instance=RequestContext(request))

@login_required
@user_passes_test(editor_check, login_url='/permission-denied/')
def editor_root_path(request):
    return render(request, 'public_site/editor_index.html')


def permission_denied(request):
    return render_to_response('public_site/permission-denied.html',locals(), context_instance=RequestContext(request))

def login_redirect_router(request):
    user = request.user
    if user.id:
        if user.groups.filter(name='editor').exists():
            return redirect('editor_root_path')
        if user.groups.filter(name='teacher').exists():
            return redirect('root_path')
        elif user.groups.filter(name='student').exists():
            student = current_student(request)
            return redirect('student_root_path')
        else:
            return redirect('root_path')
