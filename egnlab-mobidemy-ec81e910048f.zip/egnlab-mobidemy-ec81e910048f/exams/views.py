from django.shortcuts import render
from django_tables2 import RequestConfig
from django.shortcuts import get_object_or_404
from django.http import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.contrib import messages
from django.utils.translation import ugettext_lazy as _
from exams.models import *
from questions.models import *
from exams.models import *
from  settings.permission_required import editor_login_required


#@editor_login_required
def exam_list(request):
    table = ExamTable(Exam.objects.all())
    RequestConfig(request, paginate={"per_page": 16}).configure(table)
    return render(request, 'exams/list.html', {'exams': table})


#@editor_login_required
def exam_show(request, object_id):
    exam = get_object_or_404(Exam.get_assignable_exams(), id=object_id)
    exam_type_sub_heads = exam.exam_type.examtypesubhead_set.all()
    exam_complete_status = exam.can_complete()
    return render_to_response('exams/show.html', locals(), context_instance=RequestContext(request))


#@editor_login_required
def exam_question_assign_show(request, exam_id, exam_type_sub_head_id):
    exam = get_object_or_404(Exam.get_assignable_exams(), id=exam_id)
    exam_type = exam.exam_type
    exam_type_sub_head = get_object_or_404(ExamTypeSubHead, id=exam_type_sub_head_id)
    exam_type_sub_head_topics = exam_type_sub_head.examtypesubheadtopic_set.all()
    sub_head_complete_status = exam_type_sub_head.is_exam_complete(exam)
    # assignable_questions = exam.get_assigned_questions_by_exam_type_topic
    return render_to_response('exams/question_assign.html', locals(), context_instance=RequestContext(request))


#@editor_login_required
def exam_question_assign(request, exam_id, exam_type_sub_head_id, exam_type_sub_head_topic_id, question_id):
    exam = get_object_or_404(Exam.get_assignable_exams(), id=exam_id)
    exam_type_sub_head = get_object_or_404(ExamTypeSubHead.objects.all(), id=exam_type_sub_head_id)
    sub_head_complete_status = exam_type_sub_head.is_exam_complete(exam)
    if not sub_head_complete_status:
        if exam.state == 'initiated' or exam.state == 'assigning':
            exam_question_check = ExamQuestion.objects.filter(question_id=question_id,
                                                              exam_id=exam_id)  # This means One question must not assign multiple times.
            if not exam_question_check:
                exam_question = ExamQuestion()
                exam_question.exam_id = exam_id
                exam_question.question_id = question_id
                exam_type_sub_head_topic = ExamTypeSubHeadTopic.objects.get(id=exam_type_sub_head_topic_id)
                exam_question.exam_type_sub_head_topic_id = exam_type_sub_head_topic.id
                exam_question.exam_type_sub_head_id = exam_type_sub_head_id
                exam_question.assign_user_id = request.user.id

                ### Order number set algorithm (Support of One topic 1000 question, 100 Sub Head) ##
                head_order_number = exam_type_sub_head.order_number * 1000000
                topic_order_number = exam_type_sub_head_topic.order_number * 1000
                exam_question.order_number = head_order_number + topic_order_number + int(question_id)


                exam_question.save()
                assigned_questions = exam.get_assigned_questions
                if exam.state == 'initiated':
                    exam.assign()
                    exam.save()
                messages.success(request, _('Question assigned successfully'))
        else:
            messages.error(request, _('Question not assigned. exam state not available.'))
    else:
        messages.error(request, _('Question not assigned. Exam sub head is full or complete for the exam.'))
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))



#@editor_login_required
def exam_question_remove(request, exam_id, exam_type_sub_head_id, exam_type_sub_head_topic_id, question_id):
    exam = get_object_or_404(Exam.get_assignable_exams(), id=exam_id)
    if exam.state == 'completed' or exam.state == 'assigning':
        exam_question = ExamQuestion.objects.get(question_id=question_id, exam_id=exam_id,
                                                 exam_type_sub_head_topic_id=exam_type_sub_head_topic_id)
        exam_question.delete()
        if exam.state == 'completed':
            exam.assign()
            exam.save()
        messages.success(request, _('Question removed successfully from exam.'))
    else:
        messages.error(request, _('Question not removed. exam state not available.'))
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))



#@editor_login_required
def exam_complete(request, object_id):
    exam = get_object_or_404(Exam.objects.filter(state='assigning').all(), id=object_id)
    if exam.can_complete():
        exam.complete()
        exam.save()
        messages.success(request, _('Exam state changed successfully.'))
    else:
        messages.error(request, _('Exam state not changed. The exam must be assign all required questions.'))
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))



#@editor_login_required
def exam_publish(request, object_id):
    exam = get_object_or_404(Exam.objects.filter(state='completed').all(), id=object_id)
    exam.publish()
    exam.save()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))



#@editor_login_required
def exam_unpublish(request, object_id):
    exam = get_object_or_404(Exam.objects.filter(state='published').all(), id=object_id)
    exam.unpublish()
    exam.save()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))



#@editor_login_required
def exam_republish(request, object_id):
    exam = get_object_or_404(Exam.objects.filter(state='unpublished').all(), id=object_id)
    exam.republish()
    exam.save()
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))

