from django.contrib import admin
from exams.models import *


class CustomModelChoiceFieldExamType(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return "%s - %s" % (obj.exam_type.name, obj.name)


class CustomModelChoiceFieldLessonCategory(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return "%s - %s - %s - %s" % (obj.lesson_category_unit.lesson_category.lesson_level.name, obj.lesson_category_unit.lesson_category.name ,obj.lesson_category_unit.name, obj.name)



class MyExamTypeSubHeadTopicAdminForm(forms.ModelForm):
    exam_type_sub_head = CustomModelChoiceFieldExamType(queryset=ExamTypeSubHead.objects.order_by('exam_type_id').all())
    lesson_category_unit_topic = CustomModelChoiceFieldLessonCategory(queryset=LessonCategoryUnitTopic.objects.order_by('lesson_category_unit_id').all())

    class Meta:
        model = ExamTypeSubHeadTopic
        fields = '__all__'


class ExamTypeSubHeadTopicAdmin(admin.ModelAdmin):
    form = MyExamTypeSubHeadTopicAdminForm



# Register your models here.
admin.site.register(ExamType)
admin.site.register(ExamTypeSubHead)
admin.site.register(ExamTypeSubHeadTopic, ExamTypeSubHeadTopicAdmin)
admin.site.register(Exam)
