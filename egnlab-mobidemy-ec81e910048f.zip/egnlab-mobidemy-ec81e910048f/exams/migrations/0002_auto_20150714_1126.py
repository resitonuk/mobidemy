# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('lesson_categories', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('questions', '0001_initial'),
        ('user_conf', '0001_initial'),
        ('exams', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='studentexam',
            name='student',
            field=models.ForeignKey(to='user_conf.Student'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='examtypesubheadtopic',
            name='exam_type_sub_head',
            field=models.ForeignKey(to='exams.ExamTypeSubHead'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='examtypesubheadtopic',
            name='lesson_category_unit_topic',
            field=models.ForeignKey(to='lesson_categories.LessonCategoryUnitTopic'),
            preserve_default=True,
        ),
        migrations.AlterUniqueTogether(
            name='examtypesubheadtopic',
            unique_together=set([('name', 'exam_type_sub_head'), ('order_number', 'exam_type_sub_head')]),
        ),
        migrations.AddField(
            model_name='examtypesubhead',
            name='exam_type',
            field=models.ForeignKey(to='exams.ExamType'),
            preserve_default=True,
        ),
        migrations.AlterUniqueTogether(
            name='examtypesubhead',
            unique_together=set([('order_number', 'exam_type'), ('name', 'exam_type')]),
        ),
        migrations.AddField(
            model_name='examquestion',
            name='assign_user',
            field=models.ForeignKey(db_column=b'assign_user_id', blank=True, to=settings.AUTH_USER_MODEL, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='examquestion',
            name='exam',
            field=models.ForeignKey(to='exams.Exam'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='examquestion',
            name='exam_type_sub_head',
            field=models.ForeignKey(default=1, to='exams.ExamTypeSubHead'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='examquestion',
            name='exam_type_sub_head_topic',
            field=models.ForeignKey(default=1, to='exams.ExamTypeSubHeadTopic'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='examquestion',
            name='question',
            field=models.ForeignKey(to='questions.Question'),
            preserve_default=True,
        ),
        migrations.AlterUniqueTogether(
            name='examquestion',
            unique_together=set([('order_number', 'exam'), ('question', 'exam')]),
        ),
        migrations.AddField(
            model_name='exam',
            name='created_user',
            field=models.ForeignKey(related_name='exam_created', db_column=b'created_user_id', blank=True, to=settings.AUTH_USER_MODEL, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='exam',
            name='exam_type',
            field=models.ForeignKey(to='exams.ExamType'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='exam',
            name='published_user',
            field=models.ForeignKey(related_name='exam_published', db_column=b'published_user_id', blank=True, to=settings.AUTH_USER_MODEL, null=True),
            preserve_default=True,
        ),
    ]
