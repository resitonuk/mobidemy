from django.db import models
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from django_fsm import FSMField, transition
import django_tables2 as tables
from django.db.models import Q
from user_conf.models import *
from lesson_categories.models import *
from questions.models import Question
import datetime

class Choice:
    def __init__(self, index, name):
        self.index = index
        self.name = name

    def index(self):
        return self.index

    def name(self):
        return self.name

    @staticmethod
    def new(choice_count):
        choices = list()
        for i in range(choice_count):
            choice = Choice(i + 1, chr(ord('A') + i))
            choices.append(choice)
        return choices


class ExamType(models.Model):
    name = models.CharField(_('exam_type_name'), max_length=60, unique=True)
    choice_count = models.IntegerField(default=5)

    class Meta:
        app_label = 'exams'
        verbose_name = _('Exam Type')
        verbose_name_plural = _('Exam Types')

    def __unicode__(self):
        return self.name


    def full_name(self):
        value = ''
        try:
            value = self.name + self.choice_count
        except:
            value = self.name
        return value

    def choices_with_list(self):
        return Choice.new(self.choice_count)


###################################################################



class ExamTypeSubHead(models.Model):
    exam_type = models.ForeignKey(ExamType)
    name = models.CharField(max_length=100)
    order_number = models.IntegerField(default=0)
    question_count = models.IntegerField(default=0)


    class Meta:
        app_label = 'exams'
        verbose_name = _('Exam Type Sub Head')
        verbose_name_plural = _('Exam Type Sub Heads')
        ordering = ['order_number']
        unique_together = (("name", "exam_type"), ("order_number", "exam_type"),)

    def __unicode__(self):
        return self.name


    def available_questions_with_exam(self, exam):
        lesson_category_unit_topics = self.examtypesubheadtopic_set.all()
        category_list = list()
        for val in lesson_category_unit_topics:
            category_list.append(val.lesson_category_unit_topic_id)

        questions = Question.objects.select_related('ExamQuestion', 'QuestionLessonCategoryUnitTopic'). \
            filter(questionlessoncategoryunittopic__lesson_category_unit_topic_id__in=category_list,
                   state='published').exclude(examquestion__exam_id=exam.id)
        return list(set(questions))

    def assigned_questions_with_exam(self, exam):
        questions = Question.objects.select_related('ExamQuestion'). \
            filter(examquestion__exam_id=exam.id,
                   examquestion__exam_type_sub_head_id=self.id,
        )
        return questions

    def is_exam_complete(self, exam):
        if self.assigned_questions_with_exam(exam).count() == self.question_count:
            return True
        else:
            return False


######################################################################




class ExamTypeSubHeadTopic(models.Model):
    exam_type_sub_head = models.ForeignKey(ExamTypeSubHead)
    lesson_category_unit_topic = models.ForeignKey(LessonCategoryUnitTopic)
    name = models.CharField(max_length=100)
    order_number = models.IntegerField(default=0)
    ordering = ['order_number']

    class Meta:
        app_label = 'exams'
        verbose_name = _('Exam Type Sub Head Topic')
        verbose_name_plural = _('Exam Type Sub Head Topics')
        ordering = ['order_number']
        unique_together = (("name", "exam_type_sub_head"), ("order_number", "exam_type_sub_head"), )

    def __unicode__(self):
        return self.name


    def available_questions_with_exam(self, exam):
        return Question.objects.select_related('ExamQuestion', 'QuestionLessonCategoryUnitTopic').\
            filter(questionlessoncategoryunittopic__lesson_category_unit_topic_id=self.lesson_category_unit_topic_id,
                   state='published').\
            exclude(examquestion__exam_id=exam.id)




#############################################################################




STATES = {
    'initiated',
    'assigning',
    'completed',
    'published',
    'unpublished',
    'canceled'
}


class Exam(models.Model):
    exam_type = models.ForeignKey(ExamType)
    created_user = models.ForeignKey(User, db_column='created_user_id', related_name='%(class)s_created', blank=True,
                                     null=True)
    published_user = models.ForeignKey(User, db_column='published_user_id', related_name='%(class)s_published',
                                       blank=True, null=True)
    name = models.CharField(max_length=100, unique=True)
    start_date = models.DateTimeField(blank=True, null=True)
    total_time = models.IntegerField(default=0)
    state = FSMField(default='initiated')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    explanation = models.TextField(blank=True, null=True)

    class Meta:
        app_label = 'exams'
        verbose_name = _('Exam')
        verbose_name_plural = _('Exams')

    def __unicode__(self):
        return self.name


    ### State Machine Methods start ###

    @transition(field=state, source='initiated', target='assigning')
    def assign(self):
        ''


    @transition(field=state, source='assigning', target='completed')
    def complete(self):
        ''


    @transition(field=state, source='completed', target='published')
    def publish(self):
        ''


    @transition(field=state, source='published', target='unpublished')
    def unpublish(self):
        ''


    @transition(field=state, source='unpublished', target='published')
    def republish(self):
        ''


    @transition(field=state, source='*', target='canceled')
    def cancel(self):
        ''


    def can_complete(self):
        flag = True
        try:
            exam_type_sub_heads = self.exam_type.examtypesubhead_set.all()
            for exam_type_sub_head in exam_type_sub_heads:
                if not exam_type_sub_head.is_exam_complete(self):
                    flag = False
        except:
            flag = False
        return flag

    ### State Machine Methods end ###

    @staticmethod
    def get_assignable_exams():
        return Exam.objects.filter(Q(state='initiated') | Q(state='assigning') | Q(state='completed'))


    @staticmethod
    def get_published_exams():
        return Exam.objects.filter(state='published')


    def get_assigned_questions(self):
        return Question.objects.select_related('ExamQuestion').filter(examquestion__exam_id=self.id)

    def get_assigned_question(self, question_id):
        return Question.objects.select_related('ExamQuestion').get(examquestion__exam_id=self.id, id=question_id)

    def get_assigned_questions_by_exam_type_topic(self, topic_id):
        return Question.objects.select_related('ExamQuestion').filter(examquestion__exam_id=self.id,
                                                                      examquestion__exam_type_sub_head_topic_id=topic_id)


class ExamTable(tables.Table):
    actions = tables.TemplateColumn(template_name='exams/inline/general_table_link.html', orderable=False)

    class Meta:
        model = Exam



##############################################################################





class ExamQuestion(models.Model):
    exam = models.ForeignKey(Exam)
    question = models.ForeignKey('questions.Question')
    assign_user = models.ForeignKey(User, db_column='assign_user_id', blank=True, null=True)
    exam_type_sub_head_topic = models.ForeignKey(ExamTypeSubHeadTopic, default=1)
    exam_type_sub_head = models.ForeignKey(ExamTypeSubHead, default=1)
    order_number = models.IntegerField(default=0)

    class Meta:
        app_label = 'exams'
        verbose_name = _('Assigned Question')
        verbose_name_plural = _('Assigned Questions')
        ordering = ['order_number']
        unique_together = (("order_number", "exam"), ("question", "exam"), )

    def __unicode__(self):
        return self.order_number


    def get_next_exam_question(self):
        val = None
        try:
            val = ExamQuestion.objects.filter(exam_id=self.exam_id ,order_number__gt=self.order_number)[:1].get()
        except:
            val = False
        return val


    def get_previous_exam_question(self):
        val = None
        try:
            val = ExamQuestion.objects.filter(exam_id=self.exam_id ,order_number__lt=self.order_number).order_by('-order_number')[:1].get()
        except:
            val = False
        return val




#################################################################################




class StudentExam(models.Model):
    exam = models.ForeignKey(Exam)
    student = models.ForeignKey(Student)
    start_date_time = models.DateTimeField(blank=True, null=True)
    finish_date_time = models.DateTimeField(blank=True, null=True)
    hold_date_time = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_finish = models.BooleanField(default=False)

    class Meta:
        app_label = 'exams'
        verbose_name = _('Student Exam')
        verbose_name_plural = _('Student Exams')


    @staticmethod
    def get_exam_with_student(student, exam):
        val = None
        try:
            val = StudentExam.objects.get(student_id=student.id, exam_id=exam.id)
        except:
            val = False
        return val


    @staticmethod
    def get_exams_with_student(student):
        return StudentExam.objects.filter(student_id=student.id)


    def last_datetime(self):
        s_date = self.start_date_time
        e_date = s_date + datetime.timedelta(minutes=self.exam.total_time)
        return e_date

    def check_student_exam_time(self):
        return self.last_datetime() >= datetime.datetime.now()


    def get_answer_with_question(self, question):
        val = None
        try:
            val = self.studentexamanswer_set.get(question_id=question.id)
        except:
            val = False
        return val




###############################################################################



class StudentExamAnswer(models.Model):
    student_exam = models.ForeignKey(StudentExam)
    question = models.ForeignKey('questions.Question')
    answer_index_number = models.IntegerField(blank=True, null=True)
    total_spent_seconds = models.IntegerField(default=0)
    total_viewed_times = models.IntegerField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'exams'
        verbose_name = _('Student Exam Answer')
        verbose_name_plural = _('Student Exam Answers')
        unique_together = (("question", "student_exam"),)

    def __unicode__(self):
        return self.answer_index_number


