from django.db import models
from django.utils.translation import ugettext_lazy as _
from user_conf.models import *
from questions.models import *
from lesson_categories.models import *
from lessons.models import *
from videos.models import *
from quizzes.models import *

class StudentQuiz(models.Model):

    student = models.ForeignKey(Student)
    quiz = models.ForeignKey('quizzes.Quiz')
    start_date_time = models.DateTimeField(blank=True, null=True)
    finish_date_time = models.DateTimeField(blank=True, null=True)
    hold_date_time = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_finish = models.BooleanField(default=False)

    class Meta:
        app_label = 'online_quizzes'
        verbose_name = _('Student Quiz')
        verbose_name_plural = _('Student Quizzes')

class StudentQuizAnswer(models.Model):

    student_quiz = models.ForeignKey(StudentQuiz)
    question = models.ForeignKey('questions.Question')
    answer_index_number = models.IntegerField(blank=True, null=True)
    total_spent_seconds = models.IntegerField(default=0)
    total_viewed_times = models.IntegerField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'online_quizzes'
        verbose_name = _('Student Quiz Answer')
        verbose_name_plural = _('Student Quiz Answers')
        unique_together = (("question", "student_quiz"),)

    def __unicode__(self):
        return self.answer_index_number




